<?php

session_start();
require_once 'database_connection.php';




function adminLogin($username, $password, $referer, $conn) {
    echo "adminLogin";

    echo $password;

    $sql = "SELECT * FROM admin WHERE username = '$username' AND status = 'active'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);

        if(password_verify($password, $row['password'])) {
            $_SESSION['logged_in'] = true;

            $_SESSION['admin_id']       = $row['id'];
            $_SESSION['name']           = $row['name'];
            $_SESSION['status']         = $row['status'];
            $_SESSION['username']       = $row['username'];
            $_SESSION['user_type']      = $row['user_type'];
    
            header("Location: ".getBaseUrl()."/admin/views/section/index.php");
        } else {
            header("Location: ".urlQueryDataRemover($referer)."?warning=Incorrect Password");
        }
        
    } else {
        header("Location: ".urlQueryDataRemover($referer)."?warning=Account not found");
    }
}

function adviserLogin($username, $password, $referer, $conn) {

    $sql = "SELECT * FROM advisers WHERE email = '$username' AND status = 1";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);

        if(password_verify($password, $row['password'])) {
            $_SESSION['logged_in'] = true;

            $_SESSION['adviser_id']     = $row['id'];
            $_SESSION['first_name']     = $row['first_name'];
            $_SESSION['last_name']      = $row['last_name'];
            $_SESSION['birthdate']      = $row['birthdate'];
            $_SESSION['email']            = $row['email'];
            $_SESSION['status']         = $row['status'];
            $_SESSION['user_type']      = 'adviser';
    
            header("Location: ".getBaseUrl()."/adviser/views/student/index.php");
        } else {
            header("Location: ".urlQueryDataRemover($referer)."?warning=Incorrect Password");
        }
        
    } else {
        header("Location: ".urlQueryDataRemover($referer)."?warning=Account not found");
    }
}

function studentLogin($username, $password, $referer, $conn)
{
    echo "studentLogin";

    $sqlStudentAccount = "SELECT * FROM students WHERE student_school_id = '$username' OR email = '$username' AND password = '$password'";
        $resultStudentAccount = mysqli_query($conn, $sqlStudentAccount);

        if (mysqli_num_rows($resultStudentAccount) > 0) {
            $rowStudentAccount = mysqli_fetch_assoc($resultStudentAccount);

            if ($rowStudentAccount['status'] == 'inactive') {
                header("Location: ".urlQueryDataRemover($referer)."?warning=Account deactivated");
            } else {
                $_SESSION['logged_in'] = true;

                $_SESSION['student_id']      = $rowStudentAccount['student_id'];
                $_SESSION['student_school_id']      = $rowStudentAccount['student_school_id'];
                $_SESSION['first_name']             = $rowStudentAccount['first_name'];
                $_SESSION['middle_name']            = $rowStudentAccount['middle_name'];
                $_SESSION['last_name']              = $rowStudentAccount['last_name'];
                $_SESSION['sex']                    = $rowStudentAccount['sex'];
                $_SESSION['birthdate']              = $rowStudentAccount['birthdate'];
                $_SESSION['course_id']              = $rowStudentAccount['course_id'];
                $_SESSION['year']                   = $rowStudentAccount['year'];
                $_SESSION['email']                  = $rowStudentAccount['email'];
                $_SESSION['password']               = $rowStudentAccount['password'];
                $_SESSION['password']               = $rowStudentAccount['password'];

                $_SESSION['user_type']  = 'student';
                $_SESSION['session_type']  = 'student';

                header("Location: student/dashboard.php");
            }
        } else {
            header("Location: ".urlQueryDataRemover($referer)."?warning=Accountnotfound");
        }
}



function urlQueryDataRemover($url) {
    $parts = explode('?', $url, 2);
    $cleanUrl = $parts[0];

    return $cleanUrl;
}

function getBaseUrl() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'];
    $baseUrl = $protocol . $host . "/bnhsVms";

    return $baseUrl;
}

if (isset($_POST['submit'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $referer = $_SERVER['HTTP_REFERER'];

    $adminLoginUrl = "admin_login";
    $studentLoginUrl = "index";
    $adviserLoginUrl = "adviser_login";

    if (str_contains($referer, $adminLoginUrl)) {
        adminLogin($username, $password, $referer, $conn);
    } elseif (str_contains($referer, $studentLoginUrl)) {
        studentLogin($username, $password, $referer, $conn);
    } elseif (str_contains($referer, $adviserLoginUrl)) {
        adviserLogin($username, $password, $referer, $conn);
    } else {
        echo "Unidentified URL Referer";
        return;
    }

}
