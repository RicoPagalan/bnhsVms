<?php
session_start();

if (!isset($_SESSION['live_viewing_code_verified'])) {
    header("location: ./input_token_lv.php?warning=Access denied");
    exit();
}


$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'];
$baseUrl = $protocol . $host . "/bnhsVms";

require_once "./models/ElectionPeriod.php";

$election_period_id = $_SESSION['live_viewing_ep_id'];

$ElectionPeriod = new ElectionPeriod();

$electionPeriod = $ElectionPeriod->read($election_period_id);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,300,0,0" />
    <link rel="stylesheet" href="./assets/css/base.css">

    <script defer src="./assets/javascript/index.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>

    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">

    <script defer src="./assets/javascript/element-status-colors.js"></script>
</head>

<body>

    <main class="candidacy-main-container">
        <div class="align-self-center flex-column align-center">
            <h3>Cast Your Votes</h3>
            <p class="size-16"><?= $electionPeriod[0]['title'] ?></p>
        </div>
        <div id="positions-container" class="flex-column gap-20">
            <p id="loading-data-label">Loading election data...</p>
        </div>

        <!-- <div class="background-white padding-20 radius-5 flex-column">
            <p class="size-12 color-warning">Please review your selections above before proceeding</p>
            <br>
            <div class="flex-row gap-10 align-center">
                <input type="checkbox" required class="cursor-pointer">
                <p>I understand that my vote cannot be changed once it has been submitted, meaning that after casting my vote, it becomes final and irreversible.</p>
            </div>

            <br>
        </div> -->

        <div class="flex-row align-stretch gap-10">
            <a href="<?= $baseUrl ?>/input_token_lv.php?action=reset" class="button-1 background-primary-variant color-white">BACK</a>
        </div>
    </main>
    <br><br><br><br><br><br>

    <script>
        console.log("dasdsafthg");

        $(document).ready(function() {

            setInterval(function() {
                $.ajax({
                    url: './live_viewing_handler.php',
                    type: 'POST',
                    data: {
                        election_period_id: <?= $election_period_id ?>, // Modify the ID as necessary
                    },
                    success: function(response) {
                        // Assuming you have a container in your HTML where this data will be inserted
                        $('#positions-container').html(response); // Insert the HTML directly into the container
                    },
                    error: function(xhr, status, error) {
                        // Handle error
                        console.error('Error fetching data:', error);
                        alert('An error occurred while fetching data.'); // Display an alert on error
                    }
                });
            }, 2000)


            setInterval(function() {
                $('#loading-data-label').fadeOut(250).fadeIn(250);
            }, 100);
        });

    </script>

</body>

</html>