<?php
require_once "../../../models/Adviser.php";
require_once "../../../models/AdviserSection.php";

if(isset($_POST['update_adviser'])) {
    $Adviser = new Adviser();

    $id = $_POST['id'];

    $adviser = $Adviser->read($id);

    $section_id = $_POST['section_id'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $birthdate = $_POST['birthdate'];
    $email = $_POST['email'];
    $status = $_POST['status'];

    $result = $Adviser->update($id, $first_name, $last_name, $birthdate, $email, $status);

    if ($result) {
        // if adviser assigned section changed
        if($adviser['section_id'] !== $section_id) {
            $AdviserSection = new AdviserSection();
            $AdviserSection->deactivateById($adviser['adviser_section_id']);

            // insert new adviser section
            $rslt = $AdviserSection->insert($id, $section_id);

            if ($rslt) {
                header("Location: ".$Adviser->getBaseUrl()."/admin/views/adviser/show.php?id=$id");
            } else {
                header("Location: ".$Adviser->getBaseUrl()."/admin/views/adviser/show.php?id=$id&warning=Something went wrong!");
            }

        } else {
            header("Location: ".$Section->getBaseUrl()."/admin/views/adviser/show.php?id=".$id);
        }
    } else {
        echo "Error: Something went wrong!";
    }
}
