<?php
session_start();

require_once "../../../models/Student.php";
require_once "../../../models/VotersToken.php";
require_once "../../../models/Adviser.php";
require_once "../../../models/ElectionPeriod.php";

$Student = new Student();
$Adviser = new Adviser();
$VotersToken = new VotersToken();
$ElectionPeriod = new ElectionPeriod();

if (isset($_POST['generate_bulk'])) {
    $election_period_id = $_POST['election_period_id'];

    $election_period = $ElectionPeriod->read($election_period_id);

    if($election_period[0]['special_status'] != 'open' && $election_period[0]['special_status'] != 'ongoing') {
        header("Location: ".$Student->getBaseUrl()."/adviser/views/election_period/voters_token_index.php?id=$election_period_id&result=Cannot generate token anymore!");
        return;
    }

    $adviser_id = isset($_SESSION['adviser_id']) ? $_SESSION['adviser_id'] : NULL;
    $adviser = $Adviser->read($adviser_id);
    $section_id = $adviser['section_id'];
    
    // get all the students of a section who have no voters token yet for this election and section
    $student_ids = $Student->getAllStudentsWithNoVT($section_id, $election_period_id);

    if(is_array($student_ids) && !empty($student_ids)) {
        $dataArray = [];

        foreach($student_ids as $student_id) {
            $token = 'vt'.$student_id.$election_period_id.substr(bin2hex(random_bytes(10)), 0, 10);

            $row['token'] = $token;
            $row['student_id'] = $student_id;
            $row['adviser_id'] = $adviser_id;
            $row['section_id'] = $section_id;
            $row['election_period_id'] = $election_period_id;
            $row['valid_flag'] = 1;

            $dataArray[] = $row;
        }

        $result = $VotersToken->insertMany($dataArray);

        if($result) {
            header("Location: ".$Student->getBaseUrl()."/adviser/views/election_period/voters_token_index.php?id=$election_period_id&result=Successfully generated tokens");
        } else {
            header("Location: ".$Student->getBaseUrl()."/adviser/views/election_period/voters_token_index.php?id=$election_period_id&result=Something went wrong!");
        }
    }

} else {
    echo "No form submission detected.";
}
