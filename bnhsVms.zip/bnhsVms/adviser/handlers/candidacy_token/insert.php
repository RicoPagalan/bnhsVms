<?php

require_once "../../../models/CandidacyToken.php";
require_once "../../../models/ElectionPeriod.php";

if (isset($_POST['insert_candidacy_token'])) {
    $CandidacyToken = new CandidacyToken();
    $ElectionPeriod = new ElectionPeriod();

    
    $student_id = $_POST['student_id'];
    $election_period_id = $_POST['election_period_id'];
    $adviser_id = $_POST['adviser_id'];
    $section_id = $_POST['section_id'];
    $valid_flag = 1;

    $election_period = $ElectionPeriod->read($election_period_id);


    if($election_period[0]['special_status'] != 'open' || $election_period[0]['status'] != 1) {
        header("Location: ".$CandidacyToken->getBaseUrl()."/adviser/views/student/show.php?id=$student_id&result=Unable to generate token anymore");
        return;
    }

    $token = $student_id.$election_period_id.substr(bin2hex(random_bytes(10)), 0, 10);

    $result = $CandidacyToken->insert($token, $student_id, $election_period_id, $adviser_id, $section_id, $valid_flag);

    if($result['code'] == 'student_have_token') {
        header("Location: ".$CandidacyToken->getBaseUrl()."/adviser/views/student/show.php?id=$student_id&result=Student Have Token");
        return;
    }

    if ($result) {
        if($result['code'] == 'token_exist') {
            // persist
            $token = $student_id.$election_period_id.substr(bin2hex(random_bytes(10)), 0, 10);
            $result = $CandidacyToken->insert($token, $student_id, $election_period_id, $adviser_id, $section_id, $valid_flag);

            if($result) {
                header("Location: ".$CandidacyToken->getBaseUrl()."/adviser/views/student/show.php?id=$student_id&result=".$result['code']);
                return;
            }
        } else {
            header("Location: ".$CandidacyToken->getBaseUrl()."/adviser/views/student/show.php?id=$student_id&result=".$result['code']);
            return;
        }

    } else {
        echo "Error: Something went wrong!";
    }
}
