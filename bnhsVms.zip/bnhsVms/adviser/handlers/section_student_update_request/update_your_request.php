<?php
session_start();

require_once "../../../models/SectionStudentUpdateRequest.php";
require_once "../../../models/SectionStudent.php";
require_once "../../../models/Adviser.php";

$Adviser = new Adviser();
$SectionStudent = new SectionStudent();

if (isset($_POST['update_your_request'])) {
    $adviser_id = isset($_SESSION['adviser_id']) ? $_SESSION['adviser_id'] : NULL;

    $adviser = $Adviser->read($adviser_id);
    $adviser_section_id = $adviser['section_id'];

    $SectionStudentUpdateRequest = new SectionStudentUpdateRequest();

    $type = $_POST['update_your_request'];
    $request_id = $_POST['request_id'];

    $request = $SectionStudentUpdateRequest->read($request_id);

    $student_id = $request['student_id'];
    $current_adviser_id = $request['current_adviser_id'];

    if ($adviser_id != $current_adviser_id) {
        header("Location: " . $Student->getBaseUrl() . "/adviser/views/section_student_update_request/index_your_requests.php?warning=You're not authorized to update this request!");
        return false;
    }

    if ($request['status'] == '0') {
        if ($type == 'cancel') {
            // reject, status = 2
            $resultCancelRequest = $SectionStudentUpdateRequest->updateStatusById(4, $request_id);

            if ($resultCancelRequest) {
                header("Location: " . $SectionStudentUpdateRequest->getBaseUrl() . "/adviser/views/section_student_update_request/index_your_requests.php?result=Request successfully cancelled");
            } else {
                header("Location: " . $SectionStudentUpdateRequest->getBaseUrl() . "/adviser/views/section_student_update_request/index_your_requests.php?warning=Something went wrong!");
            }
        }
    } else {
        header("Location: " . $SectionStudentUpdateRequest->getBaseUrl() . "/adviser/views/section_student_update_request/index_your_requests.php?warning=Cannot update status again");
    }
}
