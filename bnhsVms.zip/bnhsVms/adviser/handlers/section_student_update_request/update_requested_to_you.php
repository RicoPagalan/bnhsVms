<?php
session_start();

require_once "../../../models/SectionStudentUpdateRequest.php";
require_once "../../../models/SectionStudent.php";
require_once "../../../models/Adviser.php";

$Adviser = new Adviser();
$SectionStudent = new SectionStudent();

if (isset($_POST['update_requested_to_you'])) {
    $adviser_id = isset($_SESSION['adviser_id']) ? $_SESSION['adviser_id'] : NULL;

    $adviser = $Adviser->read($adviser_id);
    $adviser_section_id = $adviser['section_id'];

    $SectionStudentUpdateRequest = new SectionStudentUpdateRequest();

    $type = $_POST['update_requested_to_you'];
    $request_id = $_POST['request_id'];

    $request = $SectionStudentUpdateRequest->read($request_id);

    $student_id = $request['student_id'];
    $new_section_id = $request['new_section_id'];

    if ($adviser_section_id != $new_section_id) {
        header("Location: " . $Student->getBaseUrl() . "/adviser/views/section_student_update_request/index_requested_to_you.php?warning=You're not authorized to update this request!");
        return false;
    }

    if ($request['status'] == '0') {
        if ($type == 'accept') {
            // deactivate first all prev section of student
            $deactivationResult = $SectionStudent->deactivateByStudentId($student_id);

            if ($deactivationResult) {
                // insert the new section student
                $insertResult = $SectionStudent->insert($new_section_id, $student_id);

                if ($insertResult) {
                    // update request status to accepted = 1
                    $resultAcceptRequest = $SectionStudentUpdateRequest->updateStatusById(1, $request_id);

                    if ($resultAcceptRequest) {
                        header("Location: " . $SectionStudentUpdateRequest->getBaseUrl() . "/adviser/views/section_student_update_request/index_requested_to_you.php?result=Request successfully accepted");
                    } else {
                        header("Location: " . $SectionStudentUpdateRequest->getBaseUrl() . "/adviser/views/section_student_update_request/index_requested_to_you.php?warning=Something went wrong!");
                    }
                } else {
                    header("Location: " . $SectionStudentUpdateRequest->getBaseUrl() . "/adviser/views/section_student_update_request/index_requested_to_you.php?warning=Something went wrong!");
                }
            } else {
                header("Location: " . $SectionStudentUpdateRequest->getBaseUrl() . "/adviser/views/section_student_update_request/index_requested_to_you.php?warning=Something went wrong!");
            }
        } elseif ($type == 'reject') {
            // reject, status = 2
            $resultRejectRequest = $SectionStudentUpdateRequest->updateStatusById(2, $request_id);

            if ($resultRejectRequest) {
                header("Location: " . $SectionStudentUpdateRequest->getBaseUrl() . "/adviser/views/section_student_update_request/index_requested_to_you.php?result=Request successfully rejected");
            } else {
                header("Location: " . $SectionStudentUpdateRequest->getBaseUrl() . "/adviser/views/section_student_update_request/index_requested_to_you.php?warning=Something went wrong!");
            }
        }
    } else {
        header("Location: " . $SectionStudentUpdateRequest->getBaseUrl() . "/adviser/views/section_student_update_request/index_requested_to_you.php?warning=Cannot update status again");
    }
}
