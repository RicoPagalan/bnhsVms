<?php
session_start();

require_once "../../../models/Student.php";
require_once "../../../models/SectionStudent.php";
require_once "../../../models/Adviser.php";

if(isset($_POST['insert_student'])) {
    $Student = new Student();
    $SectionStudent = new SectionStudent();

    $Adviser = new Adviser();
    $adviser = $Adviser->read($_SESSION['adviser_id']);
    $section_id = $adviser['section_id'];

    if(empty($section_id)) {
        header("Location: ".$Student->getBaseUrl()."/adviser/views/student/index.php?warning=You dont have section!");
        return false;
    }

    $true_student_id = $_POST['true_student_id'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $address = $_POST['address'];
    $birthdate = $_POST['birthdate'];
    $lrn = $_POST['lrn'];
    $email = $_POST['email'];
    $status = $_POST['status'];

    $adviser_id = isset($_SESSION['adviser_id']) ? $_SESSION['adviser_id'] : NULL;

    $student_id = $Student->insert($true_student_id, $first_name, $last_name, $address, $birthdate, $lrn, $email, $status, $adviser_id, $adviser_id);

    if($student_id) {
        $result = $SectionStudent->insert($section_id, $student_id);

        if ($result) {
            header("Location: ".$Student->getBaseUrl()."/adviser/views/student/index.php?message=Student Inserted");
        } else {
            header("Location: ".$Student->getBaseUrl()."/adviser/views/student/index.php?warning=Something went wrong!");
        }
    }

    
}
