<?php
session_start();

require_once "../../../models/Student.php";
require_once "../../../models/SectionStudent.php";
require_once "../../../models/Adviser.php";
require_once "../../../models/SectionStudentUpdateRequest.php";

$Student = new Student();
$SectionStudent = new SectionStudent();
$Adviser = new Adviser();
$SectionStudentUpdateRequest = new SectionStudentUpdateRequest();

if(isset($_POST['update_student'])) {
    $adviser_id = isset($_SESSION['adviser_id']) ? $_SESSION['adviser_id'] : NULL;

    $adviser = $Adviser->read($adviser_id);
    $adviser_section_id = $adviser['section_id'];


    $id = $_POST['id'];

    $current_section_id = $_POST['current_section_id'];
    $new_section_id = $_POST['new_section_id'];

    $true_student_id = $_POST['true_student_id'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $address = $_POST['address'];
    $birthdate = $_POST['birthdate'];
    $lrn = $_POST['lrn'];
    $email = $_POST['email'];
    $status = $_POST['status'];

    if($adviser_section_id != $current_section_id) {
        header("Location: ".$Student->getBaseUrl()."/adviser/views/student/index.php?warning=You're not authorized to update this student!");
        return false;
    }

    $updateResult = $Student->update($id, $true_student_id, $first_name, $last_name, $address, $birthdate, $lrn, $email, $status, $adviser_id, $adviser_id);

    if($updateResult) {
        if($current_section_id !== $new_section_id) {
            // send request to update section of student
            $requestId = $SectionStudentUpdateRequest->insert($id, $adviser_id, $current_section_id, $new_section_id, 0);
            
            if($requestId) {
                header("Location: ".$Student->getBaseUrl()."/adviser/views/student/show.php?id=$id&warning=Student updated & student section update requested!");
            }
        } else {
            header("Location: ".$Student->getBaseUrl()."/adviser/views/student/show.php?id=$id&warning=Student updated!");
        }

    } else {
        header("Location: ".$Student->getBaseUrl()."/adviser/views/student/index.php?warning=Something went wrong!");
    }

    
}
