<?php
session_start();

require_once "../../../models/Student.php";
require_once "../../../models/SectionStudent.php";
require_once "../../../models/Adviser.php";

if (isset($_POST['insert_bulk_csv'])) {
    $Student = new Student();
    $adviser_id = isset($_SESSION['adviser_id']) ? $_SESSION['adviser_id'] : NULL;
    
    $Adviser = new Adviser();
    $adviser = $Adviser->read($adviser_id);
    $section_id = $adviser['section_id'];

    if(empty($section_id)) {
        header("Location: ".$Student->getBaseUrl()."/adviser/views/student/index.php?warning=You dont have section!");
        return false;
    }

    // Check if a file was uploaded
    if (isset($_FILES['student_csv']) && $_FILES['student_csv']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['student_csv']['tmp_name'];
        $fileName = $_FILES['student_csv']['name'];
        $fileSize = $_FILES['student_csv']['size'];
        $fileType = $_FILES['student_csv']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));

        // Validate file extension (must be .csv)
        if ($fileExtension === 'csv') {
            // Open the file in read mode
            if (($handle = fopen($fileTmpPath, "r")) !== FALSE) {
                $rawHeader  = fgetcsv($handle); // Read the first row for headers
                $header = array_map(function($h) {
                    // Remove BOM and white spaces
                    $h = preg_replace('/\xEF\xBB\xBF/', '', $h); // Specifically targeting BOM
                    return trim($h); // Trim other whitespace
                }, $rawHeader);

                $studentsData = []; // Initialize an array to hold all students' data

                // Loop through each row of the file
                while (($rowData = fgetcsv($handle)) !== FALSE) {
                    // Map CSV row to an associative array (column header to value)
                    $studentData = array_combine($header, $rowData);

                    $dateObject = DateTime::createFromFormat('m/d/Y', $studentData['birthdate']);
                    $studentData['birthdate'] = $dateObject ? $dateObject->format('Y-m-d') : null; // Handle invalid dates gracefully

                    $studentData['last_updated_by'] = $adviser_id;
                    $studentData['section_updated_by'] = $adviser_id;

                    $studentsData[] = $studentData; // Add to the main array
                }

                $true_student_ids = array_map(function($item) {
                    return $item['true_student_id'];
                }, $studentsData);

                $lastIdStudent = $Student->insertMany($studentsData);

                if($lastIdStudent) {
                    $query = "SELECT id FROM students WHERE true_student_id IN (".implode(", ", $true_student_ids).")";
                    $student_ids = $Student->findQuery($query);

                    $SectionStudent = new SectionStudent();
                    $lastIdSectionStudent = $SectionStudent->insertMany($section_id, $student_ids);

                    if($lastIdSectionStudent) {
                        echo "Succeed: Inserted students to section";
                    }
                }


                echo $lastIdStudent;

                fclose($handle);
                echo "CSV file has been processed successfully.";
            } else {
                echo "Error opening the file.";
            }
        } else {
            echo "Only CSV files are allowed.";
        }
    } else {
        echo "Error uploading the file.";
    }
} else {
    echo "No form submission detected.";
}
