<?php
include_once '../elements/header.php';
require_once "../../../models/Adviser.php";
require_once "../../../models/Student.php";

$Adviser = new Adviser();
$adviser = $Adviser->read($_SESSION['adviser_id']);

$section_id = $adviser['section_id'];

$Student = new Student();
$section_students = $Student->getStudentsBySection($section_id);

?>

<main>
    <div class="background-white padding-20 radius-5">
        <?php
        if (isset($_GET['warning'])) {
            echo '<p class="align-self-center size-16 color-danger">' . $_GET['warning'] . '</p>';
        }
        ?>
        <div class="flex-row align-center justify-space-between position-relative">
            <h3>Current Advisory</h3>

            <button class="gap-5 background-primary color-white padding-10 radius-5 hover-gray-background flex-row align-center" onclick="toggleDiv('add-student-menu')">
                <span class="material-symbols-outlined size-16">arrow_drop_down</span>
                <p>Add Students</p>
            </button>
            <div class="absolute-dropdown-button-menu toggle-target " id="add-student-menu">
                <a href="<?= $baseUrl ?>/adviser/views/student/create.php?add_type=bulkcsv" class="gap-5 background-success color-white padding-10-40 hover-gray-background flex-row align-center">
                    <span class="material-symbols-outlined size-16">add</span>
                    <p>Bulk by CSV</p>
                </a>
                <a href="<?= $baseUrl ?>/adviser/views/student/create.php?add_type=individual" class="gap-5 background-warning color-white padding-10-40 hover-gray-background flex-row align-center">
                    <span class="material-symbols-outlined size-16">add</span>
                    <p>Individual</p>
                </a>
            </div>
        </div>
        <br>
        <div class="width-fit">
            <div class="show-info-1 gap-20">
                <p class="input-label">Grade Level</p>
                <p class="size-14"><?= $adviser['grade_level'] ?></p>
            </div>
            <div class="show-info-1 gap-20">
                <p class="input-label">Section</p>
                <p class="size-14"><?= $adviser['section_name'] ?></p>
            </div>
            <div class="show-info-1 gap-20">
                <p class="input-label">Status</p>
                <p class="size-14"><?= !empty($adviser['section_status']) ? ($adviser['section_status'] == 1 ? 'Active' : 'Inactive') : '' ?></p>
            </div>
        </div>
        <br><br>
        <h4>Students</h4><br>
        <table class="table table-datatable">
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Student name</th>
                    <th>LRN</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($section_students as $section_student) : ?>
                    <tr>
                        <td><?= $section_student['true_student_id'] ?></td>
                        <td><?= $section_student['first_name'] . " " . $section_student['last_name'] ?></td>
                        <td><?= $section_student['lrn'] ?></td>
                        <td><?= $section_student['email'] ?></td>
                        <td><?= $section_student['status'] == 1 ? 'Active' : 'Inactive' ?></td>
                        <td>
                            <div class="table-action-container">
                                <a href="<?= $Student->getBaseUrl() ?>/adviser/views/student/show.php?id=<?= $section_student["id"] ?>" class="table-action-link background-primary-variant">
                                    <span class="material-symbols-outlined size-16">visibility</span>
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</main>

<script>
    $(".table-datatable").DataTable({
        order: [
            [0, 'asc']
        ]
    })

    function toggleDiv(id) {
        let elem = $("#" + id);

        if (elem.css("display") === "none") {
            elem.show(); // Show the div if it's hidden
        } else {
            elem.hide(); // Hide the div if it's visible
        }
    }
</script>


</body>

</html>