<?php
include_once '../elements/header.php';
require_once "../../../models/Adviser.php";
?>

<?php if($_GET['add_type'] == 'individual'): ?>
<main>
    <div class="background-white padding-20 radius-5">
        <div>
            <h4>Add Student</h4>
        </div>
        <br>
        <form method="POST" action="<?= $baseUrl ?>/adviser/handlers/student/insert.php" class="flex-column">
            <div class="padding-20 flex-column gap-10">
                <div class="flex-column gap-5">
                    <label class="input-label">Student ID</label>
                    <input type="text" class="form-input" name="true_student_id" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">First name</label>
                    <input type="text" class="form-input" name="first_name" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Last name</label>
                    <input type="text" class="form-input" name="last_name" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Address</label>
                    <input type="text" class="form-input" name="address" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Birthdate</label>
                    <input type="date" class="form-input" name="birthdate" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">LRN</label>
                    <input type="text" class="form-input" name="lrn" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Email</label>
                    <input type="email" class="form-input" name="email" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Status</label>
                    <select name="status" class="form-input" required>
                        <option value="1">Active</option>
                        <option value="0">Inactive</option>
                    </select>
                </div>
            </div>
            <div class="flex-row align-stretch gap-10">
                <button type="button" class="button-1 background-gray">CANCEL</button>
                <button class="button-1 background-primary color-white" type="submit" name="insert_student">SAVE</button>
            </div>
        </form>
    </div>
</main>

<?php elseif($_GET['add_type'] == 'bulkcsv'): ?>
    <main>
    <div class="background-white padding-20 radius-5">
        <div>
            <h4>Upload Student List (CSV)</h4>
        </div>
        <br>
        <form method="POST" action="<?= $baseUrl ?>/adviser/handlers/student/insert_bulk_csv.php" enctype="multipart/form-data" class="flex-column">
            <div class="padding-20 flex-column gap-10">
                <div class="flex-column gap-5">
                    <label class="input-label">Upload CSV File</label>
                    <input type="file" class="form-input" name="student_csv" accept=".csv" required>
                </div>
            </div>
            <div class="flex-row align-stretch gap-10">
                <button type="button" class="button-1 background-gray">CANCEL</button>
                <button class="button-1 background-primary color-white" type="submit" name="insert_bulk_csv">UPLOAD</button>
            </div>
        </form>
    </div>
</main>


<?php endif; ?>

</body>

</html>