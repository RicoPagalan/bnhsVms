<?php
require_once "../../../models/Student.php";
require_once "../../../models/ElectionPeriod.php";
require_once "../../../models/CandidacyToken.php";
require_once "../../../models/VotersToken.php";

$Student = new Student();

if (isset($_GET['id']) && !empty($_GET['id'])) {

    $student = $Student->read($_GET['id']);

    if (!$student) {
        header("Location: " . $Student->getBaseUrl() . "/adviser/views/student/index.php?message=No Student Found");
    }

    $election_id = NULL;
    $election_title = 'No open election';
    $candidacy_token_value = '';
    $voters_token_value = '';

    $ElectionPeriod = new ElectionPeriod();
    $openElection = $ElectionPeriod->getElectionSpecialStatus('open');

    if ($openElection) {
        $election_id = $openElection['id'];
        $election_title = $openElection['title'];

        $CandidacyToken = new CandidacyToken();
        $candidacyToken = $CandidacyToken->findByStudentIdElectionId($student['id'], $election_id);

        $VotersToken = new VotersToken();
        $votersToken = $VotersToken->findByStudentIdElectionId($student['id'], $election_id);

        if ($candidacyToken) {
            $candidacy_token_value = $candidacyToken['token'];
        }

        if ($votersToken) {
            $voters_token_value = $votersToken['token'];
        }
    }
} else {
    header("Location: " . $Student->getBaseUrl() . "/adviser/views/student/index.php");
}



include_once '../elements/header.php';

?>

<main>
    <div class="background-white padding-20 radius-5">
        <div>
            <h4>Student Information</h4>
        </div>
        <br><br>
        <div class="grid-1fr-1fr gap-20">
            <div class="width-fit">
                <div class="show-info-1">
                    <p class="input-label">Student ID</p>
                    <p class="size-14"><?= $student['true_student_id'] ?></p>
                </div>
                <div class="show-info-1">
                    <p class="input-label">Name</p>
                    <p class="size-14"><?= $student['first_name'] . ' ' . $student['last_name'] ?></p>
                </div>
                <div class="show-info-1">
                    <p class="input-label">Address</p>
                    <p class="size-14"><?= $student['address'] ?></p>
                </div>
                <div class="show-info-1">
                    <p class="input-label">Birthdate</p>
                    <p class="size-14"><?= $student['birthdate'] ?></p>
                </div>
                <div class="show-info-1">
                    <p class="input-label">LRN</p>
                    <p class="size-14"><?= $student['lrn'] ?></p>
                </div>
                <div class="show-info-1">
                    <p class="input-label">Email</p>
                    <p class="size-14"><?= $student['email'] ?></p>
                </div>
                <div class="show-info-1">
                    <p class="input-label">Grade Level & student</p>
                    <p class="size-14"><?= $student['grade_level'] . ' - ' . $student['section_name'] ?></p>
                </div>
                <div class="show-info-1">
                    <p class="input-label">Status</p>
                    <p class="size-14"><?= $student['status'] == 1 ? 'Active' : 'Inactive' ?></p>
                </div>
            </div>
            <div>
                <div class="width-fit">
                    <div class="flex-column gap-10">
                        <p class="input-label">Candidacy Token for <?php echo $election_title ?></p>
                        <?php if ($candidacy_token_value !== ''): ?>
                            <p class="size-40 padding-5-15 <?= $candidacyToken['valid_flag'] == 0 ? 'background-gray' : 'background-primary-variant' ?>"><?= $candidacy_token_value ?></p>
                            <?php if ($candidacyToken['valid_flag'] == 0): ?>
                                <p class="color-danger size-10">Token in gray indicates invalid token (token may already be used by owner)</p>
                            <?php endif; ?>
                        <?php else: ?>
                            <form method="POST" action="<?= $baseUrl ?>/adviser/handlers/candidacy_token/insert.php" class="flex-column">
                                <input type="hidden" name="student_id" value="<?= $_GET['id'] ?>">
                                <input type="hidden" name="election_period_id" value="<?= $election_id ?>">
                                <input type="hidden" name="adviser_id" value="<?= $_SESSION['adviser_id'] ?>">
                                <input type="hidden" name="section_id" value="<?= $student['section_id'] ?>">
                                <button class="size-40 padding-5-15 background-primary-variant" type="submit" name="insert_candidacy_token">Generate token</button>
                            </form>
                        <?php endif; ?>
                    </div>
                    <br><br><br>
                    <div class="flex-column gap-10">
                        <p class="input-label">Voters Token for <?php echo $election_title ?></p>
                        <?php if ($openElection && $votersToken): ?>
                            <p class="size-40 padding-5-15 <?= $votersToken['valid_flag'] == 0 ? 'background-gray' : 'background-primary-variant' ?>"><?= $voters_token_value ?></p>
                            <?php if ($votersToken['valid_flag'] == 0): ?>
                                <p class="color-danger size-10">Token in gray indicates invalid token (token may already be used by owner for voting)</p>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <br><br>
        <a href="<?= $Student->getBaseUrl() ?>/adviser/views/student/edit.php?id=<?= $student["id"] ?>" class="button-1 background-primary-variant color-white">UPDATE</a>
        <br>
        <br>
    </div>
</main>

</body>

</html>