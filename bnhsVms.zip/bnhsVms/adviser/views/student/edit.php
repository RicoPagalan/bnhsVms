<?php
include_once '../elements/header.php';
require_once "../../../models/Adviser.php";
require_once "../../../models/Section.php";
require_once "../../../models/Student.php";

$Adviser = new Adviser();
$Section = new Section();
$Student = new Student();

if (isset($_GET['id']) && !empty($_GET['id'])) {

    $student = $Student->read($_GET['id']);


    $activeSections = $Section->getActiveSections();
} else {
    header("Location: " . $Adviser->getBaseUrl() . "/admin/views/adviser/index.php");
}
?>

<main>
    <div class="background-white padding-20 radius-5">
        <div>
            <h4>Update Student</h4>
        </div>
        <br>
        <form method="POST" action="<?= $baseUrl ?>/adviser/handlers/student/update.php" class="flex-column">
            <input type="hidden" name="id" value="<?= $student['id'] ?>">
            <input type="hidden" name="current_section_id" value="<?= $student['section_id'] ?>">
            <div class="padding-20 flex-column gap-10">
                <div class="flex-column gap-5">
                    <label class="input-label">Section</label>
                    <select name="new_section_id" class="form-input" required>
                        <option value="<?= $student['section_id'] ?>" selected><?= $student['section_name'] ?></option>
                        <?php foreach ($activeSections as $section): ?>
                            <option value="<?= $section['id'] ?>"><?= $section['name'] ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Student ID</label>
                    <input type="text" class="form-input" value="<?= $student['true_student_id'] ?>" name="true_student_id" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">First name</label>
                    <input type="text" class="form-input" value="<?= $student['first_name'] ?>" name="first_name" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Last name</label>
                    <input type="text" class="form-input" value="<?= $student['last_name'] ?>" name="last_name" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Address</label>
                    <input type="text" class="form-input" value="<?= $student['address'] ?>" name="address" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Birthdate</label>
                    <input type="date" class="form-input" value="<?= $student['birthdate'] ?>" name="birthdate" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">LRN</label>
                    <input type="text" class="form-input" value="<?= $student['lrn'] ?>" name="lrn" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Email</label>
                    <input type="email" class="form-input" value="<?= $student['email'] ?>" name="email" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Status</label>
                    <select name="status" class="form-input" required>
                        <option value="1" <?= $student['status'] == 1 ? 'selected' : '' ?>>Active</option>
                        <option value="0" <?= $student['status'] == 0 ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </div>
            </div>
            <div class="flex-row align-stretch gap-10">
                <button type="button" class="button-1 background-gray">CANCEL</button>
                <button class="button-1 background-primary color-white" type="submit" name="update_student">SAVE</button>
            </div>
        </form>
    </div>
</main>

</body>

</html>