<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['user_type'] != 'adviser' || !$_SESSION['adviser_id']) {
    header("location: ../../../adviser_login.php?accessdenied");
    exit();
}

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'];
$baseUrl = $protocol . $host . "/bnhsVms";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,300,0,0" />
    <link rel="stylesheet" href="../../../assets/css/base.css">

    <script defer src="../../../assets/javascript/index.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>

    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">

    <script defer src="../../../assets/javascript/element-status-colors.js"></script>
</head>

<body>

    <nav class="background-primary">

        <h3 class="color-white align-self-center"></h3>
        <br>
        <br>
        <br>
        <div class="flex-column align-center gap-5 width-100">
            <!-- <a href="dashboard.php" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined size-30">edit_square</span>
                <p class="size-14">Dashboard</p>
            </a> -->
            <a href="<?= $baseUrl ?>/adviser/views/student/index.php" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined size-30">meeting_room</span>
                <p class="size-14">Advisory</p>
            </a>
            <a href="<?= $baseUrl ?>/adviser/views/election_period/index.php" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined size-30">sync_alt</span>
                <p class="size-14">Elections</p>
            </a>
            <a href="<?= $baseUrl ?>/adviser/views/section_student_update_request/index_your_requests.php" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined size-30">pivot_table_chart</span>
                <p class="size-14">Update requests</p>
            </a>
            <!-- <a href="<?= $baseUrl ?>/adviser/views/adviser/index.php" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined size-30">edit_square</span>
                <p class="size-14">Advisers</p>
            </a>
            <a href="<?= $baseUrl ?>/adviser/views/predefined_position/index.php" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined size-30">sync_alt</span>
                <p class="size-14">Predef. Positions</p>
            </a>
            -->
            <!-- <a href="departments.php" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined size-30">meeting_room</span>
                <p class="size-14">Departments</p>
            </a>
            <a href="property_types.php" class="flex-row align-center nav-link gap-5 ">
            <span class="material-symbols-outlined">format_list_bulleted</span>
                <p class="size-14">Property types</p>
            </a>
            <a href="laboratories.php" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined">apartment</span>
                <p class="size-14">Laboratories</p>
            </a>
            <a href="properties.php" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined">category</span>
                <p class="size-14">Properties</p>
            </a>
            <a href="borrow_requests.php" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined">article</span>
                <p class="size-14">Borrow requests</p>
            </a>
            <a href="borrow_logs.php" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined">sync_alt</span>
                <p class="size-14">Borrow logs</p>
            </a>
            <a href="students.php" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined">groups</span>
                <p class="size-14">Students</p>
            </a> -->
            <!-- <a href="scholarships.php" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined size-30">handshake</span>
                <p class="size-14">Scholarships</p>
            </a>
            <a href="requirements.php" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined size-30">article</span>
                <p class="size-14">Requirements</p>
            </a>
            <a href="grantees.php" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined size-30">group</span>
                <p class="size-14">Grantees</p>
            </a>
            <a href="uploads.php" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined size-30">cloud_upload</span>
                <p class="size-14">Uploads</p>
            </a>
            <a href="releases.php" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined size-30">volunteer_activism</span>
                <p class="size-14">Release</p>
            </a>
            <a href="announcements.php" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined size-30">campaign</span>
                <p class="size-14">Announcements</p>
            </a>
            <br>-->
            <a href="<?= $baseUrl ?>/logout.php?user=adviser" class="flex-row align-center nav-link gap-5 ">
                <span class="material-symbols-outlined size-30">logout</span>
                <p class="size-14">Logout</p>
            </a>


        </div>
        <a class="flex-row align-center nav-link gap-5 margin-top-auto">
            <span class="material-symbols-outlined size-30">account_circle</span>
            <p class="size-14"><?= $_SESSION['first_name'] . ' ' . $_SESSION['last_name'] ?></p>
        </a>
        <br>
    </nav>

    <!-- <button data-modal-target="#user-guide-modal" id="open-user-guide-button" class="hover-gray-background">
        <span class="material-symbols-outlined size-30">help</span>
    </button> -->