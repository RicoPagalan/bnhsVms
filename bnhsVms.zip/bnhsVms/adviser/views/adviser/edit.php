<?php
require_once "../../../models/Adviser.php";
require_once "../../../models/Section.php";

if(isset($_GET['id']) && !empty($_GET['id'])) {
    $Adviser = new Adviser();
    $adviser = $Adviser->read($_GET['id']);

    $Section = new Section();
    $availableSections = $Section->getAvailableSectionsForAdviser();

} else {
    header("Location: ".$Adviser->getBaseUrl()."/admin/views/adviser/index.php");
}

include_once '../elements/header.php';

?>

<main>
    <div class="background-white padding-20 radius-5">
        <div>
            <h4>Update Adviser</h4>
        </div>
        <br>
        <form method="POST" action="<?= $baseUrl ?>/admin/handlers/adviser/update.php" class="flex-column">
            <input type="hidden" name="id" value="<?= $adviser['id'] ?>">
            <div class="modal-body padding-20 flex-column gap-10">
                <div class="flex-column gap-5">
                    <label class="input-label">Section advisory</label>
                    <select name="section_id" class="form-input" required>
                        <option value="<?= $adviser['section_id'] ?>" selected><?= $adviser['section_name'] ?></option>
                        <?php foreach($availableSections as $section): ?>
                            <option value="<?= $section['id'] ?>"><?= $section['name'] ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
                
                <div class="flex-column gap-5">
                    <label class="input-label">First name</label>
                    <input type="text" class="form-input" name="first_name" value="<?= $adviser['first_name'] ?>" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Last name</label>
                    <input type="text" class="form-input" name="last_name" value="<?= $adviser['last_name'] ?>" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Birthdate</label>
                    <input type="date" class="form-input" name="birthdate" value="<?= $adviser['birthdate'] ?>" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Email</label>
                    <input type="email" class="form-input" name="email" value="<?= $adviser['email'] ?>" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Status</label>
                    <select name="status" class="form-input" required>
                        <option value="1" <?= $adviser['status'] == 1 ? 'selected' : ''; ?>>Active</option>
                        <option value="0" <?= $adviser['status'] == 0 ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                </div>
            </div>
            <div class="flex-row align-stretch gap-10">
                <a href="<?= $Adviser->getBaseUrl() ?>/admin/views/adviser/show.php?id=<?= $adviser["id"] ?>" class="button-1 background-gray color-black">CANCEL</a>
                <button class="button-1 background-primary color-white" type="submit" name="update_adviser">SAVE</button>
            </div>
        </form>
    </div>
</main>

</body>

</html>