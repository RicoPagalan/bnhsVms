<?php
include_once '../elements/header.php';

require_once "../../../models/Adviser.php";
require_once "../../../models/VotersToken.php";
require_once "../../../models/ElectionPeriod.php";
require_once "../../../models/Student.php";

$Adviser = new Adviser();
$VotersToken = new VotersToken();
$ElectionPeriod = new ElectionPeriod();
$Student = new Student();

$adviser_id = isset($_SESSION['adviser_id']) ? $_SESSION['adviser_id'] : NULL;
$adviser = $Adviser->read($adviser_id);
$section_id = $adviser['section_id'];

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $election_period_id = $_GET['id'];

    $electionPeriod = $ElectionPeriod->read($_GET['id']);

    $studentTokens = $VotersToken->getAllBySectionIdElectionId($section_id, $election_period_id);
    

    $student_ids_withnotokens = $Student->getAllStudentsWithNoVT($section_id, $election_period_id);
} else {
    header("Location: " . $Adviser->getBaseUrl() . "/admin/views/election_period/index.php");
}



?>

<main>
    <div class="background-white padding-bottom-20 radius-5">
        <div class="flex-row align-end gap-20 background-gray">
            <a href="./show.php?id=<?= $_GET['id'] ?>" class="size-14 hover-color-primary-variant padding-20">Election Information</a>
            <a href="./show_applications.php?id=<?= $_GET['id'] ?>" class="size-14 hover-color-primary-variant padding-20">Applications</a>
            <a href="./show_candidates.php?id=<?= $_GET['id'] ?>" class="size-14 hover-color-primary-variant padding-20">Candidates</a>
            <h4 class="padding-20 background-white">Voters token</h4>
        </div>
        <br><br>
        <div class="padding-0-20">
            <?php if(!empty($student_ids_withnotokens)): ?>
                <form method="POST" action="<?= $baseUrl ?>/adviser/handlers/voters_token/generate_bulk.php" class="flex-column">
                    <input type="hidden" name="election_period_id" value="<?= $election_period_id ?>">
                    <button class="button-1 background-success color-white" type="submit" name="generate_bulk">Generate Voters Token for <?= $electionPeriod[0]['title'] ?></button>
                </form>
            <?php endif ?>
            <br>
            <table class="table table-datatable">
                <thead>
                    <tr>
                        <th>Student ID</th>
                        <th>Name</th>
                        <th>Voter Token</th>
                        <th>Valid flag</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($studentTokens as $token) : ?>
                        <tr>
                            <td><?= $token['true_student_id'] ?></td>
                            <td><?= $token['first_name'] . ' ' . $token['last_name'] ?></td>
                            <td><?= $token['token'] ?></td>
                            <td><?= $token['valid_flag'] ?></td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>

    </div>
</main>

<script>
    $(".table-datatable").DataTable({
        order: [
            [0, 'asc']
        ]
    })
</script>

</body>

</html>