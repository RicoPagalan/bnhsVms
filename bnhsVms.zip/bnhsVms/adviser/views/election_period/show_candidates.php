<?php
require_once "../../../models/ElectionPeriodCandidate.php";
require_once "../../../models/Student.php";
$ElectionPeriodCandidate = new ElectionPeriodCandidate();
$Student = new Student();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $election_period_id = $_GET['id'];

    $candidates = $ElectionPeriodCandidate->findAllByElectionId($election_period_id);
} else {
    header("Location: " . $ElectionPeriodCandidate->getBaseUrl() . "/admin/views/election_period/index.php");
}

include_once '../elements/header.php';

?>

<main>
    <div class="background-white padding-bottom-20 radius-5">
        <div class="flex-row align-end gap-20 background-gray">
            <a href="./show.php?id=<?= $_GET['id'] ?>" class="size-14 hover-color-primary-variant padding-20">Election Information</a>
            <a href="./show_applications.php?id=<?= $_GET['id'] ?>" class="size-14 hover-color-primary-variant padding-20">Applications</a>
            <h4 class="padding-20 background-white">Candidates</h4>
            <a href="./voters_token_index.php?id=<?= $_GET['id'] ?>" class="size-14 hover-color-primary-variant  padding-20">Voters token</a>
        </div>
        <br><br>
        <div class="padding-0-20">
            <table class="table table-datatable">
                <thead>
                    <tr>
                        <th>Student ID</th>
                        <th>Name</th>
                        <th>Section</th>
                        <th>Candidacy Token</th>
                        <th>Position</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($candidates as $candidate) : ?>
                        <?php
                        $student = $Student->read($candidate['student_id']);
                        ?>
                        <tr>
                            <td><?= $candidate['true_student_id'] ?></td>
                            <td><?= $candidate['student_first_name'] . ' ' . $candidate['student_last_name'] ?></td>
                            <td><?= $student['grade_level'] . ' ' . $student['section_name'] ?></td>
                            <td><?= $candidate['candidacy_token'] ?></td>
                            <td><?= $candidate['position_title'] ?></td>
                            <td><?= $candidate['valid_flag'] ? 'Valid' : 'Invalid' ?></td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>

    </div>
</main>

<script>
    $(".table-datatable").DataTable({
        order: [
            [0, 'asc']
        ]
    })

    function confirmAndSubmit(application_id, actionType) {
        // Show a confirmation dialog
        let confirmationMessage = actionType === 'accept' ?
            'Are you sure you want to accept this application?' :
            'Are you sure you want to reject this application?';

        if (confirm(confirmationMessage)) {
            // Create a form dynamically
            let form = document.createElement('form');
            form.method = 'POST';
            form.action = '../../handlers/election_period_application/update_application.php'; // Replace with your PHP handler file

            // Create a hidden input to pass the action type (success or danger)
            let input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'update_application';
            input.value = actionType;
            form.appendChild(input);

            let input2 = document.createElement('input');
            input2.type = 'hidden';
            input2.name = 'application_id';
            input2.value = application_id;
            form.appendChild(input2);

            // Append the form to the body and submit
            document.body.appendChild(form);
            form.submit();
        }
    }
</script>

</body>

</html>