<?php
require_once "../../../models/ElectionPeriodApplication.php";
require_once "../../../models/Student.php";
$ElectionPeriodApplication = new ElectionPeriodApplication();
$Student = new Student();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $election_period_id = $_GET['id'];

    $applications = $ElectionPeriodApplication->findAllByElectionId($election_period_id);
} else {
    header("Location: " . $ElectionPeriodApplication->getBaseUrl() . "/admin/views/election_period/index.php");
}

include_once '../elements/header.php';

?>

<main>
    <div class="background-white padding-bottom-20 radius-5">
        <div class="flex-row align-end gap-20 background-gray">
            <a href="./show.php?id=<?= $_GET['id'] ?>" class="size-14 hover-color-primary-variant padding-20">Election Information</a>
            <h4 class="padding-20 background-white">Applications</h4>
            <a href="./show_candidates.php?id=<?= $_GET['id'] ?>" class="size-14 hover-color-primary-variant padding-20">Candidates</a>
            <a href="./voters_token_index.php?id=<?= $_GET['id'] ?>" class="size-14 hover-color-primary-variant  padding-20">Voters token</a>
        </div>
        <br><br>
        <div class="padding-0-20">
            <table class="table table-datatable">
                <thead>
                    <tr>
                        <th>Student ID</th>
                        <th>Name</th>
                        <th>Section</th>
                        <th>Candidacy Token</th>
                        <th>Position</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($applications as $application) : ?>
                        <?php
                        $application_status = '';
                        $application_status_class = '';

                        switch ($application['status']) {
                            case 0:
                                $application_status = 'Pending';
                                $application_status_class = 'color-warning';
                                break;
                            case 1:
                                $application_status = 'Accepted';
                                $application_status_class = 'color-success';
                                break;
                            case 2:
                                $application_status = 'Rejected';
                                $application_status_class = 'color-danger';
                                break;
                            default:
                                $application_status = NULL;
                                break;
                        }

                        $student = $Student->read($application['student_id']);
                        ?>
                        <tr>
                            <td><?= $application['true_student_id'] ?></td>
                            <td><?= $application['student_first_name'] . ' ' . $application['student_last_name'] ?></td>
                            <td><?= $student['grade_level'] . ' ' . $student['section_name'] ?></td>
                            <td><?= $application['candidacy_token'] ?></td>
                            <td><?= $application['position_title'] ?></td>
                            <td class="<?= $application_status_class ?>"><?= $application_status ?></td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>

    </div>
</main>

<script>
    $(".table-datatable").DataTable({
        order: [
            [0, 'asc']
        ]
    })
</script>

</body>

</html>