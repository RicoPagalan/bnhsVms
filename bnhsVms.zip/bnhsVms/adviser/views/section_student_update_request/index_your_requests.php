<?php
include_once '../elements/header.php';
require_once "../../../models/SectionStudentUpdateRequest.php";
require_once "../../../models/Adviser.php";

$Adviser = new Adviser();
$adviser = $Adviser->read($_SESSION['adviser_id']);

$section_id = $adviser['section_id'];


$SectionStudentUpdateRequest = new SectionStudentUpdateRequest();
$requests = $SectionStudentUpdateRequest->getRequestsByCurrentAdviserId($adviser['id']);

?>

<main>
    <div class="background-white padding-20 radius-5">
        <div class="flex-row align-end gap-20 background-gray">
            <a href="./index_your_requests.php" class="size-20 hover-color-primary-variant padding-20 background-white">Your requests</a>
            <a href="./index_requested_to_you.php" class="size-14 hover-color-primary-variant padding-20">Requested to you</a>

        </div>
        <br>
        <div class="flex-column gap-10">
            <p class="size-10">These are your requests to transfer students into other sections.</p>
        </div>
        <br><br>
        <table class="table table-datatable">
            <thead>
                <tr>
                    <th>Student</th>
                    <th>Request by</th>
                    <th>Prev section</th>
                    <th>New section</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($requests as $request) : ?>
                    <?php
                    $status = '';
                    $statusColor = '';
                    switch ($request['status']) {
                        case 0:
                            $status = 'pending';
                            $statusColor = 'color-warning';
                            break;
                        case 1:
                            $status = 'accepted';
                            $statusColor = 'color-success';
                            break;
                        case 2:
                            $status = 'rejected';
                            $statusColor = 'color-danger';
                            break;
                        case 4:
                            $status = 'cancelled';
                            $statusColor = 'color-gray';
                            break;
                        default:
                            $status = 'unknown';
                            break;
                    }
                    ?>
                    <tr>
                        <td><?= $request['student_first_name'] . " " . $request['student_last_name'] ?></td>
                        <td><?= $request['current_adviser_first_name'] . " " . $request['current_adviser_last_name'] ?></td>
                        <td><?= $request['current_sections_grade_level'] . " - " . $request['current_sections_name'] ?></td>
                        <td><?= $request['new_sections_grade_level'] . " - " . $request['new_sections_name'] ?></td>
                        <td class="<?= $statusColor ?>"><?= $status ?></td>
                        <td>
                            <div class="table-action-container">
                                <?php if ($request['status'] == 0): ?>
                                    <button <?= ($request['status'] !== 0) ? 'disabled' : '' ?> class="table-action-link background-primary-variant" onclick="cancelRequest(<?= $request['id'] ?>)">
                                        cancel
                                    </button>
                                <?php endif ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</main>

<script>
    $(".table-datatable").DataTable({
        order: [
            [0, 'asc']
        ]
    })

    function cancelRequest(request_id) {
        // Show a confirmation dialog
        let confirmationMessage = 'Are you sure you want to cancel your update request?';

        if (confirm(confirmationMessage)) {
            // Create a form dynamically
            let form = document.createElement('form');
            form.method = 'POST';
            form.action = '../../handlers/section_student_update_request/update_your_request.php'; // Replace with your PHP handler file

            // Create a hidden input to pass the action type (success or danger)
            let input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'update_your_request';
            input.value = 'cancel';
            form.appendChild(input);

            let input2 = document.createElement('input');
            input2.type = 'hidden';
            input2.name = 'request_id';
            input2.value = request_id;
            form.appendChild(input2);

            // Append the form to the body and submit
            document.body.appendChild(form);
            form.submit();
        }
    }
</script>


</body>

</html>