$(window).on('load', function() {
    let statusElements = $(".status-element");

    statusElements.each(function() {
        switch ($(this).text()) {
            case 'approved':
                $(this).addClass('color-success');
                break;

            case 'active':
                $(this).addClass('color-success');
                break;

            case 'pending':
                $(this).addClass('color-warning');
                break;

            case 'requested':
                $(this).addClass('color-warning');
                break;

            case 'rejected':
                $(this).addClass('color-danger');
                break;

            default:
                break;
        }
    });
});