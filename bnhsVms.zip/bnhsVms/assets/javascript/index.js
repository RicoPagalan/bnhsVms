const openModalButtons = document.querySelectorAll("[data-modal-target]");
const closeModalButtons = document.querySelectorAll("[data-close-button]");
const overlay = document.getElementById("overlay");

openModalButtons.forEach((button) => {
    button.addEventListener("click", () => {
        const modal = document.querySelector(button.dataset.modalTarget);
        openModal(modal);
    });
});

closeModalButtons.forEach((button) => {
    button.addEventListener("click", () => {
        const modal = button.closest(".modal");
        const othermodal = button.closest(".image-viewer-modal");
        const othermodal2 = button.closest(".confirmation-modal");
        closeModal(modal);
        closeModal(othermodal);
        closeModal(othermodal2);
    });
});

try {
    overlay.addEventListener('click', () => {
        const modals = document.querySelectorAll('.modal.active, .image-viewer-modal.active, .confirmation-modal.active')
        modals.forEach(modal => {
            closeModal(modal)
        })
    })
} catch (error) {
    console.log(error);
}



function openModal(modal) {
    if (modal == null) return;
    modal.classList.add("active");
}

function closeModal(modal) {
    if (modal == null) return;
    modal.classList.remove("active");
    overlay.classList.remove("active");
    modal.classList.remove("active-modal-center");
}



function resetForm(button) {
    var form = $(button).closest("form");
    
    form.find("input[type='text'], input[type='number'], select")
        .not(".input-reset-exception")
        .not("input[type='hidden']")
        .each(function() {
            $(this).val("");
        });
}



function reloadPage() {
    window.location.reload()
}

$(".status").each(function() {
    if ($(this).text() === "approved" || $(this).text() === "Approved") {
        $(this).addClass("color-success")
    }else if ($(this).text() === "pending" || $(this).text() === "Pending") {
        $(this).addClass("color-warning")
    }else if ($(this).text() === "cancelled" || $(this).text() === "Cancelled") {
        $(this).addClass("color-danger")
    }
})

let currentPageLink = window.location.href;

$("nav a.nav-link").each(function() {
    if (currentPageLink.includes($(this).attr('href'))) {
        $(this).addClass("active");
    }
});


var numberInputs = document.querySelectorAll('input[type="number"]');

for (var i = 0; i < numberInputs.length; i++) {
    numberInputs[i].setAttribute('step', '0.01');
}

function mainContainerFullSize(button) {
    // Find the span element inside the button
    var span = $(button).find("span");

    // Check the text of the span and toggle it between 'fullscreen' and 'fullscreen_exit'
    if (span.text() === 'fullscreen') {
        $("main").addClass("full-size");
        span.text('fullscreen_exit');
    } else {
        span.text('fullscreen');
        $("main").removeClass("full-size");
    }

    // You can also add your logic for making the main container full size here
    
}

try {
    let sidebarMenuButton = document.getElementById("sidebar-menu-button");

    sidebarMenuButton.addEventListener('click', function() {
        // Correct typo in the method name: getElementsByTagName
        let navbar = document.getElementsByTagName("nav")[0];

        // Check the current display property and toggle it
        if (navbar.style.display === 'flex') {
            this.innerText = "menu";
            navbar.style.display = 'none';
        } else {
            navbar.style.display = 'flex';
            this.innerText = "close";
        }
    });
} catch (error) {
    console.log(error);
    
}


