<?php
require_once 'Model.php';

class ElectionPeriodCandidate extends Model {

    protected $table = "election_period_candidates";

    // public function index() {
    //     if (empty($this->table)) {
    //         throw new Exception('Table name is not defined in the model.');
    //     }

    //     $sql = "SELECT * FROM $this->table";
    //     $stmt = $this->conn->query($sql);

    //     $result = $stmt->fetchAll(); // fetch all the rows

    //     $data = array();
    //     foreach ($result as $row) {
    //         $data[] = $row;
    //     }

    //     return  $data;
    // }


    public function insert($election_period_application_id, $valid_flag)
    {

        $sql = "INSERT INTO $this->table (election_period_application_id, valid_flag) 
                    VALUES (:election_period_application_id, :valid_flag)";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            'election_period_application_id' => $election_period_application_id, 
            'valid_flag' => $valid_flag
        ]);

        $lastInsertedId = $this->conn->lastInsertId();

        if (!empty($lastInsertedId) && $lastInsertedId > 0) {
            return $lastInsertedId;
        } else {
            return false;
        }
    }

    public function findAllByElectionId($election_period_id)
    {
        $sql = "SELECT 
                    election_period_candidates.*,
                    election_period_applications.student_id AS student_id,
                    election_period_applications.candidacy_token_id AS candidacy_token_id,
                    election_period_applications.election_period_id AS election_period_id,
                    election_period_applications.election_period_position_id AS election_period_position_id,
                    election_period_applications.status AS election_period_application_status,
                    students.true_student_id AS true_student_id,
                    students.first_name AS student_first_name,
                    students.last_name AS student_last_name,
                    students.lrn AS lrn,
                    sections.id AS section_id, 
                    sections.grade_level AS grade_level, 
                    sections.name AS section_name,
                    candidacy_tokens.token AS candidacy_token, 
                    election_periods.title AS election_period_title,
                    election_periods.start_date AS start_date,
                    election_periods.end_date AS end_date,
                    election_periods.status AS election_period_status,
                    predefined_positions.position_title AS position_title
                FROM $this->table
                LEFT JOIN election_period_applications ON election_period_applications.id = election_period_candidates.election_period_application_id
                LEFT JOIN students ON students.id = election_period_applications.student_id
                LEFT JOIN section_students ON students.id = section_students.student_id AND section_students.status = 1
                LEFT JOIN sections ON section_students.section_id = sections.id
                LEFT JOIN candidacy_tokens ON candidacy_tokens.id = election_period_applications.candidacy_token_id
                LEFT JOIN election_periods ON election_periods.id = election_period_applications.election_period_id
                LEFT JOIN election_period_positions ON election_period_positions.id = election_period_applications.election_period_position_id
                LEFT JOIN predefined_positions ON predefined_positions.id = election_period_positions.predefined_position_id
                WHERE election_period_applications.election_period_id = :election_period_id AND election_period_candidates.valid_flag = 1";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['election_period_id' => $election_period_id]);
        $result = $stmt->fetchAll();

        return $result;
    }

    public function read($id)
    {
        $sql = "SELECT 
                    election_period_candidates.*,
                    election_period_applications.student_id AS student_id,
                    election_period_applications.candidacy_token_id AS candidacy_token_id,
                    election_period_applications.election_period_id AS election_period_id,
                    election_period_applications.election_period_position_id AS election_period_position_id,
                    election_period_applications.status AS election_period_application_status,
                    students.true_student_id AS true_student_id,
                    students.first_name AS student_first_name,
                    students.last_name AS student_last_name,
                    students.lrn AS lrn,
                    sections.id AS section_id, 
                    sections.grade_level AS grade_level, 
                    sections.name AS section_name,
                    candidacy_tokens.token AS candidacy_token, 
                    election_periods.title AS election_period_title,
                    election_periods.start_date AS start_date,
                    election_periods.end_date AS end_date,
                    election_periods.status AS election_period_status,
                    predefined_positions.position_title AS position_title
                FROM $this->table
                LEFT JOIN election_period_applications ON election_period_applications.id = election_period_candidates.election_period_application_id
                LEFT JOIN students ON students.id = election_period_applications.student_id
                LEFT JOIN section_students ON students.id = section_students.student_id AND section_students.status = 1
                LEFT JOIN sections ON section_students.section_id = sections.id
                LEFT JOIN candidacy_tokens ON candidacy_tokens.id = election_period_applications.candidacy_token_id
                LEFT JOIN election_periods ON election_periods.id = election_period_applications.election_period_id
                LEFT JOIN election_period_positions ON election_period_positions.id = election_period_applications.election_period_position_id
                LEFT JOIN predefined_positions ON predefined_positions.id = election_period_positions.predefined_position_id
                WHERE election_period_candidates.id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['id' => $id]);
        $result = $stmt->fetch();

        return $result;
    }

    // public function update($id, $first_name, $last_name, $birthdate, $email, $status)
    // {
    //     $sql = "UPDATE advisers SET    first_name = :first_name, 
    //                                 last_name = :last_name, 
    //                                 birthdate = :birthdate, 
    //                                 email = :email, 
    //                                 status = :status 
    //                 WHERE id = :id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute([
    //         'id' => $id, 
    //         'first_name' => $first_name, 
    //         'last_name' => $last_name, 
    //         'birthdate' => $birthdate, 
    //         'email' => $email, 
    //         'status' => $status
    //     ]);
    //     return true;
    // }

    // public function delete($id)
    // {
    //     $sql = "DELETE FROM users WHERE id = :id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute(['id' => $id]);
    //     return true;
    // }

    // public function totalRowCount()
    // {
    //     $sql = "SELECT * FROM users";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute([]);
    //     $t_rows = $stmt->rowCount(); // get the total rows
    //     return $t_rows;
    // }
}
