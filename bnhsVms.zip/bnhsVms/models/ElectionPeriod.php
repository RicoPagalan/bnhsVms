<?php
require_once 'Model.php';

class ElectionPeriod extends Model {

    protected $table = "election_periods";

    public function index() {
        if (empty($this->table)) {
            throw new Exception('Table name is not defined in the model.');
        }

        $sql = "SELECT * FROM $this->table";
        $stmt = $this->conn->query($sql);

        $result = $stmt->fetchAll(); // fetch all the rows

        $data = array();
        foreach ($result as $row) {
            $data[] = $row;
        }

        return  $data;
    }


    public function insert($title, $school_year_start, $school_year_end, $start_date, $end_date, $special_status, $status)
    {

        $sql = "INSERT INTO $this->table (title, school_year_start, school_year_end, start_date, end_date, special_status, status) 
                    VALUES (:title, :school_year_start, :school_year_end, :start_date, :end_date, :special_status, :status)";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            'title' => $title, 
            'school_year_start' => $school_year_start, 
            'school_year_end' => $school_year_end , 
            'start_date' => $start_date, 
            'end_date' => $end_date, 
            'special_status' => $special_status,
            'status' => $status
        ]);

        $lastInsertedId = $this->conn->lastInsertId();

        if (!empty($lastInsertedId) && $lastInsertedId > 0) {
            return $lastInsertedId;
        } else {
            return false;
        }
    }

    public function read($id)
    {
        $sql = "SELECT 
                    election_periods.*, 
                    election_period_positions.id as election_period_position_id,
                    predefined_positions.id AS predef_position_id, 
                    predefined_positions.position_title AS position_title, 
                    predefined_positions.order_number AS position_order_number
                FROM $this->table
                LEFT JOIN election_period_positions ON election_periods.id = election_period_positions.election_period_id
                LEFT JOIN predefined_positions ON election_period_positions.predefined_position_id = predefined_positions.id
                WHERE election_periods.id = :id ORDER BY position_order_number asc";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['id' => $id]);
        $result = $stmt->fetchAll();

        return $result;
    }

    public function getElectionSpecialStatus($sp_status)
    {
        $sql = "SELECT *
                FROM $this->table
                WHERE election_periods.special_status = :special_status";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['special_status' => $sp_status]);
        $result = $stmt->fetch();

        return $result;
    }

    public function getActiveElection()
    {
        $sql = "SELECT *
                FROM $this->table
                WHERE election_periods.status = 1";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetch();

        return $result;
    }


    // public function getActive()
    // {
    //     $sql = "SELECT *
    //             FROM $this->table
    //             WHERE election_periods.status = 1";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute();
    //     $result = $stmt->fetch();

    //     return $result;
    // }

    public function update($id, $title, $school_year_start, $school_year_end, $start_date, $end_date, $special_status, $status)
    {

        $sql = "UPDATE $this->table SET
                    title = :title, 
                    school_year_start = :school_year_start, 
                    school_year_end = :school_year_end, 
                    start_date = :start_date, 
                    end_date = :end_date, 
                    special_status = :special_status, 
                    status = :status
                WHERE id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            'id' => $id, 
            'title' => $title, 
            'school_year_start' => $school_year_start, 
            'school_year_end' => $school_year_end , 
            'start_date' => $start_date, 
            'end_date' => $end_date, 
            'special_status' => $special_status,
            'status' => $status
        ]);

        return true;
    }

    // public function delete($id)
    // {
    //     $sql = "DELETE FROM users WHERE id = :id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute(['id' => $id]);
    //     return true;
    // }

    // public function totalRowCount()
    // {
    //     $sql = "SELECT * FROM users";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute([]);
    //     $t_rows = $stmt->rowCount(); // get the total rows
    //     return $t_rows;
    // }
}
