<?php
require_once 'Model.php';

class ElectionPeriodPosition extends Model
{

    protected $table = "election_period_positions";

    // public function index() {
    //     if (empty($this->table)) {
    //         throw new Exception('Table name is not defined in the model.');
    //     }

    //     $sql = "SELECT * FROM $this->table";
    //     $stmt = $this->conn->query($sql);

    //     $result = $stmt->fetchAll(); // fetch all the rows

    //     $data = array();
    //     foreach ($result as $row) {
    //         $data[] = $row;
    //     }

    //     return  $data;
    // }

    public function findAllByElectionId($election_period_id)
    {
        $sql = "SELECT 
                    election_period_positions.*,
                    election_periods.title AS election_period_title,
                    election_periods.start_date AS start_date,
                    election_periods.end_date AS end_date,
                    election_periods.special_status AS election_period_special_status,
                    election_periods.status AS election_period_status,
                    predefined_positions.position_title AS position_title,
                    predefined_positions.order_number AS position_order_number
                FROM $this->table
                LEFT JOIN election_periods ON election_periods.id = election_period_positions.election_period_id
                LEFT JOIN predefined_positions ON predefined_positions.id = election_period_positions.predefined_position_id
                WHERE election_period_positions.election_period_id = :election_period_id AND election_period_positions.status = 1 
                ORDER BY predefined_positions.order_number ASC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['election_period_id' => $election_period_id]);
        $result = $stmt->fetchAll();

        return $result;
    }


    public function insert($election_period_id, $predefined_position_id, $status)
    {
        $sql = "INSERT INTO $this->table (election_period_id, predefined_position_id, status) 
                    VALUES (:election_period_id, :predefined_position_id, :status)";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            'election_period_id' => $election_period_id,
            'predefined_position_id' => $predefined_position_id,
            'status' => $status
        ]);

        $lastInsertedId = $this->conn->lastInsertId();

        if (!empty($lastInsertedId) && $lastInsertedId > 0) {
            return $lastInsertedId;
        } else {
            return false;
        }
    }

    public function insertMany($data)
    {
        $sql = "INSERT INTO $this->table (election_period_id, predefined_position_id, status) VALUES ";

        $placeholders = [];
        $values = [];

        foreach ($data as $row) {
            $placeholders[] = "(?, ?, ?)";

            $values[] = $row['election_period_id'];
            $values[] = $row['predefined_position_id'];
            $values[] = $row['status'];
        }

        $sql .= implode(", ", $placeholders);

        $stmt = $this->conn->prepare($sql);

        try {
            $stmt->execute($values);
            return $this->conn->lastInsertId();
        } catch (PDOException $e) {
            return $e->getMessage();
        }
    }

    public function read($id)
    {
        $sql = "SELECT * FROM $this->table
                    WHERE $this->table.id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['id' => $id]);
        $result = $stmt->fetch(); // fetch single record

        return $result;
    }

    public function update($id, $position_title, $order_number)
    {
        if ($this->checkOrderNumberExist($order_number)) {
            $sql = "UPDATE $this->table SET position_title = :position_title, 
                                        order_number = :order_number 
                        WHERE id = :id";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute([
                'id' => $id,
                'position_title' => $position_title,
                'order_number' => $order_number
            ]);
            return true;
        } else {
            return 'Order number already exists';
        }
    }

    public function delete($id)
    {
        $sql = "DELETE FROM $this->table WHERE id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['id' => $id]);
        return true;
    }

    public function totalRowCount()
    {
        $sql = "SELECT * FROM $this->table";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([]);
        $t_rows = $stmt->rowCount(); // get the total rows
        return $t_rows;
    }

    private function checkOrderNumberExist($order_number)
    {
        $sql = "SELECT * FROM $this->table
                    WHERE $this->table.order_number = :order_number";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['order_number' => $order_number]);
        $result = $stmt->fetch();

        return $result === false ? true : false;
    }
}
