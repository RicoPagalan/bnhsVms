<?php
require_once 'Model.php';

class ElectionVote extends Model {

    protected $table = "election_votes";

    // public function index() {
    //     if (empty($this->table)) {
    //         throw new Exception('Table name is not defined in the model.');
    //     }

    //     $sql = "SELECT * FROM $this->table";
    //     $stmt = $this->conn->query($sql);

    //     $result = $stmt->fetchAll(); // fetch all the rows

    //     $data = array();
    //     foreach ($result as $row) {
    //         $data[] = $row;
    //     }

    //     return  $data;
    // }


    public function insert($student_id, $voters_token_id, $election_period_id, $election_period_candidate_id)
    {

        $sql = "INSERT INTO $this->table (student_id, voters_token_id, election_period_id, election_period_candidate_id, valid_flag) 
                    VALUES (:student_id, :voters_token_id, :election_period_id, :election_period_candidate_id, :valid_flag)";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            'student_id' => $student_id, 
            'voters_token_id' => $voters_token_id, 
            'election_period_id' => $election_period_id, 
            'election_period_candidate_id' => $election_period_candidate_id, 
            'valid_flag' => 1
        ]);

        $lastInsertedId = $this->conn->lastInsertId();

        if (!empty($lastInsertedId) && $lastInsertedId > 0) {
            return $lastInsertedId;
        } else {
            return false;
        }
    }

    public function insertMany($dataArray) {
        $sql = "INSERT INTO $this->table (student_id, voters_token_id, election_period_id, election_period_candidate_id, valid_flag) VALUES ";

        $placeholders = [];
        $values = [];

        foreach ($dataArray as $row) {
            $placeholders[] = "(?, ?, ?, ?, ?)";

            $values[] = $row['student_id'];
            $values[] = $row['voters_token_id'];
            $values[] = $row['election_period_id'];
            $values[] = $row['election_period_candidate_id'];
            $values[] = $row['valid_flag'];
        }

        $sql .= implode(", ", $placeholders);

        $stmt = $this->conn->prepare($sql);

        try {
            $stmt->execute($values);
            return $this->conn->lastInsertId();
        } catch (PDOException $e) {
            return $e->getMessage();
        }
    }

    public function getCandidateVoteCount($election_period_candidate_id) {
        $sql = "select count(*) as vote_count from election_votes where election_period_candidate_id = :election_period_candidate_id and valid_flag = 1";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['election_period_candidate_id' => $election_period_candidate_id]);
        $result = $stmt->fetch();

        $count = $result['vote_count'];

        return $count;
    }

    public function getVotesByTokenId($voters_token_id)
    {
        $sql = "SELECT 
                    election_votes.*,
                    voters_tokens.token,
                    voters_tokens.valid_flag AS voters_token_valid_flag,
                    voters_tokens.is_used AS voters_token_is_used,
                    election_periods.title AS election_period_title,
                    election_periods.start_date AS start_date,
                    election_periods.end_date AS end_date,
                    election_periods.status AS election_period_status,
                    election_period_candidates.election_period_application_id,
                    election_period_candidates.valid_flag AS election_period_candidate_valid_flag,
                    election_period_applications.student_id AS student_id,
                    election_period_applications.candidacy_token_id AS candidacy_token_id,
                    election_period_applications.election_period_id AS election_period_id,
                    election_period_applications.election_period_position_id AS election_period_position_id,
                    election_period_applications.status AS election_period_application_status,
                    students.true_student_id AS true_student_id,
                    students.first_name AS student_first_name,
                    students.last_name AS student_last_name,
                    students.lrn AS lrn,
                    sections.id AS section_id, 
                    sections.grade_level AS grade_level, 
                    sections.name AS section_name,
                    candidacy_tokens.token AS candidacy_token,
                    election_period_positions.count AS position_count,
                    predefined_positions.position_title AS position_title
                FROM $this->table
                LEFT JOIN voters_tokens ON voters_tokens.id = election_votes.voters_token_id
                LEFT JOIN election_periods ON election_periods.id = election_votes.election_period_id
                LEFT JOIN election_period_candidates ON election_period_candidates.id = election_votes.election_period_candidate_id
                LEFT JOIN election_period_applications ON election_period_applications.id = election_period_candidates.election_period_application_id
                LEFT JOIN students ON students.id = election_period_applications.student_id
                LEFT JOIN section_students ON students.id = section_students.student_id AND section_students.status = 1
                LEFT JOIN sections ON section_students.section_id = sections.id
                LEFT JOIN candidacy_tokens ON candidacy_tokens.id = election_period_applications.candidacy_token_id
                LEFT JOIN election_period_positions ON election_period_positions.id = election_period_applications.election_period_position_id
                LEFT JOIN predefined_positions ON predefined_positions.id = election_period_positions.predefined_position_id
                WHERE election_votes.voters_token_id = :voters_token_id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['voters_token_id' => $voters_token_id]);
        $result = $stmt->fetchAll();

        return $result;
    }

    // public function read($id)
    // {
    //     $sql = "SELECT 
    //                 election_periods.*, 
    //                 predefined_positions.id AS predef_position_id, 
    //                 predefined_positions.position_title AS position_title, 
    //                 predefined_positions.order_number AS position_order_number
    //             FROM $this->table
    //             LEFT JOIN election_period_positions ON election_periods.id = election_period_positions.election_period_id
    //             LEFT JOIN predefined_positions ON election_period_positions.predefined_position_id = predefined_positions.id
    //             WHERE election_periods.id = :id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute(['id' => $id]);
    //     $result = $stmt->fetchAll();

    //     return $result;
    // }

    // public function update($id, $first_name, $last_name, $birthdate, $email, $status)
    // {
    //     $sql = "UPDATE advisers SET    first_name = :first_name, 
    //                                 last_name = :last_name, 
    //                                 birthdate = :birthdate, 
    //                                 email = :email, 
    //                                 status = :status 
    //                 WHERE id = :id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute([
    //         'id' => $id, 
    //         'first_name' => $first_name, 
    //         'last_name' => $last_name, 
    //         'birthdate' => $birthdate, 
    //         'email' => $email, 
    //         'status' => $status
    //     ]);
    //     return true;
    // }

    // public function delete($id)
    // {
    //     $sql = "DELETE FROM users WHERE id = :id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute(['id' => $id]);
    //     return true;
    // }

    // public function totalRowCount()
    // {
    //     $sql = "SELECT * FROM users";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute([]);
    //     $t_rows = $stmt->rowCount(); // get the total rows
    //     return $t_rows;
    // }
}
