<?php
require_once 'Model.php';

class VotersToken extends Model
{

    protected $table = "voters_tokens";

    // public function index() {
    //     if (empty($this->table)) {
    //         throw new Exception('Table name is not defined in the model.');
    //     }

    //     $sql = "SELECT * FROM $this->table";
    //     $stmt = $this->conn->query($sql);

    //     $result = $stmt->fetchAll(); // fetch all the rows

    //     $data = array();
    //     foreach ($result as $row) {
    //         $data[] = $row;
    //     }

    //     return  $data;
    // }


    public function insert($token, $student_id, $adviser_id, $section_id, $election_period_id, $valid_flag)
    {

        $sql = "INSERT INTO $this->table (token, student_id, adviser_id, section_id, election_period_id, valid_flag) 
                    VALUES (:token, :student_id, :adviser_id, :section_id, :election_period_id, :valid_flag)";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            'token' => $token,
            'student_id' => $student_id,
            'adviser_id' => $adviser_id,
            'section_id' => $section_id,
            'election_period_id' => $election_period_id,
            'valid_flag' => $valid_flag
        ]);

        $lastInsertedId = $this->conn->lastInsertId();

        if (!empty($lastInsertedId) && $lastInsertedId > 0) {
            return $lastInsertedId;
        } else {
            return false;
        }
    }

    public function insertMany($dataArray)
    {
        $sql = "INSERT INTO $this->table (token, student_id, adviser_id, section_id, election_period_id, valid_flag) VALUES ";

        $placeholders = [];
        $values = [];

        foreach ($dataArray as $row) {
            $placeholders[] = "(?, ?, ?, ?, ?, ?)";

            $values[] = $row['token'];
            $values[] = $row['student_id'];
            $values[] = $row['adviser_id'];
            $values[] = $row['section_id'];
            $values[] = $row['election_period_id'];
            $values[] = $row['valid_flag'];
        }

        $sql .= implode(", ", $placeholders);

        $stmt = $this->conn->prepare($sql);

        try {
            $stmt->execute($values);
            return $this->conn->lastInsertId();
        } catch (PDOException $e) {
            return $e->getMessage();
        }
    }

    public function read($id)
    {
        $sql = "SELECT 
                    voters_tokens.*, 
                    students.true_student_id AS true_student_id,
                    students.first_name AS student_first_name,
                    students.last_name AS student_last_name,
                    students.lrn AS lrn,
                    election_periods.title AS election_period_title,
                    election_periods.start_date AS start_date,
                    election_periods.end_date AS end_date,
                    election_periods.status AS election_period_status,
                    election_periods.special_status AS election_period_special_status
                FROM $this->table
                LEFT JOIN students ON students.id = voters_tokens.student_id
                LEFT JOIN election_periods ON election_periods.id = voters_tokens.election_period_id
                WHERE voters_tokens.id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['id' => $id]);
        $result = $stmt->fetch();

        return $result;
    }

    public function checkTokenIsUsedByToken($token)
    {
        $sql = "SELECT *
                FROM $this->table
                WHERE token = :token AND is_used = 1";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['token' => $token]);
        $result = $stmt->fetch();

        if ($result) {
            return $result; // return true if token already exist
        } else {
            return false;
        }
    }

    public function getAllBySectionIdElectionId($section_id, $election_period_id)
    {
        $sql = "SELECT  voters_tokens.*, 
                        students.true_student_id, 
                        students.first_name,
                        students.last_name
                FROM $this->table
                LEFT JOIN students ON students.id = voters_tokens.student_id
                WHERE section_id = :section_id AND election_period_id = :election_period_id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['section_id' => $section_id, 'election_period_id' => $election_period_id]);
        $result = $stmt->fetchAll();

        return $result;
    }

    public function findByStudentIdElectionId($student_id, $election_period_id)
    {
        $sql = "SELECT *
                FROM $this->table
                WHERE student_id = :student_id AND election_period_id = :election_period_id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['student_id' => $student_id, 'election_period_id' => $election_period_id]);
        $result = $stmt->fetch();

        return $result;
    }

    public function checkTokenExist($token)
    {
        $sql = "SELECT *
                FROM $this->table
                WHERE token = :token";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['token' => $token]);
        $result = $stmt->fetch();

        if ($result) {
            return true; // return true if token already exist
        } else {
            return false;
        }
    }

    public function checkTokenValidityByToken($token)
    {
        $sql = "SELECT *
                FROM $this->table
                WHERE token = :token AND valid_flag = 1";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['token' => $token]);
        $result = $stmt->fetch();

        if ($result) {
            return $result; // return true if token already exist
        } else {
            return false;
        }
    }

    public function checkTokenValidityById($id) {
        $sql = "SELECT *
                FROM $this->table
                WHERE id = :id AND valid_flag = 1";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['id' => $id]);
        $result = $stmt->fetch();

        if ($result) {
            return $result; // return true if token already exist
        } else {
            return false;
        }
    }

    public function invalidateTokenById($id)
    {
        $sql = "UPDATE voters_tokens SET
                                        valid_flag = 0,
                                        is_used = 1
                        WHERE id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            'id' => $id
        ]);

        return true;
    }


    // public function read($id)
    // {
    //     $sql = "SELECT 
    //                 election_periods.*, 
    //                 predefined_positions.id AS predef_position_id, 
    //                 predefined_positions.position_title AS position_title, 
    //                 predefined_positions.order_number AS position_order_number
    //             FROM $this->table
    //             LEFT JOIN election_period_positions ON election_periods.id = election_period_positions.election_period_id
    //             LEFT JOIN predefined_positions ON election_period_positions.predefined_position_id = predefined_positions.id
    //             WHERE election_periods.id = :id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute(['id' => $id]);
    //     $result = $stmt->fetchAll();

    //     return $result;
    // }

    // public function update($id, $first_name, $last_name, $birthdate, $email, $status)
    // {
    //     $sql = "UPDATE advisers SET    first_name = :first_name, 
    //                                 last_name = :last_name, 
    //                                 birthdate = :birthdate, 
    //                                 email = :email, 
    //                                 status = :status 
    //                 WHERE id = :id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute([
    //         'id' => $id, 
    //         'first_name' => $first_name, 
    //         'last_name' => $last_name, 
    //         'birthdate' => $birthdate, 
    //         'email' => $email, 
    //         'status' => $status
    //     ]);
    //     return true;
    // }

    // public function delete($id)
    // {
    //     $sql = "DELETE FROM users WHERE id = :id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute(['id' => $id]);
    //     return true;
    // }

    // public function totalRowCount()
    // {
    //     $sql = "SELECT * FROM users";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute([]);
    //     $t_rows = $stmt->rowCount(); // get the total rows
    //     return $t_rows;
    // }
}
