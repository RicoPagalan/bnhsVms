<?php
require_once 'Model.php';

class SectionStudent extends Model
{

    protected $table = "section_students";

    // public function index()
    // {
    //     if (empty($this->table)) {
    //         throw new Exception('Table name is not defined in the model.');
    //     }

    //     $sql = "SELECT * FROM " . $this->table;
    //     $stmt = $this->conn->query($sql);

    //     $result = $stmt->fetchAll(); // fetch all the rows

    //     $data = array();
    //     foreach ($result as $row) {
    //         $data[] = $row;
    //     }

    //     return  $data;
    // }

    public function insert($section_id, $student_id)
    {

        $sql = "INSERT INTO $this->table (section_id, student_id, status) 
                    VALUES (:section_id, :student_id, 1)";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['section_id' => $section_id, 'student_id' => $student_id]);

        return true;
    }

    public function insertMany($section_id, $studentIds)
    {
        $sql = "INSERT INTO $this->table (section_id, student_id, status) VALUES ";

        $placeholders = [];
        $values = [];

        foreach ($studentIds as $student_id) {
            $placeholders[] = "(?, ?, ?)";

            $values[] = $section_id;
            $values[] = $student_id['id'];
            $values[] = 1;
        }

        $sql .= implode(", ", $placeholders);

        $stmt = $this->conn->prepare($sql);

        try {
            $stmt->execute($values);
            return $this->conn->lastInsertId();
        } catch (PDOException $e) {
            return $e->getMessage();
        }
    }

    // public function read($id)
    // {
    //     $sql = "SELECT * FROM sections WHERE id = :id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute(['id' => $id]);
    //     $result = $stmt->fetch(); // fetch single record

    //     return $result;
    // }

    // public function update($id, $adviser_id, $section_id,)
    // {
    //     $sql = "UPDATE adviser_sections SET adviser_id = :fname, last_name = :lname, email = :email, phone = :phone 
    //                 WHERE id = :id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute(['id' => $id, 'fname' => $fname, 'lname' => $lname, 'email' => $email, 'phone' => $phone]);
    //     return true;
    // }

    // public function deactivateById($id)
    // {
    //     if (is_array($id)) {
    //         $ids = implode(',', array_map('intval', $id));
    //         $sql = "UPDATE adviser_sections SET status = 0
    //                 WHERE id IN ($ids)";
    //         $stmt = $this->conn->prepare($sql);
    //         $stmt->execute();
    //     } else {
    //         $sql = "UPDATE adviser_sections SET status = 0
    //                 WHERE id = :id";
    //         $stmt = $this->conn->prepare($sql);
    //         $stmt->execute(['id' => $id]);
    //     }

    //     return true;
    // }

    public function deactivateByStudentId($student_id)
    {
        $sql = "UPDATE section_students SET status = 0
        WHERE student_id = :student_id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['student_id' => $student_id]);

        return true;
    }

    // public function delete($id)
    // {
    //     $sql = "DELETE FROM users WHERE id = :id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute(['id' => $id]);
    //     return true;
    // }

    // public function totalRowCount()
    // {
    //     $sql = "SELECT * FROM users";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute([]);
    //     $t_rows = $stmt->rowCount(); // get the total rows
    //     return $t_rows;
    // }

    // // available section are those active sections without assigned adviser yet
    // public function getAvailableSectionsForAdviser() {

    //     $sql = "SELECT * FROM sections WHERE status = 1 AND NOT EXISTS (SELECT 1 FROM adviser_sections WHERE sections.id = section_id AND status = 1)";
    //     $stmt = $this->conn->query($sql);

    //     $result = $stmt->fetchAll(); // fetch all the rows

    //     $data = array();
    //     foreach ($result as $row) {
    //         $data[] = $row;
    //     }

    //     return  $data;
    // }
}
