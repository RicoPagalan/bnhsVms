<?php
require_once 'Model.php';

class PredefinedPosition extends Model {

    protected $table = "predefined_positions";

    public function index() {
        if (empty($this->table)) {
            throw new Exception('Table name is not defined in the model.');
        }

        $sql = "SELECT * FROM $this->table";
        $stmt = $this->conn->query($sql);

        $result = $stmt->fetchAll(); // fetch all the rows

        $data = array();
        foreach ($result as $row) {
            $data[] = $row;
        }

        return  $data;
    }


    public function insert($position_title, $order_number)
    {
        if($this->checkOrderNumberExist($order_number)){
            $sql = "INSERT INTO $this->table (position_title, order_number) 
            VALUES (:position_title, :order_number)";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute(['position_title' => $position_title, 'order_number' => $order_number]);

            $lastInsertedId = $this->conn->lastInsertId();

            if (!empty($lastInsertedId) && $lastInsertedId > 0) {
                return $lastInsertedId;
            } else {
                return false;
            }
        } else {
            return 'Order number already exists';
        }
    }

    public function read($id)
    {
        $sql = "SELECT * FROM $this->table
                    WHERE $this->table.id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['id' => $id]);
        $result = $stmt->fetch(); // fetch single record

        return $result;
    }

    public function update($id, $position_title, $order_number)
    {
        if($this->checkOrderNumberExistForUpdate($id, $order_number)){
            $sql = "UPDATE $this->table SET position_title = :position_title, 
                                        order_number = :order_number 
                        WHERE id = :id";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute([
                'id' => $id, 
                'position_title' => $position_title, 
                'order_number' => $order_number
            ]);
            return true;
        } else {
            return 'Order number already exists';
        }
    }

    public function delete($id)
    {
        $sql = "DELETE FROM $this->table WHERE id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['id' => $id]);
        return true;
    }

    public function totalRowCount()
    {
        $sql = "SELECT * FROM $this->table";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([]);
        $t_rows = $stmt->rowCount(); // get the total rows
        return $t_rows;
    }

    private function checkOrderNumberExist($order_number) {
        $sql = "SELECT * FROM $this->table
                    WHERE $this->table.order_number = :order_number";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['order_number' => $order_number]);
        $result = $stmt->fetch();

        return $result === false ? true : false;
    }

    private function checkOrderNumberExistForUpdate($id, $order_number) {
        $sql = "SELECT * FROM $this->table
                    WHERE $this->table.order_number = :order_number AND $this->table.id != $id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['order_number' => $order_number]);
        $result = $stmt->fetch();

        return $result === false ? true : false;
    }
}
