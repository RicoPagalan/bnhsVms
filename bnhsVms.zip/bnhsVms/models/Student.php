<?php
require_once 'Model.php';

class Student extends Model {

    protected $table = "students";

    // public function index() {
    //     if (empty($this->table)) {
    //         throw new Exception('Table name is not defined in the model.');
    //     }

    //     $sql = "SELECT advisers.*, sections.grade_level, sections.name AS section_name
    //                 FROM $this->table
    //                 LEFT JOIN adviser_sections ON advisers.id = adviser_sections.adviser_id
    //                 LEFT JOIN sections ON adviser_sections.section_id = sections.id
    //                 WHERE adviser_sections.status = 1";
    //     $stmt = $this->conn->query($sql);

    //     $result = $stmt->fetchAll(); // fetch all the rows

    //     $data = array();
    //     foreach ($result as $row) {
    //         $data[] = $row;
    //     }

    //     return  $data;
    // }

    public function getStudentsBySection($section_id) {
        if (empty($this->table)) {
            throw new Exception('Table name is not defined in the model.');
        }

        $sql = "SELECT students.*, sections.id AS section_id, sections.grade_level, sections.name AS section_name
                    FROM $this->table
                    LEFT JOIN section_students ON students.id = section_students.student_id
                    LEFT JOIN sections ON section_students.section_id = sections.id
                    WHERE 
                        sections.id = :section_id AND 
                        section_students.status = 1 AND
                        students.status = 1";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['section_id' => $section_id]);
        $result = $stmt->fetchAll(); // fetch all the rows

        $data = array();
        foreach ($result as $row) {
            $data[] = $row;
        }

        return  $data;
    }


    public function insert($true_student_id, $first_name, $last_name, $address, $birthdate, $lrn, $email, $status, $last_updated_by, $section_updated_by)
    {

        $sql = "INSERT INTO students (true_student_id, first_name, last_name, address, birthdate, lrn, email, status, last_updated_by, section_updated_by) 
                    VALUES (:true_student_id, :first_name, :last_name, :address, :birthdate, :lrn, :email, :status, :last_updated_by, :section_updated_by)";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            'true_student_id' => $true_student_id, 
            'first_name' => $first_name, 
            'last_name' => $last_name, 
            'address' => $address, 
            'birthdate' => $birthdate, 
            'lrn' => $lrn, 
            'email' => $email,
            'status' => $status,
            'last_updated_by' => $last_updated_by,
            'section_updated_by' => $section_updated_by
        ]);

        $lastInsertedId = $this->conn->lastInsertId();

        if (!empty($lastInsertedId) && $lastInsertedId > 0) {
            return $lastInsertedId;
        } else {
            return false;
        }
    }

    public function insertMany($data)
    {
        $sql = "INSERT INTO $this->table (true_student_id, first_name, last_name, address, birthdate, lrn, email, status, last_updated_by, section_updated_by) VALUES ";

        $placeholders = [];
        $values = [];

        foreach ($data as $row) {
            $placeholders[] = "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            $values[] = $row['true_student_id'];
            $values[] = $row['first_name'];
            $values[] = $row['last_name'];
            $values[] = $row['address'];
            $values[] = $row['birthdate'];
            $values[] = $row['lrn'];
            $values[] = $row['email'];
            $values[] = 1;
            $values[] = $row['last_updated_by'];
            $values[] = $row['section_updated_by'];
        }

        $sql .= implode(", ", $placeholders);

        $stmt = $this->conn->prepare($sql);

        try {
            $stmt->execute($values);
            return $this->conn->lastInsertId();
        } catch (PDOException $e) {
            return $e->getMessage();
        }
    }

    public function read($id)
    {
        $sql = "SELECT 
                    students.*, 
                    section_students.id AS section_student_id, 
                    sections.id AS section_id, 
                    sections.grade_level, 
                    sections.name AS section_name, 
                    sections.status AS section_status
                FROM $this->table
                LEFT JOIN section_students ON students.id = section_students.student_id AND section_students.status = 1
                LEFT JOIN sections ON section_students.section_id = sections.id
                WHERE students.id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['id' => $id]);
        $result = $stmt->fetch(); // fetch single record

        return $result;
    }

    public function getAllStudentsWithNoVT($section_id, $election_period_id)
    {
        $sql = "SELECT students.id
                FROM $this->table
                WHERE students.id NOT IN (
                    select student_id from voters_tokens
                    where section_id = :section_id_1 and election_period_id = :election_period_id
                ) AND students.id IN (
                    select student_id from section_students 
                    where section_id = :section_id_2 and status = 1
                ) AND students.status = 1";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            'section_id_1' => $section_id, 
            'section_id_2' => $section_id, 
            'election_period_id' => $election_period_id
        ]);
        $result = $stmt->fetchAll();

        $ids = [];

        if($result) {
            foreach($result as $item) {
                $ids[] = $item['id'];
            }
        }

        return $ids;
    }

    public function update($id, $true_student_id, $first_name, $last_name, $address, $birthdate, $lrn, $email, $status, $last_updated_by, $section_updated_by)
    {
        $sql = "UPDATE students SET    
                    true_student_id = :true_student_id, 
                    first_name = :first_name, 
                    last_name = :last_name, 
                    address = :address, 
                    birthdate = :birthdate, 
                    lrn = :lrn, 
                    email = :email, 
                    status = :status, 
                    last_updated_by = :last_updated_by, 
                    section_updated_by = :section_updated_by
                    WHERE id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            'id' => $id, 
            'true_student_id' => $true_student_id, 
            'first_name' => $first_name, 
            'last_name' => $last_name, 
            'address' => $address, 
            'birthdate' => $birthdate, 
            'lrn' => $lrn, 
            'email' => $email, 
            'status' => $status, 
            'last_updated_by' => $last_updated_by, 
            'section_updated_by' => $section_updated_by
        ]);
        return true;
    }

    public function delete($id)
    {
        $sql = "DELETE FROM users WHERE id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['id' => $id]);
        return true;
    }

    public function totalRowCount()
    {
        $sql = "SELECT * FROM users";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([]);
        $t_rows = $stmt->rowCount(); // get the total rows
        return $t_rows;
    }
}
