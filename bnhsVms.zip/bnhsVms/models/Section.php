<?php
require_once 'Model.php';

class Section extends Model {

    protected $table = "sections";

    public function index() {
        if (empty($this->table)) {
            throw new Exception('Table name is not defined in the model.');
        }

        $sql = "SELECT sections.*, advisers.first_name, advisers.last_name
                    FROM $this->table
                    LEFT JOIN adviser_sections ON sections.id = adviser_sections.section_id AND adviser_sections.status = 1
                    LEFT JOIN advisers ON adviser_sections.adviser_id = advisers.id";
        $stmt = $this->conn->query($sql);

        $result = $stmt->fetchAll(); // fetch all the rows

        $data = array();
        foreach ($result as $row) {
            $data[] = $row;
        }

        return  $data;
    }
    
    public function insert($grade_level, $name, $status)
    {

        $sql = "INSERT INTO sections (grade_level, name, status) 
                    VALUES (:grade_level, :name, :status)";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['grade_level' => $grade_level, 'name' => $name, 'status' => $status]);

        return true;
    }

    public function read($id)
    {
        $sql = "SELECT * FROM sections WHERE id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['id' => $id]);
        $result = $stmt->fetch(); // fetch single record

        return $result;
    }

    public function update($id, $grade_level, $name, $status)
    {
        $sql = "UPDATE sections SET grade_level = :grade_level, name = :name, status = :status
                    WHERE id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['id' => $id, 'grade_level' => $grade_level, 'name' => $name, 'status' => $status]);
        return true;
    }

    public function delete($id)
    {
        $sql = "DELETE FROM users WHERE id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['id' => $id]);
        return true;
    }

    public function totalRowCount()
    {
        $sql = "SELECT * FROM users";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([]);
        $t_rows = $stmt->rowCount(); // get the total rows
        return $t_rows;
    }

    // available section are those active sections without assigned adviser yet
    public function getAvailableSectionsForAdviser() {

        $sql = "SELECT * FROM sections WHERE status = 1 AND NOT EXISTS (SELECT 1 FROM adviser_sections WHERE sections.id = section_id AND status = 1)";
        $stmt = $this->conn->query($sql);

        $result = $stmt->fetchAll(); // fetch all the rows

        $data = array();
        foreach ($result as $row) {
            $data[] = $row;
        }

        return  $data;
    }

    public function getActiveSections() {

        $sql = "SELECT * FROM sections WHERE status = 1";
        $stmt = $this->conn->query($sql);

        $result = $stmt->fetchAll(); // fetch all the rows

        $data = array();
        foreach ($result as $row) {
            $data[] = $row;
        }

        return  $data;
    }
}
