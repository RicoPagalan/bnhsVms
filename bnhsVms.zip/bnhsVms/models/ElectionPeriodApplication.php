<?php
require_once 'Model.php';

class ElectionPeriodApplication extends Model
{

    protected $table = "election_period_applications";

    // public function index() {
    //     if (empty($this->table)) {
    //         throw new Exception('Table name is not defined in the model.');
    //     }

    //     $sql = "SELECT * FROM $this->table";
    //     $stmt = $this->conn->query($sql);

    //     $result = $stmt->fetchAll(); // fetch all the rows

    //     $data = array();
    //     foreach ($result as $row) {
    //         $data[] = $row;
    //     }

    //     return  $data;
    // }


    public function insert($student_id, $candidacy_token_id, $election_period_id, $election_period_position_id, $status)
    {

        $sql = "INSERT INTO $this->table (student_id, candidacy_token_id, election_period_id, election_period_position_id, status) 
                    VALUES (:student_id, :candidacy_token_id, :election_period_id, :election_period_position_id, :status)";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            'student_id' => $student_id,
            'candidacy_token_id' => $candidacy_token_id,
            'election_period_id' => $election_period_id,
            'election_period_position_id' => $election_period_position_id,
            'status' => $status
        ]);

        $lastInsertedId = $this->conn->lastInsertId();

        if (!empty($lastInsertedId) && $lastInsertedId > 0) {
            return $lastInsertedId;
        } else {
            return false;
        }
    }

    // private function checkTokenExist($token)
    // {
    //     $sql = "SELECT *
    //             FROM $this->table
    //             WHERE token = :token";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute(['token' => $token]);
    //     $result = $stmt->fetch();

    //     if ($result) {
    //         return true; // return true if token already exist
    //     } else {
    //         return false;
    //     }
    // }

    // private function checkStudentHaveToken($student_id, $election_period_id)
    // {
    //     $sql = "SELECT *
    //             FROM $this->table
    //             WHERE student_id = :student_id AND election_period_id = :election_period_id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute(['student_id' => $student_id, 'election_period_id' => $election_period_id]);
    //     $result = $stmt->fetch();

    //     if ($result) {
    //         return true; // return true if token already exist
    //     } else {
    //         return false;
    //     }
    // }

    // public function findByStudentIdElectionId($student_id, $election_period_id)
    // {
    //     $sql = "SELECT *
    //             FROM $this->table
    //             WHERE student_id = :student_id AND election_period_id = :election_period_id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute(['student_id' => $student_id, 'election_period_id' => $election_period_id]);
    //     $result = $stmt->fetch();

    //     return $result;
    // }

    // public function checkTokenValidity($token) {
    //     $sql = "SELECT *
    //             FROM $this->table
    //             WHERE token = :token AND valid_flag = 1";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute(['token' => $token]);
    //     $result = $stmt->fetch();

    //     if ($result) {
    //         return $result; // return true if token already exist
    //     } else {
    //         return false;
    //     }
    // }


    public function read($id)
    {
        $sql = "SELECT 
                    election_period_applications.*,
                    students.true_student_id AS true_student_id,
                    students.first_name AS student_first_name,
                    students.last_name AS student_last_name,
                    students.lrn AS lrn,
                    candidacy_tokens.token AS candidacy_token, 
                    election_periods.title AS election_period_title,
                    election_periods.start_date AS start_date,
                    election_periods.end_date AS end_date,
                    election_periods.status AS election_period_status,
                    election_periods.special_status AS election_period_special_status,
                    predefined_positions.position_title AS position_title
                FROM $this->table
                LEFT JOIN students ON students.id = election_period_applications.student_id
                LEFT JOIN candidacy_tokens ON candidacy_tokens.id = election_period_applications.candidacy_token_id
                LEFT JOIN election_periods ON election_periods.id = election_period_applications.election_period_id
                LEFT JOIN election_period_positions ON election_period_positions.id = election_period_applications.election_period_position_id
                LEFT JOIN predefined_positions ON predefined_positions.id = election_period_positions.predefined_position_id
                WHERE election_period_applications.id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['id' => $id]);
        $result = $stmt->fetch();

        return $result;
    }

    public function readByToken($token)
    {
        $sql = "SELECT 
                    election_period_applications.*,
                    students.true_student_id AS true_student_id,
                    students.first_name AS student_first_name,
                    students.last_name AS student_last_name,
                    students.lrn AS lrn,
                    candidacy_tokens.token AS candidacy_token, 
                    election_periods.title AS election_period_title,
                    election_periods.start_date AS start_date,
                    election_periods.end_date AS end_date,
                    election_periods.status AS election_period_status,
                    predefined_positions.position_title AS position_title
                FROM $this->table
                LEFT JOIN students ON students.id = election_period_applications.student_id
                LEFT JOIN candidacy_tokens ON candidacy_tokens.id = election_period_applications.candidacy_token_id
                LEFT JOIN election_periods ON election_periods.id = election_period_applications.election_period_id
                LEFT JOIN election_period_positions ON election_period_positions.id = election_period_applications.election_period_position_id
                LEFT JOIN predefined_positions ON predefined_positions.id = election_period_positions.predefined_position_id
                WHERE candidacy_tokens.token = :token";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['token' => $token]);
        $result = $stmt->fetch();

        return $result;
    }

    public function findAllByElectionId($election_period_id)
    {
        $sql = "SELECT 
                    election_period_applications.*,
                    students.true_student_id AS true_student_id,
                    students.first_name AS student_first_name,
                    students.last_name AS student_last_name,
                    students.lrn AS lrn,
                    candidacy_tokens.token AS candidacy_token, 
                    election_periods.title AS election_period_title,
                    election_periods.start_date AS start_date,
                    election_periods.end_date AS end_date,
                    election_periods.status AS election_period_status,
                    predefined_positions.position_title AS position_title
                FROM $this->table
                LEFT JOIN students ON students.id = election_period_applications.student_id
                LEFT JOIN candidacy_tokens ON candidacy_tokens.id = election_period_applications.candidacy_token_id
                LEFT JOIN election_periods ON election_periods.id = election_period_applications.election_period_id
                LEFT JOIN election_period_positions ON election_period_positions.id = election_period_applications.election_period_position_id
                LEFT JOIN predefined_positions ON predefined_positions.id = election_period_positions.predefined_position_id
                WHERE election_period_applications.election_period_id = :election_period_id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['election_period_id' => $election_period_id]);
        $result = $stmt->fetchAll();

        return $result;
    }

    public function updateStatusById($status, $application_id)
    {

        $sql = "UPDATE election_period_applications SET
                                    status = :status 
                    WHERE id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            'id' => $application_id,
            'status' => $status
        ]);

        return true;
    }


    // public function update($id, $first_name, $last_name, $birthdate, $email, $status)
    // {
    //     $sql = "UPDATE advisers SET    first_name = :first_name, 
    //                                 last_name = :last_name, 
    //                                 birthdate = :birthdate, 
    //                                 email = :email, 
    //                                 status = :status 
    //                 WHERE id = :id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute([
    //         'id' => $id, 
    //         'first_name' => $first_name, 
    //         'last_name' => $last_name, 
    //         'birthdate' => $birthdate, 
    //         'email' => $email, 
    //         'status' => $status
    //     ]);
    //     return true;
    // }

    // public function delete($id)
    // {
    //     $sql = "DELETE FROM users WHERE id = :id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute(['id' => $id]);
    //     return true;
    // }

    // public function totalRowCount()
    // {
    //     $sql = "SELECT * FROM users";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute([]);
    //     $t_rows = $stmt->rowCount(); // get the total rows
    //     return $t_rows;
    // }
}
