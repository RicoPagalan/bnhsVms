<?php
require_once 'Model.php';

class SectionStudentUpdateRequest extends Model
{

    protected $table = "section_student_update_requests";

    // public function index()
    // {
    //     if (empty($this->table)) {
    //         throw new Exception('Table name is not defined in the model.');
    //     }

    //     $sql = "SELECT * FROM " . $this->table;
    //     $stmt = $this->conn->query($sql);

    //     $result = $stmt->fetchAll(); // fetch all the rows

    //     $data = array();
    //     foreach ($result as $row) {
    //         $data[] = $row;
    //     }

    //     return  $data;
    // }

    public function getRequestsByNewSectionId($new_section_id) {
        if (empty($this->table)) {
            throw new Exception('Table name is not defined in the model.');
        }

        $sql = "SELECT 
                    section_student_update_requests.*,

                    students.true_student_id, 
                    students.first_name AS student_first_name, 
                    students.last_name AS student_last_name, 
                    students.address AS student_address, 
                    students.birthdate AS student_birthdate, 
                    students.lrn AS student_lrn, 
                    students.email AS student_email, 
                    students.status AS student_status,

                    current_advisers.first_name AS current_adviser_first_name,
                    current_advisers.last_name AS current_adviser_last_name,
                    current_advisers.birthdate AS current_adviser_birthdate,
                    current_advisers.email AS current_adviser_email,
                    current_advisers.status AS current_adviser_status,

                    current_sections.grade_level AS current_sections_grade_level, 
                    current_sections.name AS current_sections_name,
                    current_sections.status AS current_sections_status,

                    new_sections.grade_level AS new_sections_grade_level, 
                    new_sections.name AS new_sections_name,
                    new_sections.status AS new_sections_status,

                    approver_advisers.first_name AS approver_advisers_first_name,
                    approver_advisers.last_name AS approver_advisers_last_name,
                    approver_advisers.birthdate AS approver_advisers_birthdate,
                    approver_advisers.email AS approver_advisers_email,
                    approver_advisers.status AS approver_advisers_status

                    FROM $this->table
                    LEFT JOIN students ON section_student_update_requests.student_id = students.id
                    LEFT JOIN advisers AS current_advisers ON section_student_update_requests.current_adviser_id = current_advisers.id
                    LEFT JOIN sections AS current_sections ON section_student_update_requests.current_section_id = current_sections.id
                    LEFT JOIN sections AS new_sections ON section_student_update_requests.new_section_id = new_sections.id
                    LEFT JOIN advisers AS approver_advisers ON section_student_update_requests.approver_adviser_id = approver_advisers.id
                    WHERE 
                        section_student_update_requests.new_section_id = :new_section_id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['new_section_id' => $new_section_id]);
        $result = $stmt->fetchAll(); // fetch all the rows

        $data = array();
        foreach ($result as $row) {
            $data[] = $row;
        }

        return  $data;
    }

    public function getRequestsByCurrentAdviserId($current_adviser_id) {
        if (empty($this->table)) {
            throw new Exception('Table name is not defined in the model.');
        }

        $sql = "SELECT 
                    section_student_update_requests.*,

                    students.true_student_id, 
                    students.first_name AS student_first_name, 
                    students.last_name AS student_last_name, 
                    students.address AS student_address, 
                    students.birthdate AS student_birthdate, 
                    students.lrn AS student_lrn, 
                    students.email AS student_email, 
                    students.status AS student_status,

                    current_advisers.first_name AS current_adviser_first_name,
                    current_advisers.last_name AS current_adviser_last_name,
                    current_advisers.birthdate AS current_adviser_birthdate,
                    current_advisers.email AS current_adviser_email,
                    current_advisers.status AS current_adviser_status,

                    current_sections.grade_level AS current_sections_grade_level, 
                    current_sections.name AS current_sections_name,
                    current_sections.status AS current_sections_status,

                    new_sections.grade_level AS new_sections_grade_level, 
                    new_sections.name AS new_sections_name,
                    new_sections.status AS new_sections_status,

                    approver_advisers.first_name AS approver_advisers_first_name,
                    approver_advisers.last_name AS approver_advisers_last_name,
                    approver_advisers.birthdate AS approver_advisers_birthdate,
                    approver_advisers.email AS approver_advisers_email,
                    approver_advisers.status AS approver_advisers_status

                    FROM $this->table
                    LEFT JOIN students ON section_student_update_requests.student_id = students.id
                    LEFT JOIN advisers AS current_advisers ON section_student_update_requests.current_adviser_id = current_advisers.id
                    LEFT JOIN sections AS current_sections ON section_student_update_requests.current_section_id = current_sections.id
                    LEFT JOIN sections AS new_sections ON section_student_update_requests.new_section_id = new_sections.id
                    LEFT JOIN advisers AS approver_advisers ON section_student_update_requests.approver_adviser_id = approver_advisers.id
                    WHERE 
                        section_student_update_requests.current_adviser_id = :current_adviser_id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['current_adviser_id' => $current_adviser_id]);
        $result = $stmt->fetchAll(); // fetch all the rows

        $data = array();
        foreach ($result as $row) {
            $data[] = $row;
        }

        return  $data;
    }

    public function insert($student_id, $current_adviser_id, $current_section_id, $new_section_id, $status)
    {

        $sql = "INSERT INTO $this->table (student_id, current_adviser_id, current_section_id, new_section_id, status) 
                    VALUES (:student_id, :current_adviser_id, :current_section_id, :new_section_id, :status)";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            'student_id' => $student_id, 
            'current_adviser_id' => $current_adviser_id,
            'current_section_id' => $current_section_id,
            'new_section_id' => $new_section_id,
            'status' => $status
        ]);

        $lastInsertedId = $this->conn->lastInsertId();

        if (!empty($lastInsertedId) && $lastInsertedId > 0) {
            return $lastInsertedId;
        } else {
            return false;
        }
    }

    public function read($id) {
        if (empty($this->table)) {
            throw new Exception('Table name is not defined in the model.');
        }

        $sql = "SELECT 
                    section_student_update_requests.*,

                    students.true_student_id, 
                    students.first_name AS student_first_name, 
                    students.last_name AS student_last_name, 
                    students.address AS student_address, 
                    students.birthdate AS student_birthdate, 
                    students.lrn AS student_lrn, 
                    students.email AS student_email, 
                    students.status AS student_status,

                    current_advisers.first_name AS current_adviser_first_name,
                    current_advisers.last_name AS current_adviser_last_name,
                    current_advisers.birthdate AS current_adviser_birthdate,
                    current_advisers.email AS current_adviser_email,
                    current_advisers.status AS current_adviser_status,

                    current_sections.grade_level AS current_sections_grade_level, 
                    current_sections.name AS current_sections_name,
                    current_sections.status AS current_sections_status,

                    new_sections.grade_level AS new_sections_grade_level, 
                    new_sections.name AS new_sections_name,
                    new_sections.status AS new_sections_status,

                    approver_advisers.first_name AS approver_advisers_first_name,
                    approver_advisers.last_name AS approver_advisers_last_name,
                    approver_advisers.birthdate AS approver_advisers_birthdate,
                    approver_advisers.email AS approver_advisers_email,
                    approver_advisers.status AS approver_advisers_status

                    FROM $this->table
                    LEFT JOIN students ON section_student_update_requests.student_id = students.id
                    LEFT JOIN advisers AS current_advisers ON section_student_update_requests.current_adviser_id = current_advisers.id
                    LEFT JOIN sections AS current_sections ON section_student_update_requests.current_section_id = current_sections.id
                    LEFT JOIN sections AS new_sections ON section_student_update_requests.new_section_id = new_sections.id
                    LEFT JOIN advisers AS approver_advisers ON section_student_update_requests.approver_adviser_id = approver_advisers.id
                    WHERE 
                        section_student_update_requests.id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['id' => $id]);
        $result = $stmt->fetch(); // fetch all the rows

        return $result;
    }

    public function updateStatusById($status, $request_id)
    {

        $sql = "UPDATE section_student_update_requests SET
                                    status = :status 
                    WHERE id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            'id' => $request_id,
            'status' => $status
        ]);

        return true;
    }

    // public function insertMany($section_id, $studentIds)
    // {
    //     $sql = "INSERT INTO $this->table (section_id, student_id, status) VALUES ";

    //     $placeholders = [];
    //     $values = [];

    //     foreach ($studentIds as $student_id) {
    //         $placeholders[] = "(?, ?, ?)";

    //         $values[] = $section_id;
    //         $values[] = $student_id['id'];
    //         $values[] = 1;
    //     }

    //     $sql .= implode(", ", $placeholders);

    //     $stmt = $this->conn->prepare($sql);

    //     try {
    //         $stmt->execute($values);
    //         return $this->conn->lastInsertId();
    //     } catch (PDOException $e) {
    //         return $e->getMessage();
    //     }
    // }

    // public function read($id)
    // {
    //     $sql = "SELECT * FROM sections WHERE id = :id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute(['id' => $id]);
    //     $result = $stmt->fetch(); // fetch single record

    //     return $result;
    // }

    // public function update($id, $adviser_id, $section_id,)
    // {
    //     $sql = "UPDATE adviser_sections SET adviser_id = :fname, last_name = :lname, email = :email, phone = :phone 
    //                 WHERE id = :id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute(['id' => $id, 'fname' => $fname, 'lname' => $lname, 'email' => $email, 'phone' => $phone]);
    //     return true;
    // }

    // public function deactivateById($id)
    // {
    //     if (is_array($id)) {
    //         $ids = implode(',', array_map('intval', $id));
    //         $sql = "UPDATE adviser_sections SET status = 0
    //                 WHERE id IN ($ids)";
    //         $stmt = $this->conn->prepare($sql);
    //         $stmt->execute();
    //     } else {
    //         $sql = "UPDATE adviser_sections SET status = 0
    //                 WHERE id = :id";
    //         $stmt = $this->conn->prepare($sql);
    //         $stmt->execute(['id' => $id]);
    //     }

    //     return true;
    // }

    // public function delete($id)
    // {
    //     $sql = "DELETE FROM users WHERE id = :id";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute(['id' => $id]);
    //     return true;
    // }

    // public function totalRowCount()
    // {
    //     $sql = "SELECT * FROM users";
    //     $stmt = $this->conn->prepare($sql);
    //     $stmt->execute([]);
    //     $t_rows = $stmt->rowCount(); // get the total rows
    //     return $t_rows;
    // }

    // // available section are those active sections without assigned adviser yet
    // public function getAvailableSectionsForAdviser() {

    //     $sql = "SELECT * FROM sections WHERE status = 1 AND NOT EXISTS (SELECT 1 FROM adviser_sections WHERE sections.id = section_id AND status = 1)";
    //     $stmt = $this->conn->query($sql);

    //     $result = $stmt->fetchAll(); // fetch all the rows

    //     $data = array();
    //     foreach ($result as $row) {
    //         $data[] = $row;
    //     }

    //     return  $data;
    // }
}
