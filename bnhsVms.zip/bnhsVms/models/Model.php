<?php

require_once 'Dbh.php';

class Model extends Dbh {
    public $conn;

    public function __construct() {
        $this->conn = $this->connect();
    }

    public static function getBaseUrl() {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
        $host = $_SERVER['HTTP_HOST'];
        $baseUrl = $protocol . $host . "/bnhsVms";
    
        return $baseUrl;
    }

    public function findQuery($query) {
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll(); // fetch all the rows

        $data = array();
        foreach ($result as $row) {
            $data[] = $row;
        }

        return  $data;
    }

    // return true if unique, not exist yet
    // return false if there's existing
    public function checkUnique($table, $column, $value) {
        $sql = "SELECT 1 FROM $table where $column = :value1";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['value1' => $value]);
        $result = $stmt->fetch(); // fetch single record

        if($result) {
            return false;
        } else {
            return true;
        }
    }
}