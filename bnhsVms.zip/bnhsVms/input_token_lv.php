<?php 
session_start();

    if(isset($_GET['action']) && $_GET['action'] == 'reset') {
        unset($_SESSION['live_viewing_code_verified']);
        unset($_SESSION['live_viewing_ep_id']);
    }
?>

<?php
if (isset($_SESSION['live_viewing_code_verified']) && $_SESSION['live_viewing_code_verified']) {
    header("location: ./election_live_viewing.php");
    exit();
}
?>
<?php
require_once "./models/ElectionPeriod.php";
$ElectionPeriod = new ElectionPeriod();

$activeEP = $ElectionPeriod->getActiveElection();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="" href="./assets/css/base.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>

</head>

<body>
    <img src="./images/voting2.jpg" alt="" class="background-image blur-10">
    <div class="login-container">
        <form action="./live_viewing_token_verify.php" method="POST" class="login-form-container gap-5 height-100">
            <input type="hidden" name="election_period_id" value="<?= $activeEP['id'] ?>">
            <?php
            if (isset($_GET['warning'])) {
                echo '<p class="align-self-center size-16 color-danger">' . $_GET['warning'] . '</p>';
            }
            ?>
            <p class="color-white size-20 border-bottom-1px-grey">View Ongoing Election Live!</p>
            <br>
            <p class="color-white size-30 align-self-center"><?= $activeEP['title'] ?></p>
            <br>
            <div class="flex-column gap-20">
                <div class="flex-column gap-20">
                    <label class="size-14 color-warning align-self-center" id="label-viewing-code">Please enter live viewing credentials</label>
                    <input type="text" name="live_viewing_code" class="form-input-2 background-none color-white size-30" autofocus autocomplete="off" placeholder="Live viewing token">
                </div>
            </div>

            <br><br>
            <div class="m-top-auto flex-column gap-20">
                <input type="submit" value="Submit" name="verify_live_viewing_code" class="weight-600 color-white padding-10 radius-10 background-primary-variant">
            </div>
        </form>
    </div>

    <script>
        // $(document).ready(function() {
        //     setInterval(function() {
        //         $('#label-viewing-code').fadeOut(250).fadeIn(250);
        //     }, 500);
        // });
    </script>

</body>

</html>