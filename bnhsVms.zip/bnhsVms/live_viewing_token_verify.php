<?php

session_start();
require_once "./models/ElectionPeriod.php";

$ElectionPeriod = new ElectionPeriod();

$referer = $_SERVER['HTTP_REFERER'];
$parts = explode('?', $referer, 2);
$cleanUrl = $parts[0];

if (isset($_POST['verify_live_viewing_code']) && isset($_POST['live_viewing_code'])) {
    if (empty($_POST['live_viewing_code'])) {
        header("Location: " . $cleanUrl . "?warning=Please provide token");

        return;
    }

    $live_viewing_code = $_POST['live_viewing_code'];
    $election_period_id = $_POST['election_period_id'];

    $election_period = $ElectionPeriod->read($election_period_id);

    if($election_period) {
        $epStatus = $election_period[0]['status'];
        $epLVC = $election_period[0]['live_viewing_code'];

        if($epStatus == 1) {
            if($epLVC == $live_viewing_code) {
                $_SESSION['live_viewing_code_verified'] = true;
                $_SESSION['live_viewing_ep_id'] = $election_period_id;

                header("Location: ./election_live_viewing.php?token verified");
            } else {
                header("Location: " . $cleanUrl . "?warning=Election period code does not match");
            }
        } else {
            header("Location: " . $cleanUrl . "?warning=Election period is inactive&$epStatus");
        }
    } else {
        header("Location: " . $cleanUrl . "?warning=Election period invalid");
    }
} else {
    header("Location: " . $cleanUrl . "?warning=Invalid request");
}
