<?php
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'];
$baseUrl = $protocol . $host . "/bnhsVms";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" type="" href="<?= $baseUrl ?>/assets/css/base.css">
</head>
<body class="background-primary flex-column align-center justify-center">
    <div class="flex-column align-center gap-10">
        <p class="color-white size-16">Error 404 | Page not found</p>
        <a href="<?= $baseUrl ?>/index.php" class="hover-color-primary-variant">Go to homepage >></a>
    </div>
</body>
</html>