<?php
session_start();
header('Content-Type: text/html');

require_once "./models/ElectionPeriod.php";
require_once "./models/ElectionPeriodPosition.php";
require_once "./models/ElectionPeriodCandidate.php";
require_once "./models/ElectionVote.php";

$ElectionPeriod = new ElectionPeriod();
$ElectionPeriodPosition = new ElectionPeriodPosition();
$ElectionPeriodCandidate = new ElectionPeriodCandidate();
$ElectionVote = new ElectionVote();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['election_period_id'])) {
    $election_period_id = $_POST['election_period_id'];

    // Fetch data from the database
    $electionPeriod = $ElectionPeriod->read($election_period_id);
    $electionPeriodPositions = $ElectionPeriodPosition->findAllByElectionId($election_period_id);
    $electionPeriodCandidates = $ElectionPeriodCandidate->findAllByElectionId($election_period_id);

    // Start output buffering to capture the HTML
    ob_start();

    // Generate the HTML dynamically using PHP
    foreach ($electionPeriodPositions as $position): ?>
        <div class="background-white padding-20 radius-5 flex-column">
            <div class="align-self-center flex-column align-center">
                <p class="size-20 weight-600"><?= htmlspecialchars($position['position_title']) ?></p>
                <p class="size-10">Winners: <?= htmlspecialchars($position['count']) ?></p>
            </div>
            <br><br>
            <div class="flex-column gap-20 padding-20">
                <?php foreach ($electionPeriodCandidates as $candidate): ?>
                    <?php if ($candidate['election_period_position_id'] == $position['id']): ?>
                        <?php
                            $vote_count = $ElectionVote->getCandidateVoteCount($candidate['id'])
                        ?>
                        <div class="voting-candidate-card-2 border-gray">
                            <div class="candidate-avatar-container">
                                <img src="./images/avatar.png" alt="" class="candidate-avatar">
                            </div>
                            <div class="voting-card-info">
                                <p class="size-16 weight-500"><?= htmlspecialchars($candidate['student_first_name'] . ' ' . $candidate['student_last_name']) ?></p>
                                <p class="size-12"><?= htmlspecialchars($candidate['grade_level'] . ' - ' . $candidate['section_name']) ?></p>
                            </div>
                            <div class="margin-left-auto padding-0-15">
                                <p class="size-24"><?= $vote_count ?></p> <!-- Replace this with actual data -->
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
<?php endforeach;

    // Get the generated HTML content
    $html = ob_get_clean();

    // Send the HTML as a response
    echo $html;
}
