<?php
session_start();

if (!isset($_SESSION['candidacy_token_verified']) || !$_SESSION['candidacy_token_verified']) {
    header("location: ./input_token.php?accessdenied");
    exit();
}

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'];
$baseUrl = $protocol . $host . "/bnhsVms";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,300,0,0" />
    <link rel="stylesheet" href="../../../assets/css/base.css">

    <script defer src="../../../assets/javascript/index.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>

    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">

    <script defer src="../../../assets/javascript/element-status-colors.js"></script>
</head>

<body>


<?php
require_once "../../../models/ElectionPeriod.php";

$candidacyToken = $_SESSION['candidacy_token_data'];

$student_id = $candidacyToken['student_id'];
$true_student_id = $candidacyToken['true_student_id'];
$student_first_name = $candidacyToken['student_first_name'];
$student_last_name = $candidacyToken['student_last_name'];
$token = $candidacyToken['token'];
$election_period_title =  $candidacyToken['election_period_title'];
$start_date =  $candidacyToken['start_date'];
$end_date =  $candidacyToken['end_date'];

$candidacy_token_id = $candidacyToken['id'];
$election_period_id = $candidacyToken['election_period_id'];

$ElectionPeriod = new ElectionPeriod();
$electionPeriod = $ElectionPeriod->read($election_period_id);

?>

<main class="candidacy-main-container">
    <div class="background-white padding-20 radius-5">
        <div>
            <h4>File for candidacy</h4>
        </div>
        <br>
        <form method="POST" action="../../handlers/candidacy/insert_application.php" id="electionForm" class="flex-column">
            <input type="hidden" name="student_id" value="<?= $student_id ?>">
            <input type="hidden" name="candidacy_token_id" value="<?= $candidacy_token_id ?>">
            <input type="hidden" name="election_period_id" value="<?= $election_period_id ?>">
            
            <div class="modal-body padding-20 flex-column gap-10">
                <div class="flex-column gap-5">
                    <label class="input-label">Election period</label>
                    <p class="form-input"><?= $election_period_title ?></p>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Election Date</label>
                    <p class="form-input"><?= $start_date.' - '.$end_date?></p>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Student ID</label>
                    <p class="form-input"><?= $true_student_id ?></p>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Student</label>
                    <p class="form-input"><?= $student_first_name.' '.$student_last_name ?></p>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Candidate token</label>
                    <p class="form-input"><?= $token ?></p>
                </div>
            </div>
            <div class="padding-20 flex-column gap-10">
                <div>
                    <h4>Add Positions</h4>
                    <p class="size-12">Select 1 position</p>
                </div>
                <div class="flex-column gap-10">
                    <?php foreach ($electionPeriod as $position): ?>
                        <div class="padding-15 border-gray flex-row align-center gap-10 cursor-pointer hover-green-background" onclick="toggleCheckbox(this)">
                            <input type="radio" name="election_period_position_id" value="<?php echo $position['election_period_position_id']; ?>"  class="position-checkbox" required>
                            <p class="size-14"><?php echo htmlspecialchars($position['position_title']); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>

            </div>
            <br><br>
            <p class="size-12">Please review before submitting</p>
            <br>
            <div class="flex-row align-stretch gap-10">
                <a href="<?= $ElectionPeriod->getBaseUrl() ?>/student/views/candidacy/input_token.php?action=cancel_application" class="button-1 background-primary-variant color-white">CANCEL</a>
                <button class="button-1 background-primary color-white" type="submit" name="insert_application">SAVE</button>
            </div>
        </form>
    </div>
</main>
<br><br><br><br><br><br>

<script>
// Function to toggle checkbox when positions is clicked
function toggleCheckbox(div) {
    var checkbox = div.querySelector('.position-checkbox');

    // Check if the clicked radio button is already selected
    if (checkbox.checked) {
        // If it's already checked, uncheck it and remove the green background
        checkbox.checked = false;
        $(div).removeClass('green-background');
    } else {
        // Deselect all other radio buttons and remove their green background
        var allDivs = document.querySelectorAll('.position-checkbox');
        allDivs.forEach(function(item) {
            item.checked = false;
            item.closest('.padding-15').classList.remove('green-background');
        });

        // Set the clicked radio button as checked and add green background
        checkbox.checked = true;
        $(div).addClass('green-background');
    }
}



</script>

</body>

</html>