<?php
session_start();

if (!isset($_SESSION['election_period_application_id'])) {
    header("location: ./input_token.php?accessdenied");
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,300,0,0" />
    <link rel="stylesheet" href="../../../assets/css/base.css">

    <script defer src="../../../assets/javascript/index.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>

    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">

    <script defer src="../../../assets/javascript/element-status-colors.js"></script>
</head>

<body>


    <?php
    require_once "../../../models/ElectionPeriodApplication.php";
    $ElectionPeriodApplication = new ElectionPeriodApplication();

    $election_period_application_id = $_SESSION['election_period_application_id'];

    $application = $ElectionPeriodApplication->read($election_period_application_id);

    $application_status = '';
    $application_status_class = '';

    switch ($application['status']) {
        case '0':
            $application_status = 'Pending';
            $application_status_class = 'background-warning';
            break;
        case '1':
            $application_status = 'Accepted';
            $application_status_class = 'background-success';
            break;
        case '2':
            $application_status = 'Rejected';
            $application_status_class = 'background-danger';
            break;
        default:
            $application_status = NULL;
            break;
    }
    ?>

    <main class="candidacy-main-container">
        <div class="background-white padding-20 radius-5">
            <div>
                <h4>Election application</h4>
            </div>
            <br>
            <div class="modal-body padding-20 flex-column gap-10">
                <div class="flex-column gap-5">
                    <label class="input-label">Application status</label>
                    <p class="form-input <?= $application_status_class ?>"><?= $application_status ?></p>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Election period</label>
                    <p class="form-input"><?= $application['election_period_title'] ?></p>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Election Date</label>
                    <p class="form-input"><?= $application['start_date'] . ' - ' . $application['end_date'] ?></p>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Student ID</label>
                    <p class="form-input"><?= $application['true_student_id'] ?></p>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Student</label>
                    <p class="form-input"><?= $application['student_first_name'] . ' ' .  $application['student_last_name'] ?></p>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Candidate token</label>
                    <p class="form-input"><?= $application['candidacy_token'] ?></p>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Position</label>
                    <p class="form-input"><?= $application['position_title'] ?></p>
                </div>
            </div>
            <br><br>
            <a href="<?= $ElectionPeriodApplication->getBaseUrl() ?>/student/views/candidacy/input_token.php" class="button-1 background-primary-variant color-white">RETURN</a>
            <br><br>
        </div>
    </main>
    <br><br><br><br><br><br>

    <script>
        // Function to toggle checkbox when positions is clicked
        function toggleCheckbox(div) {
            var checkbox = div.querySelector('.position-checkbox');

            // Check if the clicked radio button is already selected
            if (checkbox.checked) {
                // If it's already checked, uncheck it and remove the green background
                checkbox.checked = false;
                $(div).removeClass('green-background');
            } else {
                // Deselect all other radio buttons and remove their green background
                var allDivs = document.querySelectorAll('.position-checkbox');
                allDivs.forEach(function(item) {
                    item.checked = false;
                    item.closest('.padding-15').classList.remove('green-background');
                });

                // Set the clicked radio button as checked and add green background
                checkbox.checked = true;
                $(div).addClass('green-background');
            }
        }
    </script>

</body>

</html>