<?php
    session_start();
    unset($_SESSION['election_period_application_id']);

    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'];
    $baseUrl = $protocol . $host . "/bnhsVms";
?>

<?php 
    if(isset($_GET['action']) && $_GET['action'] == 'cancel_application') {
        unset($_SESSION['candidacy_token_verified']);
        unset($_SESSION['candidacy_token_data']);
    }
?>

<?php
    if (isset($_SESSION['candidacy_token_verified']) && $_SESSION['candidacy_token_verified']) {
        header("location: ./election_period_application.php");
        exit();
    }
?> 
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="" href="../../../assets/css/base.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>

</head>

<body>
    <img src="../../../images/voting2.jpg" alt="" class="background-image blur-10">
    <div class="login-container">
        <form action="../../handlers/candidacy/verify_candidacy_token.php" method="POST" class="login-form-container gap-5 height-100">
            <?php
            if (isset($_GET['warning'])) {
                echo '<p class="align-self-center size-16 color-danger">' . $_GET['warning'] . '</p>';
            }
            ?>
            <p class="color-white size-20 border-bottom-1px-grey">Election Candidacy</p>
            
            <br>
            <br>
            <div class="flex-column gap-20">
                <div class="flex-column gap-20">
                    <label class="size-14 color-warning align-self-center ">Please enter your candidacy token to begin</label>
                    <input required type="text" name="token" class="form-input-2 background-none color-white size-30" autofocus autocomplete="off" placeholder="Candidacy token">
                </div>
            </div>

            <br><br>
            <div class="m-top-auto flex-column gap-20">
                <input type="submit" value="Submit" name="submit" class="weight-600 color-white padding-10 radius-10 background-primary-variant">
            </div>
        </form>

        <a href="<?= $baseUrl ?>./index.php" class="hover-color-primary-variant"><< back to home</a>
    </div>

    <script>
        function currentTime() {
            let now = new Date();
            let hours = now.getHours();
            let minutes = now.getMinutes();
            let seconds = now.getSeconds();

            let amPmIdentifies = hours <= 12 ? 'AM' : 'PM';

            // Format single-digit minutes and seconds with leading zeros
            let initialHours = hours > 12 ? hours - 12 : hours;
            let formattedHours = initialHours < 10 ? '0' + initialHours : initialHours;
            let formattedMinutes = minutes < 10 ? '0' + minutes : minutes;
            let formattedSeconds = seconds < 10 ? '0' + seconds : seconds;

            let timeString = `${formattedHours}:${formattedMinutes} ${amPmIdentifies}`;

            $("#current-time-container").text(timeString);
        }

        function updateCurrentDate() {
            const currentDateElement = document.getElementById('current-date-container');

            const now = new Date();
            const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

            const dayOfWeek = daysOfWeek[now.getDay()];
            const dayOfMonth = now.getDate();
            const month = months[now.getMonth()];
            const year = now.getFullYear().toString().slice(-2);

            const dateString = `${dayOfWeek}, ${dayOfMonth} ${month} '${year}`;

            // Set the inner text of the element to the formatted date string
            currentDateElement.innerText = dateString;
        }


        setInterval(currentTime, 1000);
        setInterval(updateCurrentDate, 1000);
    </script>

</body>

</html>