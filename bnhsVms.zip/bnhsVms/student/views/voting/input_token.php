<?php
    session_start();
    unset($_SESSION['voting_success_voters_token_id']);

    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'];
    $baseUrl = $protocol . $host . "/bnhsVms";
?>

<?php 
    if(isset($_GET['action']) && $_GET['action'] == 'cancel_application') {
        unset($_SESSION['voters_token_verified']);
        unset($_SESSION['voters_token_data']);
    }
?>

<?php
    if (isset($_SESSION['voters_token_verified']) && $_SESSION['voters_token_verified']) {
        header("location: ./election_votes_create.php");
        exit();
    }
?> 
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="" href="../../../assets/css/base.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>

</head>

<body>
    <img src="../../../images/voting2.jpg" alt="" class="background-image blur-10">
    <div class="login-container">
        <form action="../../handlers/voting/verify_voters_token.php" method="POST" class="login-form-container gap-5 height-100">
            <?php
            if (isset($_GET['warning'])) {
                echo '<p class="align-self-center size-16 color-danger">' . $_GET['warning'] . '</p>';
            }
            ?>
            <p class="color-white size-20 border-bottom-1px-grey">Election Voting</p>
            
            <br>
            <br>
            <div class="flex-column gap-20">
                <div class="flex-column gap-20">
                    <label class="size-14 color-warning align-self-center ">Please enter your voters token to begin</label>
                    <input required type="text" name="voters_token" class="form-input-2 background-none color-white size-30" autofocus autocomplete="off" placeholder="Voters token">
                </div>
            </div>

            <br><br>
            <div class="m-top-auto flex-column gap-20">
                <input type="submit" value="Submit" name="submit" class="weight-600 color-white padding-10 radius-10 background-primary-variant">
            </div>
        </form>

        <a href="<?= $baseUrl ?>./index.php" class="hover-color-primary-variant"><< back to home</a>
    </div>

</body>

</html>