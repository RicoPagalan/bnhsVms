<?php
session_start();

if (!isset($_SESSION['voters_token_verified']) || !$_SESSION['voters_token_verified']) {
    header("location: ./input_token.php?accessdenied");
    exit();
}

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'];
$baseUrl = $protocol . $host . "/bnhsVms";
?>

<?php
require_once "../../../models/ElectionPeriod.php";
require_once "../../../models/ElectionPeriodPosition.php";
require_once "../../../models/ElectionPeriodCandidate.php";

$votersToken = $_SESSION['voters_token_data'];

$student_id = $votersToken['student_id'];
$true_student_id = $votersToken['true_student_id'];
$student_first_name = $votersToken['student_first_name'];
$student_last_name = $votersToken['student_last_name'];
$token = $votersToken['token'];
$election_period_title =  $votersToken['election_period_title'];
$start_date =  $votersToken['start_date'];
$end_date =  $votersToken['end_date'];

$voters_token_id = $votersToken['id'];
$election_period_id = $votersToken['election_period_id'];

$ElectionPeriod = new ElectionPeriod();
$ElectionPeriodPosition = new ElectionPeriodPosition();
$ElectionPeriodCandidate = new ElectionPeriodCandidate();


$electionPeriod = $ElectionPeriod->read($election_period_id);
$electionPeriodPositions = $ElectionPeriodPosition->findAllByElectionId($election_period_id);
$electionPeriodCandidates = $ElectionPeriodCandidate->findAllByElectionId($election_period_id);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,300,0,0" />
    <link rel="stylesheet" href="../../../assets/css/base.css">

    <script defer src="../../../assets/javascript/index.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>

    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">

    <script defer src="../../../assets/javascript/element-status-colors.js"></script>
</head>

<body>

    <main class="candidacy-main-container">
        <div class="align-self-center flex-column align-center">
            <h3>Cast Your Votes</h3>
            <p class="size-16">2024 SSG Election</p>
        </div>
        <?php foreach ($electionPeriodPositions as $position): ?>
            <div class="background-white padding-20 radius-5 flex-column">
                <div class="align-self-center flex-column align-center">
                    <p class="size-20 weight-600"><?= $position['position_title'] ?></p>
                    <p class="size-10">Select <?= $position['count'] ?></p>
                </div>
                <br><br>
                <div class="grid-1fr-1fr-1fr-1fr gap-20 padding-20" id="position-<?= $position['id'] ?>" data-count="<?= $position['count'] ?>">
                    <?php foreach ($electionPeriodCandidates as $candidate): ?>
                        <?php if ($candidate['election_period_position_id'] == $position['id']): ?>
                            <div class="voting-candidate-card border-gray" data-id="<?= $candidate['id'] ?>">
                                <div class="candidate-avatar-container">
                                    <img src="../../../images/avatar.png" alt="" class="candidate-avatar">
                                </div>
                                <div class="voting-card-info">
                                    <p class="size-16 weight-500"><?= $candidate['student_first_name'] . ' ' . $candidate['student_last_name'] ?></p>
                                    <p class="size-12"><?= $candidate['grade_level'] . ' - ' . $candidate['section_name'] ?></p>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <div class="background-white padding-20 radius-5 flex-column">
            <p class="size-12 color-warning">Please review your selections above before proceeding</p>
            <br>
            <div class="flex-row gap-10 align-center">
                <input type="checkbox" required class="cursor-pointer">
                <p>I understand that my vote cannot be changed once it has been submitted, meaning that after casting my vote, it becomes final and irreversible.</p>
            </div>

            <br>
        </div>

        <div class="flex-row align-stretch gap-10 justify-end">
            <a href="<?= $ElectionPeriod->getBaseUrl() ?>/student/views/voting/input_token.php?action=cancel_application" class="button-1 background-primary-variant color-white">CANCEL</a>
            <button class="button-1-large background-success color-white" id="submit_vote">SUBMIT</button>
        </div>
    </main>
    <br><br><br><br><br><br>

    <script>
        $(document).ready(function() {
            // Object to store selected candidates
            let selectedCandidates = {};

            // Loop through each position group
            $('div[id^="position-"]').each(function() {
                const positionId = $(this).attr('id'); // Get the id of the position div
                const count = $(this).data('count'); // Get the count from the data attribute

                // Initialize the structure for each position id
                selectedCandidates[positionId] = {
                    count: count, // Set the count from the data attribute
                    ids: [] // Initialize an empty array for ids
                };
            });

            $('.voting-candidate-card').on('click', function() {
                const cardId = $(this).data('id');
                const positionId = $(this).closest('div[id^="position-"]').attr('id');
                const count = $(this).closest('div[id^="position-"]').data('count');

                let selectedPositionCandidateLength = selectedCandidates[positionId]['ids'].length;

                // Find the currently selected candidate in the same position group
                const currentlySelected = $(`#${positionId} .voting-candidate-card.selected`);
                const selectedIds = [];

                currentlySelected.each(function() {
                    const id = $(this).data('id'); // Get the data-id attribute
                    selectedIds.push(id); // Push it into the array
                });

                // Check if the clicked card is already selected
                if (selectedIds.includes(cardId)) {
                    // If it's already selected, unselect it
                    $(this).removeClass('selected').addClass('unselected');
                    selectedCandidates[positionId]['ids'] = selectedCandidates[positionId]['ids'].filter(id => id !== cardId);
                    console.log("here1");

                } else {
                    console.log("here 2222");
                    // Check if the current count of selected candidates is less than the required
                    if (selectedPositionCandidateLength < count) {
                        // Add the clicked card as selected
                        $(this).addClass('selected').removeClass('unselected');
                        selectedCandidates[positionId]['ids'].push(cardId); // Add the candidate ID to the array
                    } else {
                        // Current count equals required count, so pop the last added candidate
                        const lastCandidateId = selectedCandidates[positionId]['ids'].pop(); // Remove the last selected candidate
                        // Find the corresponding card and unselect it
                        $(`#${positionId} .voting-candidate-card[data-id="${lastCandidateId}"]`).removeClass('selected').addClass('unselected');

                        // Add the currently clicked card as selected
                        $(this).addClass('selected').removeClass('unselected');
                        selectedCandidates[positionId]['ids'].push(cardId); // Add the new candidate ID to the array
                    }
                }

                // console.log('Selected Candidates:', selectedCandidates);
            });

            $('#submit_vote').on('click', function() {
                let warningMessages = []; // Initialize an array to hold warning messages

                // Loop through each selectedCandidates
                for (let positionId in selectedCandidates) {
                    const candidateData = selectedCandidates[positionId];
                    const {
                        count,
                        ids
                    } = candidateData; // Destructure to get count and ids

                    // Check if the length of ids is less than the count
                    if (ids.length < count) {
                        warningMessages.push(`Warning: Position ${positionId} has only ${ids.length} selected candidates but requires ${count}.`);
                    }
                }

                // If there are warning messages, display them
                if (warningMessages.length > 0) {
                    alert(warningMessages.join('\n')); // You can change this to your preferred method of displaying warnings
                } else {
                    // Proceed with the voting process if no warnings
                    console.log("All checks passed. Proceeding with the vote.");

                    let url = '<?= $baseUrl ?>' + '/student/handlers/voting/insert_vote.php'
                    requestData = selectedCandidates
                    // send ajax request
                    $.ajax({
                        url: url,
                        type: 'POST',
                        data: {
                            candidates: selectedCandidates,
                            student_id: <?= $student_id ?>,
                            voters_token_id: <?= $voters_token_id ?>,
                            election_period_id: <?= $election_period_id ?>,
                        },
                        dataType: 'json',
                        success: function(response) {
                            if (response.error_code) {
                                switch (response.error_code) {
                                    case 'empty':
                                        alert(response.message)
                                        break;
                                    case 'invalid_token':
                                        alert(response.message)
                                        break;
                                    case 'unknown':
                                        alert(response.message)
                                        break;
                                    case 'token_invalidation_error':
                                        alert(response.message)
                                        break;
                                    case 'not_started':
                                        alert(response.message)
                                        break;
                                }
                            } else if (response.result) {
                                alert(response.result)

                                window.location.href = '<?= $baseUrl ?>' + '/student/views/voting/view_election_period_vote.php'
                            }
                        },
                        error: function(xhr, status, error) {
                            // Handle error
                            console.error('Error fetching data:', error);
                            alert('An error occurred while fetching data.'); // Display an alert on error
                        }
                    });
                }
            });


        });
    </script>

</body>

</html>