<?php
session_start();

if (!isset($_SESSION['voting_success_voters_token_id'])) {
    header("location: ./input_token.php?accessdenied");
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,300,0,0" />
    <link rel="stylesheet" href="../../../assets/css/base.css">

    <script defer src="../../../assets/javascript/index.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>

    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">

    <script defer src="../../../assets/javascript/element-status-colors.js"></script>
</head>

<body>


    <?php

    require_once "../../../models/VotersToken.php";
    require_once "../../../models/ElectionVote.php";
    require_once "../../../models/ElectionPeriodPosition.php";
    $VotersToken = new VotersToken();
    $ElectionVote = new ElectionVote();
    $ElectionPeriodPosition = new ElectionPeriodPosition();

    $voters_token_id = $_SESSION['voting_success_voters_token_id'];

    $votersToken = $VotersToken->read($voters_token_id);

    $token = $votersToken['token'];

    $true_student_id = $votersToken['true_student_id'];
    $student_first_name = $votersToken['student_first_name'];
    $student_last_name = $votersToken['student_last_name'];
    $lrn = $votersToken['lrn'];

    $election_period_title = $votersToken['election_period_title'];
    $start_date = $votersToken['start_date'];
    $end_date = $votersToken['end_date'];
    $election_period_status = $votersToken['election_period_status'];
    $election_period_id = $votersToken['election_period_id'];

    $electionPeriodPositions = $ElectionPeriodPosition->findAllByElectionId($election_period_id);

    $votes = $ElectionVote->getVotesByTokenId($voters_token_id);

    ?>

    <main class="candidacy-main-container">
        <div class="background-white padding-20 radius-5">
            <div>
                <h4>Vote information</h4>
            </div>
            <br>
            <div class="modal-body padding-20 flex-column gap-10">
                <div class="flex-column gap-5">
                    <label class="input-label">Token</label>
                    <p class="form-input"><?= $token ?></p>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Voter's name</label>
                    <p class="form-input"><?= $student_first_name . ' ' . $student_last_name ?></p>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Election period</label>
                    <p class="form-input"><?= $election_period_title ?></p>
                </div>
            </div>
            <br>
            <h3>You selected the following:</h3>
            <br>
            <?php foreach ($electionPeriodPositions as $position): ?>
                <div class="background-white padding-20 radius-5 flex-column border-top-2px-grey">
                    <div class="">
                        <p class="size-20 weight-600"><?= $position['position_title'] ?></p>
                        <p class="size-10">Select <?= $position['count'] ?></p>
                    </div>
                    <div class="grid-1fr-1fr-1fr-1fr gap-20 padding-20" id="position-<?= $position['id'] ?>" data-count="<?= $position['count'] ?>">
                        <?php foreach ($votes as $vote): ?>
                            <?php if ($vote['election_period_position_id'] == $position['id']): ?>
                                <div class="voting-candidate-card border-gray" data-id="<?= $vote['id'] ?>">
                                    <div class="candidate-avatar-container">
                                        <img src="../../../images/avatar.png" alt="" class="candidate-avatar">
                                    </div>
                                    <div class="voting-card-info">
                                        <p class="size-16 weight-500"><?= $vote['student_first_name'] . ' ' . $vote['student_last_name'] ?></p>
                                        <p class="size-12"><?= $vote['grade_level'] . ' - ' . $vote['section_name'] ?></p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
                <br>
            <?php endforeach; ?>
            <br><br>
            <a href="<?= $ElectionVote->getBaseUrl() ?>/student/views/voting/input_token.php" class="button-1 background-primary-variant color-white">RETURN</a>
            <br><br>
        </div>
    </main>
    <br><br><br><br><br><br>

    <script>
        // Function to toggle checkbox when positions is clicked
        function toggleCheckbox(div) {
            var checkbox = div.querySelector('.position-checkbox');

            // Check if the clicked radio button is already selected
            if (checkbox.checked) {
                // If it's already checked, uncheck it and remove the green background
                checkbox.checked = false;
                $(div).removeClass('green-background');
            } else {
                // Deselect all other radio buttons and remove their green background
                var allDivs = document.querySelectorAll('.position-checkbox');
                allDivs.forEach(function(item) {
                    item.checked = false;
                    item.closest('.padding-15').classList.remove('green-background');
                });

                // Set the clicked radio button as checked and add green background
                checkbox.checked = true;
                $(div).addClass('green-background');
            }
        }
    </script>

</body>

</html>