<?php

session_start();
require_once "../../../models/CandidacyToken.php";
require_once "../../../models/ElectionPeriodApplication.php";

$referer = $_SERVER['HTTP_REFERER'];
$parts = explode('?', $referer, 2);
$cleanUrl = $parts[0];

if (isset($_POST['submit']) && isset($_POST['token'])) {
    if (empty($_POST['token'])) {
        header("Location: " . $cleanUrl . "?warning=Please provide token");
    }

    $CandidacyToken = new CandidacyToken();

    $token = $_POST['token'];

    $token_exist = $CandidacyToken->checkTokenExist($token);

    if ($token_exist) {

        $validity = $CandidacyToken->checkTokenValidityByToken($token); // check if token is valid

        if ($validity) {
            // if valid, get token data (student owner, and to what election)

            $token_id = $validity['id'];

            $candidacyToken = $CandidacyToken->read($token_id);

            if ($candidacyToken['election_period_status'] == 1 && $candidacyToken['election_period_special_status'] == 'open') {
                $_SESSION['candidacy_token_verified'] = true;
                $_SESSION['candidacy_token_data'] = $candidacyToken;

                header("Location: ../../views/candidacy/election_period_application.php?token verified");
            } else {
                header("Location: " . $cleanUrl . "?warning=Cannot use token anymore");
            }
        } else {
            $token_is_used = $CandidacyToken->checkTokenIsUsedByToken($token);

            if ($token_is_used) {
                $ElectionPeriodApplication = new ElectionPeriodApplication();
                $application = $ElectionPeriodApplication->readByToken($token);

                unset($_SESSION['candidacy_token_verified']);
                unset($_SESSION['candidacy_token_data']);

                $_SESSION['election_period_application_id'] = $application['id'];

                header("Location: ../../views/candidacy/view_election_period_application.php?Application");
            } else {
                header("Location: " . $cleanUrl . "?warning=Token invalid");
            }
        }
    } else {
        header("Location: " . $cleanUrl . "?warning=Token doesn't exist");
    }
}
