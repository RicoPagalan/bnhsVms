<?php 

session_start();
require_once "../../../models/ElectionPeriodApplication.php";
require_once "../../../models/CandidacyToken.php";
require_once "../../../models/ElectionPeriod.php";

if(isset($_POST['insert_application'])) {
    $ElectionPeriodApplication = new ElectionPeriodApplication();
    $CandidacyToken = new CandidacyToken();
    $ElectionPeriod = new ElectionPeriod();

    $student_id = $_POST['student_id'];
    $candidacy_token_id = $_POST['candidacy_token_id'];
    $election_period_id = $_POST['election_period_id'];
    $election_period_position_id = $_POST['election_period_position_id'];
    $status = 0;

    $election_period = $ElectionPeriod->read($election_period_id);

    if($election_period[0]['special_status'] != 'open' || $election_period[0]['status'] != 1) {
        header("Location: ../../views/candidacy/input_token.php?action=cancel_application&Token Invalid");
        return;
    }

    // check token if valid by id
    $tokenValidity = $CandidacyToken->checkTokenValidityById($candidacy_token_id);

    if($tokenValidity) {
        // if token valid, insert election application
        $result = $ElectionPeriodApplication->insert($student_id, $candidacy_token_id, $election_period_id, $election_period_position_id, $status);

        if($result) {
            // after insert into application, invalidate the token (because token is one-time-use only)
            $invalidationResult = $CandidacyToken->invalidateTokenById($candidacy_token_id);

            if($invalidationResult) {
                // if successfull invalidation of token, clear the session on candidacy token then redirect to input_token.php
                if (isset($_SESSION['candidacy_token_verified']) || isset($_SESSION['candidacy_token_data'])) {
                    unset($_SESSION['candidacy_token_verified']);
                    unset($_SESSION['candidacy_token_data']);

                    $_SESSION['election_period_application_id'] = $result;

                    header("Location: ../../views/candidacy/view_election_period_application.php?Your Application is filed");
                }
            } else {
                if (isset($_SESSION['candidacy_token_verified']) || isset($_SESSION['candidacy_token_data'])) {
                    unset($_SESSION['candidacy_token_verified']);
                    unset($_SESSION['candidacy_token_data']);

                    header("Location: ../../views/candidacy/input_token.php?Something went wrong");
                }
            }
        } else {
            if (isset($_SESSION['candidacy_token_verified']) || isset($_SESSION['candidacy_token_data'])) {
                unset($_SESSION['candidacy_token_verified']);
                unset($_SESSION['candidacy_token_data']);

                header("Location: ../../views/candidacy/input_token.php?Something went wrong");
            }
        }
    } else {
        if (isset($_SESSION['candidacy_token_verified']) || isset($_SESSION['candidacy_token_data'])) {
            unset($_SESSION['candidacy_token_verified']);
            unset($_SESSION['candidacy_token_data']);

            header("Location: ../../views/candidacy/input_token.php?Token Invalid");
        }
    }

}