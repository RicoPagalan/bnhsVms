<?php

session_start();
require_once "../../../models/VotersToken.php";
require_once "../../../models/ElectionPeriodApplication.php";

$referer = $_SERVER['HTTP_REFERER'];
$parts = explode('?', $referer, 2);
$cleanUrl = $parts[0];

if (isset($_POST['submit']) && isset($_POST['voters_token'])) {
    if (empty($_POST['voters_tokenvoters_token'])) {
        header("Location: " . $cleanUrl . "?warning=Please provide token");
    }

    $VotersToken = new VotersToken();

    $token = $_POST['voters_token'];

    $token_exist = $VotersToken->checkTokenExist($token);

    if ($token_exist) {

        $validity = $VotersToken->checkTokenValidityByToken($token); // check if token is valid

        if ($validity) {
            // if valid, get token data (student owner, and to what election)

            $token_id = $validity['id'];

            $votersToken = $VotersToken->read($token_id);

            if ($votersToken['election_period_status'] == 1 && $votersToken['election_period_special_status'] == 'ongoing') {
                $_SESSION['voters_token_verified'] = true;
                $_SESSION['voters_token_data'] = $votersToken;

                header("Location: ../../views/voting/election_votes_create.php?token verified");
            } else {
                header("Location: " . $cleanUrl . "?warning=Election period expired or not yet started&");
            }
        } else {
            $token_is_used = $VotersToken->checkTokenIsUsedByToken($token);

            if ($token_is_used) {

                $token_id = $token_is_used['id'];

                unset($_SESSION['voters_token_verified']);
                unset($_SESSION['voters_token_data']);

                $_SESSION['voting_success_voters_token_id'] = $token_id;

                header("Location: ../../views/voting/view_election_period_vote.php?Voting");
            } else {
                header("Location: " . $cleanUrl . "?warning=Token invalid");
            }
        }
    } else {
        header("Location: " . $cleanUrl . "?warning=Token doesn't exist");
    }
}
