<?php
session_start();
header('Content-Type: application/json');

require_once "../../../models/ElectionPeriodCandidate.php";
require_once "../../../models/ElectionVote.php";
require_once "../../../models/VotersToken.php";
require_once "../../../models/ElectionPeriod.php";
$ElectionPeriodCandidate = new ElectionPeriodCandidate();
$ElectionVote = new ElectionVote();
$VotersToken = new VotersToken();
$ElectionPeriod = new ElectionPeriod();

// sleep(1);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['candidates'])) {
    $selectedCandidates = $_POST['candidates'];
    $student_id = $_POST['student_id'];
    $voters_token_id = $_POST['voters_token_id'];
    $election_period_id = $_POST['election_period_id'];

    $election_period = $ElectionPeriod->read($election_period_id);

    if($election_period[0]['special_status'] != 'ongoing' || $election_period[0]['status'] != 1) {
        $response = array(
            "error_code" => "not_started", 
            "message" => "Election not ongoing for now"
        );
        echo json_encode($response);
        return;
    }

    $dataArray = [];

    $candidate_names = [];

    $tokenValidity = $VotersToken->checkTokenValidityById($voters_token_id);

    if ($tokenValidity) {
        // Process the selected candidates as needed (e.g., save to database)
        foreach ($selectedCandidates as $positionId => $data) {
            $count = $data['count'];
            $ids = $data['ids'];

            foreach ($ids as $id) {

                $dataArray[] = [
                    'student_id' => $student_id,
                    'voters_token_id' => $voters_token_id,
                    'election_period_id' => $election_period_id,
                    'election_period_candidate_id' => $id,
                    'valid_flag' => 1
                ];

                $candidate = $ElectionPeriodCandidate->read($id);
                $candidate_names[] = $candidate['student_first_name'] . ' ' . $candidate['student_last_name'];
            }
        }


        $lastId = $ElectionVote->insertMany($dataArray);

        if ($lastId) {
            // if vote added, invalidate the voters token

            $invalidationResult = $VotersToken->invalidateTokenById($voters_token_id);

            if ($invalidationResult) {
                $response = array(
                    "result" => "Successfully saved votes",
                    'student_id' =>  $student_id,
                    'voters_token_id' =>  $voters_token_id,
                    'election_period_id' =>  $election_period_id,
                    'candidate_names' => $candidate_names
                );

                if (isset($_SESSION['voters_token_verified'])) {
                    unset($_SESSION['voters_token_verified']);
                }

                $_SESSION['voting_success_voters_token_id'] = $voters_token_id;

                echo json_encode($response);
            } else {
                $response = array(
                    "error_code" => "token_invalidation_error",
                    "message" => "Unable to invalidate voters token"
                );

                echo json_encode($response);
            }
        } else {
            $response = array(
                "error_code" => "unknown", 
                "message" => "Unknown error occured"
            );

            echo json_encode($response);
        }
    } else {
        $response = array(
            "error_code" => "invalid_token", 
            "message" => "Token is invalid"
        );

        echo json_encode($response);
        
    }
} else {
    $response = array(
        "error_code" => "empty", 
        "message" => "No candidates data received."
    );
    echo json_encode($response);
}
