<?php
include_once 'header.php';
require_once '../database_connection.php';


?>


<main>
    <div class="main-header-title">
        <div class="flex-row gap-10 align-center">
            <h3>Dashboard</h3>
        </div>
        <div class="flex-row gap-20 align-center">
            <?php include_once 'user_profile_and_links_container.php'; ?>
        </div>
    </div>
    <div class="grid-1fr-1fr media-grid-1fr gap-10">
        <div class="background-white padding-10 radius-5 flex-column gap-10">
            <div class="flex-row media-flex-column media-align-center align-center gap-20">
                <img src="../uploads/nmsc-logo-stroked.png" alt="" class="large-image-profile">
                <div class="flex-column media-text-align-center gap-20">
                    <p class="weight-600 size-20 color-blue">Welcome to NMSCST <br> <span class="size-30">Property Borrowing System!</span> </p>
                    <p class="size-16">We're delighted to have you on board! </p>
                </div>
            </div>
            <br>
            <p class="size-10 color-gray">If you have any questions, check out our helpful documentation or reach out to our team. <br> We're here to assist you every step of the way.</p>
        </div>

        <div class="background-white media-gap-10 flex-column padding-10 radius-5">
            <p class="weight-500 size-16">All departments data</p>
            <div class="padding-20 grid-1fr-1fr-1fr-1fr">
                <div class="flex-column align-center">
                    <h3 class="size-48 color-blue"><?= $allCourses ?></h3>
                    <p class="text-align-center">Courses</p>
                </div>
                <div class="flex-column align-center">
                    <h3 class="size-48 color-blue"><?= $allDepartmentsStudents ?></h3>
                    <p class="text-align-center">registered<br>students</p>
                </div>
                <div class="flex-column align-center">
                    <h3 class="size-48 color-blue"><?= $allDepartmentsProperties ?></h3>
                    <p class="text-align-center">Total properties</p>
                </div>
                <div class="flex-column align-center">
                    <h3 class="size-48 color-blue"><?= $allDepartmentsTransactions ?></h3>
                    <p class="text-align-center">Transactions</p>
                </div>
            </div>


            <div class="flex-row margin-top-auto align-center justify-space-between color-gray">
                <p class="weight-500">NMSCST, Labuyo</p>
                <div class="flex-row align-center gap-5">
                    <p>As of</p>
                    <p id="current-time-container"></p>
                    <p id="current-date-container"></p>
                </div>
            </div>
        </div>
    </div>
    <div class="flex-row align-center media-grid-1fr-1fr gap-10">
        <?php foreach ($departments as $department) :
            $this_department_id = $department['department_id'];

            $sqlTotalStudents = "SELECT COUNT(*) as total_students FROM student_view WHERE department_id = $this_department_id";
            $resultTotalStudents = mysqli_query($conn, $sqlTotalStudents);
            $totalStudents = mysqli_fetch_assoc($resultTotalStudents)['total_students'];

            $sqlTotalProperties = "SELECT COUNT(*) as total_properties FROM property_view WHERE department_id = $this_department_id";
            $resultTotalProperties = mysqli_query($conn, $sqlTotalProperties);
            $totalProperties = mysqli_fetch_assoc($resultTotalProperties)['total_properties'];

            $sqlTotalRequests = "SELECT COUNT(*) as total_requests FROM borrow_request_view WHERE property_department_id = $this_department_id";
            $resultTotalRequests = mysqli_query($conn, $sqlTotalRequests);
            $totalRequests = mysqli_fetch_assoc($resultTotalRequests)['total_requests'];

            $sqlTotalTransactions = "SELECT COUNT(*) as total_transactions FROM borrow_log_view WHERE property_department_id = $this_department_id";
            $resultTotalTransactions = mysqli_query($conn, $sqlTotalTransactions);
            $totalTransactions = mysqli_fetch_assoc($resultTotalTransactions)['total_transactions'];

            $sqlTotalUnreturned = "SELECT COUNT(*) as total_unreturned FROM borrow_log_view WHERE is_returned = 'no' AND property_department_id = $this_department_id";
            $resultTotalUnreturned = mysqli_query($conn, $sqlTotalUnreturned);
            $totalUnreturned = mysqli_fetch_assoc($resultTotalUnreturned)['total_unreturned'];
        ?>
            <a href="properties.php?department_id=<?= $department['department_id'] ?>" class="radius-5 hover-gray-background hover-flip background-white padding-10 flex-column gap-10 color-black width-100">
                <p class="size-20 weight-600"><?= $department['department_acronym'] ?></p>
                <div class="flex-row align-center gap-10 color-blue">
                    <h3 class="size-48"><?= $totalProperties ?></h3>
                    <p>properties</p>
                </div>
                <div class="flex-column">
                    <div class="flex-row align-center justify-space-between">
                        <p class="color-gray">Registered students</p>
                        <p class="weight-500 size-16"><?= $totalStudents ?></p>
                    </div>
                    <div class="flex-row align-center justify-space-between">
                        <p class="color-gray">Borrow requests</p>
                        <p class="weight-500 size-16"><?= $totalRequests ?></p>
                    </div>
                    <div class="flex-row align-center justify-space-between">
                        <p class="color-gray">Borrow transactions</p>
                        <p class="weight-500 size-16"><?= $totalTransactions ?></p>
                    </div>
                    <div class="flex-row align-center justify-space-between">
                        <p class="color-gray">Unreturned properties</p>
                        <p class="weight-500 size-16"><?= $totalUnreturned ?></p>
                    </div>
                </div>

            </a>
        <?php endforeach ?>
    </div>


    <div class="grid-2fr-1fr media-flex-column">
        <div class="background-white padding-10 radius-5">
            <p class="weight-500">Recent transactions</p>
            <table class="table width-100">
                <thead>
                    <tr>
                        <th>Borrower</th>
                        <th>Model</th>
                        <th>Date borrowed</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($borrowLogs as $borrowLog) : ?>
                        <tr>
                            <td><?= $borrowLog['first_name'] . ' ' .  $borrowLog['last_name'] ?></td>
                            <td class="td-overflowing-wrap"><?= $borrowLog['model'] ?></td>
                            <td><?= $borrowLog['date_borrowed'] ?></td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>

    <br>
</main>


<script>
    function currentTime() {
        let now = new Date();
        let hours = now.getHours();
        let minutes = now.getMinutes();
        let seconds = now.getSeconds();

        let amPmIdentifies = hours <= 12 ? 'AM' : 'PM';

        // Format single-digit minutes and seconds with leading zeros
        let initialHours = hours > 12 ? hours - 12 : hours;
        let formattedHours = initialHours < 10 ? '0' + initialHours : initialHours;
        let formattedMinutes = minutes < 10 ? '0' + minutes : minutes;
        let formattedSeconds = seconds < 10 ? '0' + seconds : seconds;

        let timeString = `${formattedHours}:${formattedMinutes} ${amPmIdentifies}`;

        $("#current-time-container").text(timeString);
    }

    function updateCurrentDate() {
        const currentDateElement = document.getElementById('current-date-container');

        const now = new Date();
        const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

        const dayOfWeek = daysOfWeek[now.getDay()];
        const dayOfMonth = now.getDate();
        const month = months[now.getMonth()];
        const year = now.getFullYear().toString().slice(-2);

        const dateString = `${dayOfWeek}, ${dayOfMonth} ${month} '${year}`;

        // Set the inner text of the element to the formatted date string
        currentDateElement.innerText = dateString;
    }


    setInterval(currentTime, 1000);
    setInterval(updateCurrentDate, 1000);
</script>



</body>

</html>