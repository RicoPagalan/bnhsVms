<?php
require_once "../../../models/ElectionPeriodApplication.php";
require_once "../../../models/Student.php";
$ElectionPeriodApplication = new ElectionPeriodApplication();
$Student = new Student();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $election_period_id = $_GET['id'];

    $applications = $ElectionPeriodApplication->findAllByElectionId($election_period_id);
} else {
    header("Location: " . $ElectionPeriodApplication->getBaseUrl() . "/admin/views/election_period/index.php");
}

include_once '../elements/header.php';

?>

<main>
    <div class="background-white padding-20 radius-5">
        <div class="flex-row align-end gap-20">
            <a href="./show.php?id=<?= $_GET['id'] ?>" class="size-14 hover-color-primary-variant">Election Information</a>
            <h4>Applications</h4>
            <a href="./show_candidates.php?id=<?= $_GET['id'] ?>" class="size-14 hover-color-primary-variant">Candidates</a>
        </div>
        <br><br>
        <table class="table table-datatable">
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Section</th>
                    <th>Candidacy Token</th>
                    <th>Position</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($applications as $application) : ?>
                    <?php
                    $application_status = '';
                    $application_status_class = '';

                    switch ($application['status']) {
                        case 0:
                            $application_status = 'Pending';
                            $application_status_class = 'color-warning';
                            break;
                        case 1:
                            $application_status = 'Accepted';
                            $application_status_class = 'color-success';
                            break;
                        case 2:
                            $application_status = 'Rejected';
                            $application_status_class = 'color-danger';
                            break;
                        default:
                            $application_status = NULL;
                            break;
                    }

                    $student = $Student->read($application['student_id']);
                    ?>
                    <tr>
                        <td><?= $application['true_student_id'] ?></td>
                        <td><?= $application['student_first_name'] . ' ' . $application['student_last_name'] ?></td>
                        <td><?= $student['grade_level'] . ' ' . $student['section_name'] ?></td>
                        <td><?= $application['candidacy_token'] ?></td>
                        <td><?= $application['position_title'] ?></td>
                        <td class="<?= $application_status_class ?>"><?= $application_status ?></td>
                        <td>
                            <div class="table-action-container">
                                <button <?= ($application['status'] !== 0) ? 'disabled' : '' ?> class="table-action-link background-success" onclick="confirmAndSubmit(<?= $application['id'] ?>, 'accept')"><span class="material-symbols-outlined size-16" >check</span></button>
                                <button <?= ($application['status'] !== 0) ? 'disabled' : '' ?> class="table-action-link background-danger" onclick="confirmAndSubmit(<?= $application['id'] ?>, 'reject')"><span class="material-symbols-outlined size-16" >close</span></button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</main>

<script>
    $(".table-datatable").DataTable({
        order: [
            [0, 'asc']
        ]
    })

    function confirmAndSubmit(application_id, actionType) {
        // Show a confirmation dialog
        let confirmationMessage = actionType === 'accept' ?
            'Are you sure you want to accept this application?' :
            'Are you sure you want to reject this application?';

        if (confirm(confirmationMessage)) {
            // Create a form dynamically
            let form = document.createElement('form');
            form.method = 'POST';
            form.action = '../../handlers/election_period_application/update_application.php'; // Replace with your PHP handler file

            // Create a hidden input to pass the action type (success or danger)
            let input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'update_application';
            input.value = actionType;
            form.appendChild(input);

            let input2 = document.createElement('input');
            input2.type = 'hidden';
            input2.name = 'application_id';
            input2.value = application_id;
            form.appendChild(input2);

            // Append the form to the body and submit
            document.body.appendChild(form);
            form.submit();
        }
    }
</script>

</body>

</html>