<?php
include_once '../elements/header.php';
require_once "../../../models/ElectionPeriod.php";
require_once "../../../models/PredefinedPosition.php";

$ElectionPeriod = new ElectionPeriod();
$PredefinedPosition = new PredefinedPosition();

$predefinedPositions = $PredefinedPosition->index();


if(isset($_GET['id']) && !empty($_GET['id'])) {
    
    $electionPeriod = $ElectionPeriod->read($_GET['id']);

} else {
    header("Location: ".$Adviser->getBaseUrl()."/admin/views/election_period/index.php");
}

?>

<main>
    <div class="background-white padding-20 radius-5">
        <div>
            <h4>Setup New Election</h4>
            
        </div>
        <br>
        <form method="POST" action="<?= $baseUrl ?>/admin/handlers/election_period/update.php" id="electionForm" class="flex-column">
            <input type="hidden" name="id" value="<?= $electionPeriod[0]['id'] ?>">
            <div class="modal-body padding-20 flex-column gap-10">
                <div class="flex-column gap-5">
                    <label class="input-label">Title</label>
                    <input type="text" class="form-input" name="title" value="<?= $electionPeriod[0]['title'] ?>" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">School Year</label>
                    <div>
                        <input type="number" class="form-input" value="<?= $electionPeriod[0]['school_year_start'] ?>" name="school_year_start" required>
                        -
                        <input type="number" class="form-input" value="<?= $electionPeriod[0]['school_year_end'] ?>" name="school_year_end" required>
                    </div>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Election Date</label>
                    <input type="datetime-local" class="form-input" value="<?= $electionPeriod[0]['start_date'] ?>" name="start_date" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Election End</label>
                    <input type="datetime-local" class="form-input" value="<?= $electionPeriod[0]['end_date'] ?>" name="end_date" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Election status</label>
                    <select name="special_status" class="form-input" required>
                        
                        <option value="open" <?= $electionPeriod[0]['special_status'] == 'open' ? 'selected' : '' ?>>open</option>
                        <option value="ongoing" <?= $electionPeriod[0]['special_status'] == 'ongoing' ? 'selected' : '' ?>>ongoing</option>
                        <option value="closed" <?= $electionPeriod[0]['special_status'] == 'closed' ? 'selected' : '' ?>>closed</option>
                        <option value="finished" <?= $electionPeriod[0]['special_status'] == 'finished' ? 'selected' : '' ?>>finished</option>
                    </select>
                </div>

                <div class="flex-column gap-5">
                    <label class="input-label">Active</label>
                    <select name="status" class="form-input" required>
                        <option value="1" <?= $electionPeriod[0]['status'] == 1 ? 'selected' : '' ?>>Active</option>
                        <option value="0" <?= $electionPeriod[0]['status'] == 0 ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </div>
            </div>
            <div class="padding-20 flex-column gap-10">
                <div>
                    <h4>Positions</h4>
                    <p class="size-12">Select from predefined position</p>
                    <p class="size-10 color-warning">Cannot be updated</p>
                </div>
                <div class="flex-column gap-10">
                    <?php foreach ($electionPeriod as $ep): ?>
                        <div class="padding-15 border-gray flex-row align-center gap-10 cursor-pointer hover-green-background green-background">
                            <input type="checkbox" disabled checked class="position-checkbox">
                            <p class="size-14"><?php echo htmlspecialchars($ep['position_title']); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>

            </div>
            <br><br>
            <div class="flex-row align-stretch gap-10">
                <button type="button" class="button-1 background-gray">CANCEL</button>
                <button class="button-1 background-primary color-white" type="submit" name="update_election_period">SAVE</button>
            </div>
        </form>
    </div>
</main>
<br><br><br><br><br><br>

<script>
// Function to toggle checkbox when positions is clicked
function toggleCheckbox(div) {
    var checkbox = div.querySelector('.position-checkbox');
    checkbox.checked = !checkbox.checked; // Toggle the checkbox state

    if(checkbox.checked) {
        $(div).addClass('green-background')
    } else {
        $(div).removeClass('green-background')
    }
}
</script>

</body>

</html>