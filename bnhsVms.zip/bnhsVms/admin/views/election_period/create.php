<?php
include_once '../elements/header.php';
require_once "../../../models/PredefinedPosition.php";

$PredefinedPosition = new PredefinedPosition();
$positions = $PredefinedPosition->index();
?>

<main>
    <div class="background-white padding-20 radius-5">
        <div>
            <h4>Setup New Election</h4>
        </div>
        <br>
        <form method="POST" action="<?= $baseUrl ?>/admin/handlers/election_period/insert.php" id="electionForm" class="flex-column">
            <div class="modal-body padding-20 flex-column gap-10">
                <div class="flex-column gap-5">
                    <label class="input-label">Title</label>
                    <input type="text" class="form-input" name="title" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">School Year</label>
                    <div>
                        <input type="number" class="form-input" name="school_year_start" required>
                        -
                        <input type="number" class="form-input" name="school_year_end" required>
                    </div>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Election Date</label>
                    <input type="datetime-local" class="form-input" name="start_date" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Election End</label>
                    <input type="datetime-local" class="form-input" name="end_date" required>
                </div>
            </div>
            <div class="padding-20 flex-column gap-10">
                <div>
                    <h4>Add Positions</h4>
                    <p class="size-12">Select from predefined position</p>
                </div>
                <div class="flex-column gap-10">
                    <?php foreach ($positions as $position): ?>
                        <div class="padding-15 border-gray flex-row align-center gap-10 cursor-pointer hover-green-background" onclick="toggleCheckbox(this)">
                            <input type="checkbox" name="positions[]" value="<?php echo $position['id']; ?>"  class="position-checkbox">
                            <p class="size-14"><?php echo htmlspecialchars($position['position_title']); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>

            </div>
            <br><br>
            <div class="flex-row align-stretch gap-10">
                <button type="button" class="button-1 background-gray">CANCEL</button>
                <button class="button-1 background-primary color-white" type="submit" name="insert_election_period">SAVE</button>
            </div>
        </form>
    </div>
</main>
<br><br><br><br><br><br>

<script>
// Function to toggle checkbox when positions is clicked
function toggleCheckbox(div) {
    var checkbox = div.querySelector('.position-checkbox');
    checkbox.checked = !checkbox.checked; // Toggle the checkbox state

    if(checkbox.checked) {
        $(div).addClass('green-background')
    } else {
        $(div).removeClass('green-background')
    }
}

document.getElementById('electionForm').addEventListener('submit', function(event) {
    var checkboxes = document.querySelectorAll('input[name="positions[]"]');
    var checked = Array.from(checkboxes).some(checkbox => checkbox.checked);

    if (!checked) {
        event.preventDefault(); // Prevent form submission
        alert('Please select at least one position.');
    }
});
</script>

</body>

</html>