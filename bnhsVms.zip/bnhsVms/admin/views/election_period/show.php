<?php
require_once "../../../models/ElectionPeriod.php";
$ElectionPeriod = new ElectionPeriod();

if(isset($_GET['id']) && !empty($_GET['id'])) {
    
    $electionPeriod = $ElectionPeriod->read($_GET['id']);

} else {
    header("Location: ".$ElectionPeriod->getBaseUrl()."/admin/views/election_period/index.php");
}

include_once '../elements/header.php';

?>

<main>
    <div class="background-white padding-20 radius-5">
        <div class="flex-row align-end gap-20">
            <h4>Election Information</h4>
            <a href="./show_applications.php?id=<?= $_GET['id'] ?>" class="size-14 hover-color-primary-variant">Applications</a>
            <a href="./show_candidates.php?id=<?= $_GET['id'] ?>" class="size-14 hover-color-primary-variant">Candidates</a>
        </div>
        <br><br>
        <div class="width-fit">
            <div class="show-info-1">
                <p class="input-label">Title</p>
                <p class="size-14"><?= $electionPeriod[0]['title'] ?></p>
            </div>
            <div class="show-info-1">
                <p class="input-label">School year</p>
                <p class="size-14"><?= $electionPeriod[0]['school_year_start'].'-'.$electionPeriod[0]['school_year_end'] ?></p>
            </div>
            <div class="show-info-1">
                <p class="input-label">Voting schedule</p>
                <p class="size-14"><?= $electionPeriod[0]['start_date'].' - '.$electionPeriod[0]['end_date'] ?></p>
            </div>
            <div class="show-info-1">
                <p class="input-label">Status</p>
                <p class="size-14"><?= ucfirst($electionPeriod[0]['special_status']) ?></p>
            </div>
            <div class="show-info-1">
                <p class="input-label">Active flag</p>
                <p class="size-14 <?= $electionPeriod[0]['status'] == 1 ? 'color-success' : 'color-danger' ?>"><?= $electionPeriod[0]['status'] == 1 ? 'Active' : 'Inactive' ?></p>
            </div>
        </div>
        <br>
        <div class="flex-column gap-10">
            <div>
                <h4>Positions</h4>
                <p class="size-10">These are the positions for this election</p>
            </div>
            <div class="flex-column gap-10">
                <?php foreach ($electionPeriod as $ep): ?>
                    <div class="padding-15 border-gray flex-row align-center gap-10 cursor-pointer hover-green-background">
                        <p class="size-14"><?php echo htmlspecialchars($ep['position_title']); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <br><br><br>
        <a href="<?= $ElectionPeriod->getBaseUrl() ?>/admin/views/election_period/edit.php?id=<?= $electionPeriod[0]["id"] ?>" class="button-1 background-primary-variant color-white">UPDATE</a>
        <br><br>
    </div>
</main>

</body>

</html>