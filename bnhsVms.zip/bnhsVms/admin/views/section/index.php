<?php
include_once '../elements/header.php';
require_once "../../../models/Section.php";

$Section = new Section();
$sections = $Section->index();

?>

<main>
    <div class="background-white padding-20 radius-5">
        <div class="flex-row align-center justify-space-between">
            <h3>Sections</h3>
            <a href="<?= $baseUrl ?>/admin/views/section/create.php" class="gap-5 background-primary color-white padding-10 radius-5 hover-gray-background flex-row align-center">
                <span class="material-symbols-outlined size-16">add</span>
                <p>Add Section</p>
            </a>
        </div>
        <br><br>
        <table class="table table-datatable">
            <thead>
                <tr>
                    <th>Gradel Level</th>
                    <th>Name</th>
                    <th>Adviser</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($sections as $section) : ?>
                    <tr>
                        <td><?= $section['grade_level'] ?></td>
                        <td><?= $section['name'] ?></td>
                        <td><?= $section['first_name'] ." ".$section['last_name'] ?></td>
                        <td><?= $section['status'] == 1 ? 'Active' : 'Inactive' ?></td>
                        <td>
                            <div class="table-action-container">
                                <a href="<?= $Section->getBaseUrl() ?>/admin/views/section/show.php?id=<?= $section["id"] ?>" class="table-action-link background-primary-variant">
                                    <span class="material-symbols-outlined size-16">visibility</span>
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</main>

<script>
    $(".table-datatable").DataTable({
        order: [
            [0, 'asc']
        ]
    })
</script>


</body>

</html>