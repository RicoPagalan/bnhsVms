<?php
include_once '../elements/header.php';
require_once "../../../models/Adviser.php";

$Adviser = new Adviser();
$advisers = $Adviser->index();

?>

<main>
    <div class="background-white padding-20 radius-5">
        <div>
            <h4>Add Section</h4>
        </div>
        <br>
        <form method="POST" action="<?= $baseUrl ?>/admin/handlers/section/insert.php" class="flex-column">
            <div class="modal-body padding-20 flex-column gap-10">
                <input type="hidden" id="add_course_department_id" name="add_course_department_id">
                <div class="flex-column gap-5">
                    <label class="input-label">Grade Level</label>
                    <input type="number" class="form-input" name="grade_level" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Name</label>
                    <input type="text" class="form-input" name="name" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Status</label>
                    <select name="status" class="form-input" required>
                        <option value="1">Active</option>
                        <option value="0">Inactive</option>
                    </select>
                </div>
            </div>
            <div class="flex-row align-stretch gap-10">
                <button type="button" class="button-1 background-gray">CANCEL</button>
                <button class="button-1 background-primary color-white" type="submit" name="insert_section">SAVE</button>
            </div>
        </form>
    </div>
</main>

</body>

</html>