<?php
require_once "../../../models/Section.php";

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $Section = new Section();
    $section = $Section->read($_GET['id']);
} else {
    header("Location: " . $Adviser->getBaseUrl() . "/admin/views/adviser/index.php");
}

include_once '../elements/header.php';

?>

<main>
    <div class="background-white padding-20 radius-5">
        <div>
            <h4>Adviser Information</h4>
        </div>
        <br><br>
        <div class="width-fit">
            <div class="show-info-1">
                <p class="input-label">Grade Level</p>
                <p class="size-14"><?= $section['grade_level'] ?></p>
            </div>
            <div class="show-info-1">
                <p class="input-label">Name</p>
                <p class="size-14"><?= $section['name'] ?></p>
            </div>
            <div class="show-info-1">
                <p class="input-label">Status</p>
                <p class="size-14"><?= $section['status'] == 1 ? 'Active' : 'Inactive' ?></p>
            </div>
        </div>
        <br>
        <a href="<?= $Section->getBaseUrl() ?>/admin/views/section/edit.php?id=<?= $section["id"] ?>" class="button-1 background-primary-variant color-white">UPDATE</a>
        
    </div>
</main>

</body>

</html>