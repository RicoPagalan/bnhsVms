<?php
require_once "../../../models/Section.php";

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $Section = new Section();
    $section = $Section->read($_GET['id']);
} else {
    header("Location: " . $Adviser->getBaseUrl() . "/admin/views/adviser/index.php");
}

include_once '../elements/header.php';

?>
<main>
    <div class="background-white padding-20 radius-5">
        <div>
            <h4>Update Section</h4>
        </div>
        <br>
        <form method="POST" action="<?= $baseUrl ?>/admin/handlers/section/update.php" class="flex-column">
            <input type="hidden" name="id" value="<?= $section['id'] ?>">
            <div class="modal-body padding-20 flex-column gap-10">
                <div class="flex-column gap-5">
                    <label class="input-label">Grade Level</label>
                    <input type="number" class="form-input" name="grade_level" value="<?= $section['grade_level'] ?>" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Name</label>
                    <input type="text" class="form-input" name="name" value="<?= $section['name'] ?>" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Status</label>
                    <select name="status" class="form-input" required>
                        <option value="1" <?= $section['status'] == 1 ? 'selected' : ''; ?>>Active</option>
                        <option value="0" <?= $section['status'] == 0 ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                </div>
            </div>
            <div class="flex-row align-stretch gap-10">
                <a href="<?= $Section::getBaseUrl() ?>/admin/views/section/show.php?id=<?= $section["id"] ?>" class="button-1 background-gray color-black">CANCEL</a>
                <button class="button-1 background-primary color-white" type="submit" name="update_section">SAVE</button>
            </div>
        </form>
    </div>
</main>

</body>
</html>