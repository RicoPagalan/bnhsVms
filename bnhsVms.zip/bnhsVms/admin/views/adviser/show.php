<?php
require_once "../../../models/Adviser.php";

if(isset($_GET['id']) && !empty($_GET['id'])) {
    $Adviser = new Adviser();
    $adviser = $Adviser->read($_GET['id']);

} else {
    header("Location: ".$Adviser->getBaseUrl()."/admin/views/adviser/index.php");
}

include_once '../elements/header.php';

?>

<main>
    <div class="background-white padding-20 radius-5">
        <div>
            <h4>Adviser Information</h4>
        </div>
        <br><br>
        <div class="width-fit">
            <div class="show-info-1">
                <p class="input-label">Full name</p>
                <p class="size-14"><?= $adviser['first_name']. " ". $adviser['last_name'] ?></p>
            </div>
            <div class="show-info-1">
                <p class="input-label">Birthdate</p>
                <p class="size-14"><?= $adviser['birthdate'] ?></p>
            </div>
            <div class="show-info-1">
                <p class="input-label">Email</p>
                <p class="size-14"><?= $adviser['email'] ?></p>
            </div>
            <div class="show-info-1">
                <p class="input-label">Advisory</p>
                <p class="size-14"><?= $adviser['grade_level']." - ".$adviser['section_name'] ?></p>
            </div>
            <div class="show-info-1">
                <p class="input-label">Status</p>
                <p class="size-14"><?= $adviser['status'] == 1 ? 'Active' : 'Inactive' ?></p>
            </div>
        </div>
        <br>
        <a href="<?= $Adviser->getBaseUrl() ?>/admin/views/adviser/edit.php?id=<?= $adviser["id"] ?>" class="button-1 background-primary-variant color-white">UPDATE</a>
        
    </div>
</main>

</body>

</html>