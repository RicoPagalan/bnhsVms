<?php
include_once '../elements/header.php';
require_once "../../../models/Adviser.php";
require_once "../../../models/Section.php";

$Adviser = new Adviser();
$advisers = $Adviser->index();

$Section = new Section();
$availableSections = $Section->getAvailableSectionsForAdviser();
?>

<main>
    <div class="background-white padding-20 radius-5">
        <div>
            <h4>Register Adviser</h4>
        </div><br>
        <?php
        if (isset($_GET['warning'])) {
            echo '<p class="align-self-center size-16 color-danger">' . $_GET['warning'] . '</p>';
        }
        ?>
        <form method="POST" action="<?= $baseUrl ?>/admin/handlers/adviser/insert.php" class="flex-column">
            <div class="modal-body padding-20 flex-column gap-10">
                <div class="flex-column gap-5">
                    <label class="input-label">Section advisory</label>
                    <select name="section_id" class="form-input" required>
                        <option value="">Choose section to assign adviser</option>
                        <?php foreach ($availableSections as $section): ?>
                            <option value="<?= $section['id'] ?>"><?= $section['name'] ?></option>
                        <?php endforeach ?>
                    </select>
                </div>

                <div class="flex-column gap-5">
                    <label class="input-label">First name</label>
                    <input type="text" class="form-input" name="first_name" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Last name</label>
                    <input type="text" class="form-input" name="last_name" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Birthdate</label>
                    <input type="date" class="form-input" name="birthdate" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Email</label>
                    <input type="email" class="form-input" name="email" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Status</label>
                    <select name="status" class="form-input" required>
                        <option value="1">Active</option>
                        <option value="0">Inactive</option>
                    </select>
                </div>
            </div>
            <div class="flex-row align-stretch gap-10">
                <button type="button" class="button-1 background-gray">CANCEL</button>
                <button class="button-1 background-primary color-white" type="submit" name="insert_adviser">SAVE</button>
            </div>
        </form>
    </div>
</main>

</body>

</html>