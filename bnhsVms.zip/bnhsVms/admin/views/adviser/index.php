<?php
include_once '../elements/header.php';
require_once "../../../models/Adviser.php";

$Adviser = new Adviser();
$advisers = $Adviser->index();

?>

<main>
    <div class="background-white padding-20 radius-5">
        <div class="flex-row align-center justify-space-between">
            <h3>Advisers</h3>
            <a href="<?= $baseUrl ?>/admin/views/adviser/create.php" class="gap-5 background-primary color-white padding-10 radius-5 hover-gray-background flex-row align-center">
                <span class="material-symbols-outlined size-16">add</span>
                <p>Add Adviser</p>
            </a>
        </div>
        <br><br>
        <table class="table table-datatable">
            <thead>
                <tr>
                    <th>First name</th>
                    <th>Last name</th>
                    <th>Birthdate</th>
                    <th>Email</th>
                    <th>Advisory</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($advisers as $adviser) : ?>
                    <tr>
                        <td><?= $adviser['first_name'] ?></td>
                        <td><?= $adviser['last_name'] ?></td>
                        <td><?= $adviser['birthdate'] ?></td>
                        <td><?= $adviser['email'] ?></td>
                        <td><?= $adviser['grade_level']." - ".$adviser['section_name']  ?></td>
                        <td><?= $adviser['status'] == 1 ? 'Active' : 'Inactive' ?></td>
                        <td>
                            <div class="table-action-container">
                                <a href="<?= $Adviser->getBaseUrl() ?>/admin/views/adviser/show.php?id=<?= $adviser["id"] ?>" class="table-action-link background-primary-variant">
                                    <span class="material-symbols-outlined size-16">visibility</span>
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</main>

<script>
    $(".table-datatable").DataTable({
        order: [
            [0, 'asc']
        ]
    })
</script>


</body>

</html>