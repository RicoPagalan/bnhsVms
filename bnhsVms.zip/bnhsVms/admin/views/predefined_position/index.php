<?php
include_once '../elements/header.php';
require_once "../../../models/PredefinedPosition.php";

$PredefinedPosition = new PredefinedPosition();
$positions = $PredefinedPosition->index();

?>

<main>
    <div class="background-white padding-20 radius-5">
        <div class="flex-row align-center justify-space-between">
            <h3>Predefined Positions</h3>
            <a href="<?= $baseUrl ?>/admin/views/predefined_position/create.php" class="gap-5 background-primary color-white padding-10 radius-5 hover-gray-background flex-row align-center">
                <span class="material-symbols-outlined size-16">add</span>
                <p>Add Position</p>
            </a>
        </div>
        <br><br>
        <table class="table table-datatable">
            <thead>
                <tr>
                    <th>Position</th>
                    <th>Order</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($positions as $position) : ?>
                    <tr>
                        <td><?= $position['position_title'] ?></td>
                        <td><?= $position['order_number'] ?></td>
                        <td>
                            <div class="table-action-container">
                                <a href="<?= $PredefinedPosition->getBaseUrl() ?>/admin/views/predefined_position/show.php?id=<?= $position["id"] ?>" class="table-action-link background-primary-variant">
                                    <span class="material-symbols-outlined size-16">visibility</span>
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</main>

<script>
    $(".table-datatable").DataTable({
        order: [
            [1, 'asc']
        ]
    })
</script>


</body>

</html>