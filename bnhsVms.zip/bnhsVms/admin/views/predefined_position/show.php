<?php
require_once "../../../models/PredefinedPosition.php";

if(isset($_GET['id']) && !empty($_GET['id'])) {
    $PredefinedPosition = new PredefinedPosition();
    $predefinedPosition = $PredefinedPosition->read($_GET['id']);

} else {
    header("Location: ".$PredefinedPosition->getBaseUrl()."/admin/views/predefined_position/index.php");
}

include_once '../elements/header.php';

?>

<main>
    <div class="background-white padding-20 radius-5">
        <div>
            <h4>Position Info</h4>
        </div>
        <br><br>
        <div class="width-fit">
            <div class="show-info-1">
                <p class="input-label">Title</p>
                <p class="size-14"><?= $predefinedPosition['position_title'] ?></p>
            </div>
            <div class="show-info-1">
                <p class="input-label">Order</p>
                <p class="size-14"><?= $predefinedPosition['order_number'] ?></p>
            </div>
        </div>
        <br>
        <a href="<?= $PredefinedPosition->getBaseUrl() ?>/admin/views/predefined_position/edit.php?id=<?= $predefinedPosition["id"] ?>" class="button-1 background-primary-variant color-white">UPDATE</a>
        
    </div>
</main>

</body>

</html>