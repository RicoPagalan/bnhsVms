<?php
include_once '../elements/header.php';
?>

<main>
    <div class="background-white padding-20 radius-5">
        <div>
            <h4>Add position</h4>
        </div>
        <br>
        <form method="POST" action="<?= $baseUrl ?>/admin/handlers/predefined_position/insert.php" class="flex-column">
            <div class="modal-body padding-20 flex-column gap-10">
                <div class="flex-column gap-5">
                    <label class="input-label">Title</label>
                    <input type="text" class="form-input" name="position_title" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Order</label>
                    <input type="number" class="form-input" name="order_number" required>
                </div>
            </div>
            <div class="flex-row align-stretch gap-10">
                <button type="button" class="button-1 background-gray">CANCEL</button>
                <button class="button-1 background-primary color-white" type="submit" name="insert_predefined_position">SAVE</button>
            </div>
        </form>
    </div>
</main>

</body>

</html>