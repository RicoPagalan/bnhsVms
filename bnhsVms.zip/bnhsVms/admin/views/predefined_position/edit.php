<?php
require_once "../../../models/PredefinedPosition.php";

if(isset($_GET['id']) && !empty($_GET['id'])) {
    $PredefinedPosition = new PredefinedPosition();
    $predefinedPosition = $PredefinedPosition->read($_GET['id']);

} else {
    header("Location: ".$Adviser->getBaseUrl()."/admin/views/predefined_position/index.php");
}

include_once '../elements/header.php';

?>

<main>
    <div class="background-white padding-20 radius-5">
        <div>
            <h4>Update Position</h4>
        </div>
        <br>
        <form method="POST" action="<?= $baseUrl ?>/admin/handlers/predefined_position/update.php" class="flex-column">
            <input type="hidden" name="id" value="<?= $predefinedPosition['id'] ?>">
            <div class="modal-body padding-20 flex-column gap-10">
                <div class="flex-column gap-5">
                    <label class="input-label">Title</label>
                    <input type="text" class="form-input" name="position_title" value="<?= $predefinedPosition['position_title'] ?>" required>
                </div>
                <div class="flex-column gap-5">
                    <label class="input-label">Order</label>
                    <input type="number" class="form-input" name="order_number" value="<?= $predefinedPosition['order_number'] ?>" required>
                </div>
            </div>
            <div class="flex-row align-stretch gap-10">
                <a href="<?= $PredefinedPosition->getBaseUrl() ?>/admin/views/predefined_position/show.php?id=<?= $predefinedPosition["id"] ?>" class="button-1 background-gray color-black">CANCEL</a>
                <button class="button-1 background-primary color-white" type="submit" name="update_predefined_position">SAVE</button>
            </div>
        </form>
    </div>
</main>

</body>

</html>