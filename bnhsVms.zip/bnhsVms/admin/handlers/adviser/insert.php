<?php

require_once "../../../models/Adviser.php";
require_once "../../../models/AdviserSection.php";

if(isset($_POST['insert_adviser'])) {
    $Adviser = new Adviser();
    $AdviserSection = new AdviserSection();

    $section_id = $_POST['section_id'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $birthdate = $_POST['birthdate'];
    $email = $_POST['email'];
    $status = $_POST['status'];

    $uniqueEmail = $Adviser->checkUnique('advisers', 'email', $email);

    if(!$uniqueEmail) {
        header("Location: ".$Adviser->getBaseUrl()."/admin/views/adviser/create.php?warning=Email not unique!");
        return false;
    }

    $adviser_id = $Adviser->insert($first_name, $last_name, $birthdate, $email, $status);

    if($adviser_id) {
        $result = $AdviserSection->insert($adviser_id, $section_id);

        if ($result) {
            header("Location: ".$Adviser->getBaseUrl()."/admin/views/adviser/index.php");
        } else {
            header("Location: ".$Adviser->getBaseUrl()."/admin/views/adviser/index.php?warning=Something went wrong!");
        }
    }

    
}
