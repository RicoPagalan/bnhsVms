<?php

require_once "../../../models/ElectionPeriod.php";
require_once "../../../models/ElectionPeriodPosition.php";

if (isset($_POST['insert_election_period'])) {
    $ElectionPeriod = new ElectionPeriod();
    

    $title = $_POST['title'];
    $school_year_start = $_POST['school_year_start'];
    $school_year_end = $_POST['school_year_end'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    
    $special_status = 'open';
    $status = 1;

    $selected_positions = $_POST['positions'];

    $ep_id = $ElectionPeriod->insert($title, $school_year_start, $school_year_end, $start_date, $end_date, $special_status, $status);

    if ($ep_id) {
        $ElectionPeriodPosition = new ElectionPeriodPosition();

        $data = [];

        foreach ($selected_positions as $position_id) {
            $position_id = htmlspecialchars($position_id, ENT_QUOTES, 'UTF-8');

            $data[] = [
                'election_period_id' => $ep_id,
                'predefined_position_id' => $position_id,
                'status' => 1,
            ];

            
        }

        $lastIdEPP = $ElectionPeriodPosition->insertMany($data);

        if ($lastIdEPP) {
            header("Location: ".$ElectionPeriod->getBaseUrl()."/admin/views/election_period/index.php?result=$lastIdEPP");
        } else {
            echo "Error: Something went wrong!";
        }
    } else {
        echo "Error: Something went wrong!";
    }
}
