<?php

require_once "../../../models/ElectionPeriod.php";
require_once "../../../models/ElectionPeriodPosition.php";

if (isset($_POST['update_election_period'])) {
    $ElectionPeriod = new ElectionPeriod();
    

    $id = $_POST['id'];

    $title = $_POST['title'];
    $school_year_start = $_POST['school_year_start'];
    $school_year_end = $_POST['school_year_end'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    
    $special_status = $_POST['special_status'];
    $status = $_POST['status'];

    $result = $ElectionPeriod->update($id, $title, $school_year_start, $school_year_end, $start_date, $end_date, $special_status, $status);

    if ($result) {
        header("Location: ".$ElectionPeriod->getBaseUrl()."/admin/views/election_period/show.php?id=$id");
    } else {
        echo "Error: Something went wrong!";
    }
}
