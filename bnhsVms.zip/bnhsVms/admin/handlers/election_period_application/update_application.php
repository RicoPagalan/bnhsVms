<?php

require_once "../../../models/ElectionPeriodApplication.php";
require_once "../../../models/ElectionPeriodCandidate.php";

if(isset($_POST['update_application'])) {
    $ElectionPeriodApplication = new ElectionPeriodApplication();

    $type = $_POST['update_application'];
    $application_id = $_POST['application_id'];

    $application = $ElectionPeriodApplication->read($application_id);

    if($application['election_period_special_status'] != 'open' || $application['election_period_status'] != 1) {
        header("Location: ".$ElectionPeriodApplication->getBaseUrl()."/admin/views/election_period/show_applications.php?id=".$application['election_period_id']."&warning=Cannot update status anymore");
        return;
    }

    if($application['status'] == '0') {
        if($type == 'accept'){
            // accept, status = 1
            $ElectionPeriodCandidate = new ElectionPeriodCandidate();

            $result = $ElectionPeriodCandidate->insert($application_id, 1);

            if ($result) {
                $acceptResult = $ElectionPeriodApplication->updateStatusById(1, $application_id);

                if($acceptResult) {
                    header("Location: ".$ElectionPeriodApplication->getBaseUrl()."/admin/views/election_period/show_applications.php?id=".$application['election_period_id']."&result=Application successfully accepted");
                } else {
                header("Location: ".$ElectionPeriodApplication->getBaseUrl()."/admin/views/election_period/show_applications.php?id=".$application['election_period_id']."&warning=Something went wrong!");
                }

            } else {
                header("Location: ".$ElectionPeriodApplication->getBaseUrl()."/admin/views/election_period/show_applications.php?id=".$application['election_period_id']."&warning=Something went wrong!");
            }

        } elseif($type == 'reject') { 
            // reject, status = 2
            $result = $ElectionPeriodApplication->updateStatusById(2, $application_id);

            if ($result) {
                header("Location: ".$ElectionPeriodApplication->getBaseUrl()."/admin/views/election_period/show_applications.php?id=".$application['election_period_id']."&result=Application successfully rejected");
            } else {
                header("Location: ".$ElectionPeriodApplication->getBaseUrl()."/admin/views/election_period/show_applications.php?id=".$application['election_period_id']."&warning=Something went wrong!");
            }
        }


        
    } else {
        header("Location: ".$ElectionPeriodApplication->getBaseUrl()."/admin/views/election_period/show_applications.php?id=".$application['election_period_id']."&warning=Cannot update status again");
    }

    
}
