<?php

require_once "../../../models/Section.php";

if(isset($_POST['insert_section'])) {
    $Section = new Section();

    $grade_level = $_POST['grade_level'];
    $name = $_POST['name'];
    $status = $_POST['status'];

    $result = $Section->insert($grade_level, $name, $status);

    if ($result) {
        header("Location: ".$Section->getBaseUrl()."/admin/views/section/index.php");
    } else {
        echo "Error: Something went wrong!";
    }
}
