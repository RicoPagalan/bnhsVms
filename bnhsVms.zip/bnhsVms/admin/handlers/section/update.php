<?php

require_once "../../../models/Section.php";

if(isset($_POST['update_section'])) {
    $Section = new Section();

    $id = $_POST['id'];

    $grade_level = $_POST['grade_level'];
    $name = $_POST['name'];
    $status = $_POST['status'];

    $result = $Section->update($id, $grade_level, $name, $status);

    if ($result) {
        header("Location: ".$Section->getBaseUrl()."/admin/views/section/show.php?id=".$id);
    } else {
        echo "Error: Something went wrong!";
    }
}
