<?php

require_once "../../../models/PredefinedPosition.php";

if(isset($_POST['insert_predefined_position'])) {
    $PredefinedPosition = new PredefinedPosition();

    $position_title = $_POST['position_title'];
    $order_number = $_POST['order_number'];

    $result = $PredefinedPosition->insert($position_title, $order_number);

    if ($result) {
        header("Location: ".$PredefinedPosition->getBaseUrl()."/admin/views/predefined_position/index.php?result=$result");
    } else {
        echo "Error: Something went wrong!";
    }
}
