<?php

require_once "../../../models/PredefinedPosition.php";

if(isset($_POST['update_predefined_position'])) {
    $PredefinedPosition = new PredefinedPosition();

    $id = $_POST['id'];

    $position_title = $_POST['position_title'];
    $order_number = $_POST['order_number'];

    $result = $PredefinedPosition->update($id, $position_title, $order_number);

    if ($result) {
        header("Location: ".$PredefinedPosition->getBaseUrl()."/admin/views/predefined_position/show.php?id=".$id."&$result");
    } else {
        echo "Error: Something went wrong!";
    }
}
