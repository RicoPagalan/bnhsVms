<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="" href="./assets/css/base.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>

</head>

<body>
    <div class="div-overlay">
        <img src="./images/voting2.jpg" alt="" class="background-image blur-10 ">
    </div>

    <div class="landing-page-container-1">
        <div class="flex-column align-center">
            <div class="flex-column">
                <p class="size-16 color-white text-align-center">Welcome to Bonifacio National High School</p>
                <p class="size-48 color-white weight-500 text-align-center margin-top-nega-70"><br>Online Voting System</p>
                <p class="size-12 color-white text-align-center margin-top-10">
                    The Bonifacio National High School Online Voting System is a secure and user-friendly platform <br> designed to facilitate
                    the efficient and transparent election of student leaders. This system allows students to cast their votes electronically, <br>
                    ensuring a smooth voting process with real-time results, reducing manual errors, and promoting fair elections.
                </p>
            </div>
            <br><br><br>
            <div class="flex-row gap-10">
                <a href="./student/views/candidacy/input_token.php" class="button-1 background-primary-variant color-white flex-equal min-width-200">File for candidacy</a>
                <a href="./student/views/voting/input_token.php" class="button-1 background-success color-white flex-equal min-width-200">Vote now</a>
            </div>
        </div>

        <div class="user-links-to-login">
            <a href="./input_token_lv.php" class="hover-color-primary-variant">>> live viewing</a>
            <br>
            <a href="./admin_login.php" class="hover-color-primary-variant">>> admin login</a>
            <a href="./adviser_login.php" class="hover-color-primary-variant">>> adviser login</a>
        </div>
    </div>


</body>

</html>