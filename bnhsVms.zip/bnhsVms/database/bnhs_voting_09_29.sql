-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 29, 2024 at 11:21 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bnhs_voting`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL DEFAULT 'admin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `status`, `username`, `password`, `user_type`) VALUES
(1, 'admin user', 'active', 'admin', '$2y$10$MmteXrONGcTSu/Kp02DZiecTtPsWQppVi6ogDrjcfslv4IUox2XOq', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `advisers`
--

CREATE TABLE `advisers` (
  `id` int(12) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `birthdate` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` tinyint(50) NOT NULL COMMENT '(0:inactive, 1:active)',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `advisers`
--

INSERT INTO `advisers` (`id`, `first_name`, `last_name`, `birthdate`, `email`, `password`, `status`, `created`, `modified`) VALUES
(1, 'Asia', 'Youd', '2024-09-02', 'asia@gmail.com', '$2y$10$O/hH0Kr0tmeyvES5l5h6gOlud50WWKjeRCDwrds6rWpdDXRfyIAfy', 1, '2024-09-28 04:10:35', '2024-09-28 04:10:35'),
(2, 'Glen', 'Jockers', '2024-09-26', 'glen@gmail.com', '$2y$10$yzrY5sSMfU8EJzXAKt8LNuI5EtBAzvlmr5bDTGKo/qgSYet1c/EJi', 1, '2024-09-28 04:10:59', '2024-09-28 04:10:59'),
(3, 'Myles', 'Heisse', '2024-09-17', 'myles@gmail.com', '$2y$10$vD88DBAMTba2nbK9fut7hOE4HX009s98XIlovdgZupCakWzMQ/4yi', 1, '2024-09-28 04:11:21', '2024-09-28 04:11:21'),
(4, 'Devon', 'Zettel', '2024-09-01', 'devon@gmail.com', '$2y$10$O3CUWQV3FNxpEX8AKf7EQuJ3XKiugHCdTsePDr8K5qWfCadReGqyi', 1, '2024-09-28 04:11:38', '2024-09-28 04:11:38');

-- --------------------------------------------------------

--
-- Table structure for table `adviser_sections`
--

CREATE TABLE `adviser_sections` (
  `id` int(11) NOT NULL,
  `adviser_id` int(255) NOT NULL,
  `section_id` int(255) NOT NULL,
  `status` tinyint(50) NOT NULL COMMENT '(0:inactive, 1:active)',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adviser_sections`
--

INSERT INTO `adviser_sections` (`id`, `adviser_id`, `section_id`, `status`, `created`, `modified`) VALUES
(1, 1, 1, 0, '2024-09-28 04:10:35', '2024-09-28 04:10:35'),
(2, 2, 2, 0, '2024-09-28 04:10:59', '2024-09-28 04:10:59'),
(3, 3, 3, 1, '2024-09-28 04:11:21', '2024-09-28 04:11:21'),
(4, 4, 4, 1, '2024-09-28 04:11:38', '2024-09-28 04:11:38'),
(5, 1, 2, 1, '2024-09-29 01:42:53', '2024-09-29 01:42:53'),
(7, 2, 1, 1, '2024-09-29 12:08:36', '2024-09-29 12:08:36');

-- --------------------------------------------------------

--
-- Table structure for table `candidacy_tokens`
--

CREATE TABLE `candidacy_tokens` (
  `id` int(11) NOT NULL,
  `token` varchar(50) NOT NULL,
  `student_id` int(11) NOT NULL,
  `election_period_id` int(11) NOT NULL,
  `adviser_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `valid_flag` tinyint(1) NOT NULL,
  `is_used` tinyint(4) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `candidacy_tokens`
--

INSERT INTO `candidacy_tokens` (`id`, `token`, `student_id`, `election_period_id`, `adviser_id`, `section_id`, `valid_flag`, `is_used`, `created`, `modified`) VALUES
(1, '319673a4d4f0', 3, 1, 1, 1, 0, 1, '2024-09-28 11:21:45', '2024-09-28 11:21:45'),
(2, '213571a65506', 2, 1, 1, 1, 0, 1, '2024-09-28 11:22:02', '2024-09-28 11:22:02'),
(3, '61d45b2cf756', 6, 1, 1, 1, 0, 1, '2024-09-28 11:22:15', '2024-09-28 11:22:15'),
(4, '8100bd329db5', 8, 1, 1, 1, 0, 1, '2024-09-28 11:22:29', '2024-09-28 11:22:29'),
(5, '511b88c0f6369', 51, 1, 4, 4, 0, 1, '2024-09-28 11:23:01', '2024-09-28 11:23:01'),
(6, '5310b66cf46bc', 53, 1, 4, 4, 0, 1, '2024-09-28 11:23:10', '2024-09-28 11:23:10'),
(7, '5815fd4f4fd1f', 58, 1, 4, 4, 0, 1, '2024-09-28 11:23:23', '2024-09-28 11:23:23'),
(8, '6017088229b00', 60, 1, 4, 4, 0, 1, '2024-09-28 11:23:36', '2024-09-28 11:23:36'),
(9, '55120be087cc8', 55, 1, 4, 4, 0, 1, '2024-09-28 11:23:51', '2024-09-28 11:23:51'),
(10, '54126b51510ce', 54, 1, 4, 4, 0, 1, '2024-09-28 11:24:01', '2024-09-28 11:24:01'),
(11, '181e2174eb905', 18, 1, 2, 2, 0, 1, '2024-09-28 11:24:26', '2024-09-28 11:24:26'),
(12, '1415b510f8a80', 14, 1, 2, 2, 0, 1, '2024-09-28 11:24:36', '2024-09-28 11:24:36'),
(13, '2015f8af546c2', 20, 1, 2, 2, 0, 1, '2024-09-28 11:25:04', '2024-09-28 11:25:04'),
(14, '131e8c4493b10', 13, 1, 2, 2, 0, 1, '2024-09-28 11:25:15', '2024-09-28 11:25:15'),
(15, '2416f7b304fbd', 24, 1, 3, 3, 0, 1, '2024-09-28 11:25:36', '2024-09-28 11:25:36'),
(16, '26179d17514c4', 26, 1, 3, 3, 0, 1, '2024-09-28 11:25:47', '2024-09-28 11:25:47'),
(17, '2717a90f32c83', 27, 1, 3, 3, 0, 1, '2024-09-28 11:26:03', '2024-09-28 11:26:03'),
(18, '29106deb98cc2', 29, 1, 3, 3, 0, 1, '2024-09-28 11:26:12', '2024-09-28 11:26:12'),
(19, '3014f49137f1d', 30, 1, 3, 3, 0, 1, '2024-09-28 11:26:21', '2024-09-28 11:26:21'),
(20, '231eded11292f', 23, 1, 3, 3, 0, 1, '2024-09-28 11:26:30', '2024-09-28 11:26:30'),
(21, '2216be01152f2', 22, 1, 3, 3, 0, 1, '2024-09-28 11:26:40', '2024-09-28 11:26:40'),
(22, '2110baac98238', 21, 1, 3, 3, 0, 1, '2024-09-28 11:26:49', '2024-09-28 11:26:49'),
(23, '71db26e2fe62', 7, 1, 1, 1, 0, 1, '2024-09-28 11:27:58', '2024-09-28 11:27:58'),
(24, '251c972f06087', 25, 1, 3, 3, 0, 1, '2024-09-28 11:32:54', '2024-09-28 11:32:54'),
(25, '114771869c92', 1, 1, 1, 1, 0, 1, '2024-09-28 12:45:12', '2024-09-28 12:45:12'),
(26, '41e369530e1a', 4, 1, 1, 1, 0, 1, '2024-09-28 12:45:21', '2024-09-28 12:45:21');

-- --------------------------------------------------------

--
-- Table structure for table `election_periods`
--

CREATE TABLE `election_periods` (
  `id` int(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `school_year_start` int(255) NOT NULL,
  `school_year_end` int(255) NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `special_status` varchar(255) NOT NULL COMMENT '(status for election like: open, ongoing, closed, finished, etc.)',
  `status` tinyint(50) NOT NULL,
  `live_viewing_code` varchar(255) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `election_periods`
--

INSERT INTO `election_periods` (`id`, `title`, `school_year_start`, `school_year_end`, `start_date`, `end_date`, `special_status`, `status`, `live_viewing_code`, `created`, `modified`) VALUES
(1, '2024 SSG Election', 2024, 2025, '2024-09-28 11:00:00', '2024-09-28 18:00:00', 'open', 1, 'admin123', '2024-09-28 04:18:43', '2024-09-28 04:18:43');

-- --------------------------------------------------------

--
-- Table structure for table `election_period_applications`
--

CREATE TABLE `election_period_applications` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `candidacy_token_id` int(11) NOT NULL,
  `election_period_id` int(11) NOT NULL,
  `election_period_position_id` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0: pending, 1: accepted, 2: rejected',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `election_period_applications`
--

INSERT INTO `election_period_applications` (`id`, `student_id`, `candidacy_token_id`, `election_period_id`, `election_period_position_id`, `status`, `created`, `modified`) VALUES
(25, 51, 5, 1, 1, 1, '2024-09-28 11:47:19', '2024-09-28 11:47:19'),
(26, 24, 15, 1, 1, 1, '2024-09-28 11:47:27', '2024-09-28 11:47:27'),
(27, 53, 6, 1, 4, 1, '2024-09-28 11:47:33', '2024-09-28 11:47:33'),
(28, 18, 11, 1, 4, 1, '2024-09-28 11:47:47', '2024-09-28 11:47:47'),
(29, 3, 1, 1, 2, 1, '2024-09-28 11:47:53', '2024-09-28 11:47:53'),
(30, 26, 16, 1, 2, 1, '2024-09-28 11:48:00', '2024-09-28 11:48:00'),
(31, 14, 12, 1, 2, 1, '2024-09-28 11:48:10', '2024-09-28 11:48:10'),
(32, 58, 7, 1, 2, 1, '2024-09-28 11:48:16', '2024-09-28 11:48:16'),
(33, 7, 23, 1, 5, 1, '2024-09-28 11:48:24', '2024-09-28 11:48:24'),
(34, 25, 24, 1, 5, 1, '2024-09-28 11:48:30', '2024-09-28 11:48:30'),
(35, 60, 8, 1, 5, 1, '2024-09-28 11:48:36', '2024-09-28 11:48:36'),
(36, 2, 2, 1, 3, 1, '2024-09-28 11:48:44', '2024-09-28 11:48:44'),
(37, 27, 17, 1, 3, 1, '2024-09-28 11:48:56', '2024-09-28 11:48:56'),
(38, 6, 3, 1, 6, 1, '2024-09-28 11:49:02', '2024-09-28 11:49:02'),
(39, 29, 18, 1, 6, 1, '2024-09-28 11:49:12', '2024-09-28 11:49:12'),
(40, 30, 19, 1, 6, 1, '2024-09-28 11:49:18', '2024-09-28 11:49:18'),
(41, 55, 9, 1, 7, 1, '2024-09-28 11:49:24', '2024-09-28 11:49:24'),
(42, 23, 20, 1, 7, 1, '2024-09-28 11:49:30', '2024-09-28 11:49:30'),
(43, 20, 13, 1, 7, 1, '2024-09-28 11:49:35', '2024-09-28 11:49:35'),
(44, 8, 4, 1, 8, 1, '2024-09-28 11:49:42', '2024-09-28 11:49:42'),
(45, 22, 21, 1, 9, 1, '2024-09-28 11:49:50', '2024-09-28 11:49:50'),
(46, 21, 22, 1, 9, 1, '2024-09-28 11:50:05', '2024-09-28 11:50:05'),
(47, 54, 10, 1, 10, 1, '2024-09-28 11:50:12', '2024-09-28 11:50:12'),
(48, 13, 14, 1, 10, 1, '2024-09-28 11:50:19', '2024-09-28 11:50:19'),
(49, 1, 25, 1, 11, 1, '2024-09-28 12:45:57', '2024-09-28 12:45:57'),
(50, 4, 26, 1, 12, 1, '2024-09-28 12:46:03', '2024-09-28 12:46:03');

-- --------------------------------------------------------

--
-- Table structure for table `election_period_candidates`
--

CREATE TABLE `election_period_candidates` (
  `id` int(11) NOT NULL,
  `election_period_application_id` int(11) NOT NULL,
  `valid_flag` tinyint(4) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `election_period_candidates`
--

INSERT INTO `election_period_candidates` (`id`, `election_period_application_id`, `valid_flag`, `created`, `modified`) VALUES
(25, 35, 1, '2024-09-28 11:50:41', '2024-09-28 11:50:41'),
(26, 38, 1, '2024-09-28 11:50:43', '2024-09-28 11:50:43'),
(27, 29, 1, '2024-09-28 11:50:44', '2024-09-28 11:50:44'),
(28, 26, 1, '2024-09-28 11:50:45', '2024-09-28 11:50:45'),
(29, 36, 1, '2024-09-28 11:50:47', '2024-09-28 11:50:47'),
(30, 25, 1, '2024-09-28 11:50:48', '2024-09-28 11:50:48'),
(31, 30, 1, '2024-09-28 11:50:49', '2024-09-28 11:50:49'),
(32, 45, 1, '2024-09-28 11:50:50', '2024-09-28 11:50:50'),
(33, 42, 1, '2024-09-28 11:50:51', '2024-09-28 11:50:51'),
(34, 46, 1, '2024-09-28 11:50:53', '2024-09-28 11:50:53'),
(35, 44, 1, '2024-09-28 11:50:54', '2024-09-28 11:50:54'),
(36, 31, 1, '2024-09-28 11:50:55', '2024-09-28 11:50:55'),
(37, 32, 1, '2024-09-28 11:50:58', '2024-09-28 11:50:58'),
(38, 28, 1, '2024-09-28 11:51:00', '2024-09-28 11:51:00'),
(39, 37, 1, '2024-09-28 11:51:02', '2024-09-28 11:51:02'),
(40, 41, 1, '2024-09-28 11:51:06', '2024-09-28 11:51:06'),
(41, 33, 1, '2024-09-28 11:51:09', '2024-09-28 11:51:09'),
(42, 27, 1, '2024-09-28 11:51:11', '2024-09-28 11:51:11'),
(43, 39, 1, '2024-09-28 11:51:15', '2024-09-28 11:51:15'),
(44, 34, 1, '2024-09-28 11:51:17', '2024-09-28 11:51:17'),
(45, 40, 1, '2024-09-28 11:51:20', '2024-09-28 11:51:20'),
(46, 43, 1, '2024-09-28 11:51:24', '2024-09-28 11:51:24'),
(47, 47, 1, '2024-09-28 11:51:26', '2024-09-28 11:51:26'),
(48, 48, 1, '2024-09-28 11:51:28', '2024-09-28 11:51:28'),
(49, 49, 1, '2024-09-28 12:46:11', '2024-09-28 12:46:11'),
(50, 50, 1, '2024-09-28 12:46:14', '2024-09-28 12:46:14');

-- --------------------------------------------------------

--
-- Table structure for table `election_period_positions`
--

CREATE TABLE `election_period_positions` (
  `id` int(11) NOT NULL,
  `election_period_id` int(11) NOT NULL,
  `predefined_position_id` int(11) NOT NULL,
  `count` int(11) NOT NULL DEFAULT 1 COMMENT 'how many wins in a position',
  `status` tinyint(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `election_period_positions`
--

INSERT INTO `election_period_positions` (`id`, `election_period_id`, `predefined_position_id`, `count`, `status`, `created`, `modified`) VALUES
(1, 1, 1, 1, 1, '2024-09-28 04:18:43', '2024-09-28 04:18:43'),
(2, 1, 2, 1, 1, '2024-09-28 04:18:43', '2024-09-28 04:18:43'),
(3, 1, 3, 1, 1, '2024-09-28 04:18:43', '2024-09-28 04:18:43'),
(4, 1, 4, 1, 1, '2024-09-28 04:18:43', '2024-09-28 04:18:43'),
(5, 1, 5, 1, 1, '2024-09-28 04:18:43', '2024-09-28 04:18:43'),
(6, 1, 6, 2, 1, '2024-09-28 04:18:43', '2024-09-28 04:18:43'),
(7, 1, 7, 1, 1, '2024-09-28 04:18:43', '2024-09-28 04:18:43'),
(8, 1, 8, 1, 1, '2024-09-28 04:18:43', '2024-09-28 04:18:43'),
(9, 1, 9, 1, 1, '2024-09-28 04:18:43', '2024-09-28 04:18:43'),
(10, 1, 10, 1, 1, '2024-09-28 04:18:43', '2024-09-28 04:18:43'),
(11, 1, 11, 1, 1, '2024-09-28 04:18:43', '2024-09-28 04:18:43'),
(12, 1, 12, 1, 1, '2024-09-28 04:18:43', '2024-09-28 04:18:43');

-- --------------------------------------------------------

--
-- Table structure for table `election_votes`
--

CREATE TABLE `election_votes` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL COMMENT 'the voter',
  `voters_token_id` int(11) NOT NULL,
  `election_period_id` int(11) NOT NULL,
  `election_period_candidate_id` int(11) NOT NULL,
  `valid_flag` tinyint(1) NOT NULL DEFAULT 1,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `election_votes`
--

INSERT INTO `election_votes` (`id`, `student_id`, `voters_token_id`, `election_period_id`, `election_period_candidate_id`, `valid_flag`, `created`, `modified`) VALUES
(53, 3, 3, 1, 30, 1, '2024-09-28 15:50:34', '2024-09-28 15:50:34'),
(54, 3, 3, 1, 42, 1, '2024-09-28 15:50:34', '2024-09-28 15:50:34'),
(55, 3, 3, 1, 31, 1, '2024-09-28 15:50:34', '2024-09-28 15:50:34'),
(56, 3, 3, 1, 44, 1, '2024-09-28 15:50:34', '2024-09-28 15:50:34'),
(57, 3, 3, 1, 39, 1, '2024-09-28 15:50:34', '2024-09-28 15:50:34'),
(58, 3, 3, 1, 43, 1, '2024-09-28 15:50:34', '2024-09-28 15:50:34'),
(59, 3, 3, 1, 45, 1, '2024-09-28 15:50:34', '2024-09-28 15:50:34'),
(60, 3, 3, 1, 33, 1, '2024-09-28 15:50:34', '2024-09-28 15:50:34'),
(61, 3, 3, 1, 35, 1, '2024-09-28 15:50:34', '2024-09-28 15:50:34'),
(62, 3, 3, 1, 32, 1, '2024-09-28 15:50:34', '2024-09-28 15:50:34'),
(63, 3, 3, 1, 48, 1, '2024-09-28 15:50:34', '2024-09-28 15:50:34'),
(64, 3, 3, 1, 49, 1, '2024-09-28 15:50:34', '2024-09-28 15:50:34'),
(65, 3, 3, 1, 50, 1, '2024-09-28 15:50:34', '2024-09-28 15:50:34'),
(66, 2, 2, 1, 28, 1, '2024-09-28 15:56:06', '2024-09-28 15:56:06'),
(67, 2, 2, 1, 38, 1, '2024-09-28 15:56:06', '2024-09-28 15:56:06'),
(68, 2, 2, 1, 31, 1, '2024-09-28 15:56:06', '2024-09-28 15:56:06'),
(69, 2, 2, 1, 44, 1, '2024-09-28 15:56:06', '2024-09-28 15:56:06'),
(70, 2, 2, 1, 29, 1, '2024-09-28 15:56:06', '2024-09-28 15:56:06'),
(71, 2, 2, 1, 26, 1, '2024-09-28 15:56:06', '2024-09-28 15:56:06'),
(72, 2, 2, 1, 43, 1, '2024-09-28 15:56:06', '2024-09-28 15:56:06'),
(73, 2, 2, 1, 33, 1, '2024-09-28 15:56:06', '2024-09-28 15:56:06'),
(74, 2, 2, 1, 35, 1, '2024-09-28 15:56:06', '2024-09-28 15:56:06'),
(75, 2, 2, 1, 32, 1, '2024-09-28 15:56:06', '2024-09-28 15:56:06'),
(76, 2, 2, 1, 47, 1, '2024-09-28 15:56:06', '2024-09-28 15:56:06'),
(77, 2, 2, 1, 49, 1, '2024-09-28 15:56:06', '2024-09-28 15:56:06'),
(78, 2, 2, 1, 50, 1, '2024-09-28 15:56:06', '2024-09-28 15:56:06'),
(79, 9, 9, 1, 30, 1, '2024-09-28 15:59:12', '2024-09-28 15:59:12'),
(80, 9, 9, 1, 42, 1, '2024-09-28 15:59:12', '2024-09-28 15:59:12'),
(81, 9, 9, 1, 27, 1, '2024-09-28 15:59:12', '2024-09-28 15:59:12'),
(82, 9, 9, 1, 41, 1, '2024-09-28 15:59:12', '2024-09-28 15:59:12'),
(83, 9, 9, 1, 39, 1, '2024-09-28 15:59:12', '2024-09-28 15:59:12'),
(84, 9, 9, 1, 26, 1, '2024-09-28 15:59:12', '2024-09-28 15:59:12'),
(85, 9, 9, 1, 43, 1, '2024-09-28 15:59:12', '2024-09-28 15:59:12'),
(86, 9, 9, 1, 33, 1, '2024-09-28 15:59:12', '2024-09-28 15:59:12'),
(87, 9, 9, 1, 35, 1, '2024-09-28 15:59:12', '2024-09-28 15:59:12'),
(88, 9, 9, 1, 32, 1, '2024-09-28 15:59:12', '2024-09-28 15:59:12'),
(89, 9, 9, 1, 47, 1, '2024-09-28 15:59:12', '2024-09-28 15:59:12'),
(90, 9, 9, 1, 49, 1, '2024-09-28 15:59:12', '2024-09-28 15:59:12'),
(91, 9, 9, 1, 50, 1, '2024-09-28 15:59:12', '2024-09-28 15:59:12'),
(92, 8, 8, 1, 30, 1, '2024-09-28 16:02:37', '2024-09-28 16:02:37'),
(93, 8, 8, 1, 38, 1, '2024-09-28 16:02:37', '2024-09-28 16:02:37'),
(94, 8, 8, 1, 27, 1, '2024-09-28 16:02:37', '2024-09-28 16:02:37'),
(95, 8, 8, 1, 41, 1, '2024-09-28 16:02:37', '2024-09-28 16:02:37'),
(96, 8, 8, 1, 29, 1, '2024-09-28 16:02:37', '2024-09-28 16:02:37'),
(97, 8, 8, 1, 26, 1, '2024-09-28 16:02:37', '2024-09-28 16:02:37'),
(98, 8, 8, 1, 45, 1, '2024-09-28 16:02:37', '2024-09-28 16:02:37'),
(99, 8, 8, 1, 33, 1, '2024-09-28 16:02:37', '2024-09-28 16:02:37'),
(100, 8, 8, 1, 35, 1, '2024-09-28 16:02:37', '2024-09-28 16:02:37'),
(101, 8, 8, 1, 32, 1, '2024-09-28 16:02:37', '2024-09-28 16:02:37'),
(102, 8, 8, 1, 47, 1, '2024-09-28 16:02:37', '2024-09-28 16:02:37'),
(103, 8, 8, 1, 49, 1, '2024-09-28 16:02:37', '2024-09-28 16:02:37'),
(104, 8, 8, 1, 50, 1, '2024-09-28 16:02:37', '2024-09-28 16:02:37'),
(105, 4, 4, 1, 28, 1, '2024-09-28 17:12:44', '2024-09-28 17:12:44'),
(106, 4, 4, 1, 38, 1, '2024-09-28 17:12:44', '2024-09-28 17:12:44'),
(107, 4, 4, 1, 36, 1, '2024-09-28 17:12:44', '2024-09-28 17:12:44'),
(108, 4, 4, 1, 25, 1, '2024-09-28 17:12:44', '2024-09-28 17:12:44'),
(109, 4, 4, 1, 29, 1, '2024-09-28 17:12:44', '2024-09-28 17:12:44'),
(110, 4, 4, 1, 45, 1, '2024-09-28 17:12:44', '2024-09-28 17:12:44'),
(111, 4, 4, 1, 26, 1, '2024-09-28 17:12:44', '2024-09-28 17:12:44'),
(112, 4, 4, 1, 46, 1, '2024-09-28 17:12:44', '2024-09-28 17:12:44'),
(113, 4, 4, 1, 35, 1, '2024-09-28 17:12:44', '2024-09-28 17:12:44'),
(114, 4, 4, 1, 34, 1, '2024-09-28 17:12:44', '2024-09-28 17:12:44'),
(115, 4, 4, 1, 48, 1, '2024-09-28 17:12:44', '2024-09-28 17:12:44'),
(116, 4, 4, 1, 49, 1, '2024-09-28 17:12:44', '2024-09-28 17:12:44'),
(117, 4, 4, 1, 50, 1, '2024-09-28 17:12:44', '2024-09-28 17:12:44');

-- --------------------------------------------------------

--
-- Table structure for table `predefined_positions`
--

CREATE TABLE `predefined_positions` (
  `id` int(11) NOT NULL,
  `position_title` varchar(255) NOT NULL,
  `order_number` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `predefined_positions`
--

INSERT INTO `predefined_positions` (`id`, `position_title`, `order_number`, `created`, `modified`) VALUES
(1, 'President', 1, '2024-09-28 04:12:21', '2024-09-28 04:12:21'),
(2, 'Secretary', 3, '2024-09-28 04:12:29', '2024-09-28 04:12:29'),
(3, 'Auditor', 5, '2024-09-28 04:12:46', '2024-09-28 04:12:46'),
(4, 'Vice President', 2, '2024-09-28 04:12:52', '2024-09-28 04:12:52'),
(5, 'Treasurer', 4, '2024-09-28 04:13:05', '2024-09-28 04:13:05'),
(6, 'Public Information Officer', 6, '2024-09-28 04:13:34', '2024-09-28 04:13:34'),
(7, 'Protocol Officer', 7, '2024-09-28 04:14:36', '2024-09-28 04:14:36'),
(8, 'Grade 8 Representative', 8, '2024-09-28 04:14:42', '2024-09-28 04:14:42'),
(9, 'Grade 9 Representative', 9, '2024-09-28 04:14:48', '2024-09-28 04:14:48'),
(10, 'Grade 10 Representative', 10, '2024-09-28 04:14:55', '2024-09-28 04:14:55'),
(11, 'Grade 11 Representative', 11, '2024-09-28 04:15:03', '2024-09-28 04:15:03'),
(12, 'Grade 12 Representative', 12, '2024-09-28 04:15:07', '2024-09-28 04:15:07');

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `id` int(255) NOT NULL,
  `grade_level` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` tinyint(50) NOT NULL COMMENT '(0:inactive, 1:active)',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`id`, `grade_level`, `name`, `status`, `created`, `modified`) VALUES
(1, 7, 'Melon', 1, '2024-09-28 04:09:29', '2024-09-28 04:09:29'),
(2, 9, 'Daisy', 1, '2024-09-28 04:09:45', '2024-09-28 04:09:45'),
(3, 8, 'Apple', 1, '2024-09-28 04:09:54', '2024-09-28 04:09:54'),
(4, 9, 'Sunflower', 1, '2024-09-28 04:10:07', '2024-09-28 04:10:07');

-- --------------------------------------------------------

--
-- Table structure for table `section_students`
--

CREATE TABLE `section_students` (
  `id` int(255) NOT NULL,
  `section_id` int(255) NOT NULL,
  `student_id` int(255) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `section_students`
--

INSERT INTO `section_students` (`id`, `section_id`, `student_id`, `status`, `created`, `modified`) VALUES
(1, 1, 4, 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29'),
(2, 1, 3, 0, '2024-09-28 04:21:29', '2024-09-28 04:21:29'),
(3, 1, 5, 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29'),
(4, 1, 9, 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29'),
(5, 1, 10, 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29'),
(6, 1, 1, 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29'),
(7, 1, 7, 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29'),
(8, 1, 8, 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29'),
(9, 1, 6, 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29'),
(10, 1, 2, 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29'),
(11, 2, 16, 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23'),
(12, 2, 12, 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23'),
(13, 2, 19, 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23'),
(14, 2, 18, 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23'),
(15, 2, 17, 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23'),
(16, 2, 13, 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23'),
(17, 2, 11, 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23'),
(18, 2, 14, 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23'),
(19, 2, 15, 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23'),
(20, 2, 20, 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23'),
(21, 3, 29, 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59'),
(22, 3, 30, 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59'),
(23, 3, 26, 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59'),
(24, 3, 22, 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59'),
(25, 3, 23, 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59'),
(26, 3, 21, 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59'),
(27, 3, 24, 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59'),
(28, 3, 27, 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59'),
(29, 3, 25, 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59'),
(30, 3, 28, 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59'),
(31, 4, 56, 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28'),
(32, 4, 51, 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28'),
(33, 4, 58, 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28'),
(34, 4, 54, 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28'),
(35, 4, 57, 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28'),
(36, 4, 53, 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28'),
(37, 4, 60, 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28'),
(38, 4, 55, 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28'),
(39, 4, 59, 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28'),
(40, 4, 52, 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28'),
(41, 1, 62, 1, '2024-09-28 04:27:42', '2024-09-28 04:27:42'),
(42, 0, 16, 1, '2024-09-29 12:02:44', '2024-09-29 12:02:44'),
(43, 0, 12, 1, '2024-09-29 12:02:44', '2024-09-29 12:02:44'),
(44, 0, 19, 1, '2024-09-29 12:02:44', '2024-09-29 12:02:44'),
(45, 0, 18, 1, '2024-09-29 12:02:44', '2024-09-29 12:02:44'),
(46, 0, 17, 1, '2024-09-29 12:02:44', '2024-09-29 12:02:44'),
(47, 0, 13, 1, '2024-09-29 12:02:44', '2024-09-29 12:02:44'),
(48, 0, 11, 1, '2024-09-29 12:02:44', '2024-09-29 12:02:44'),
(49, 0, 14, 1, '2024-09-29 12:02:44', '2024-09-29 12:02:44'),
(50, 0, 15, 1, '2024-09-29 12:02:44', '2024-09-29 12:02:44'),
(51, 0, 20, 1, '2024-09-29 12:02:44', '2024-09-29 12:02:44'),
(54, 3, 3, 1, '2024-09-29 16:59:00', '2024-09-29 16:59:00');

-- --------------------------------------------------------

--
-- Table structure for table `section_student_update_requests`
--

CREATE TABLE `section_student_update_requests` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `current_adviser_id` int(11) NOT NULL,
  `current_section_id` int(11) NOT NULL,
  `new_section_id` int(11) NOT NULL,
  `approver_adviser_id` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL COMMENT '0: pending, 1: accepted, 2: rejected, 4: cancelled',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `section_student_update_requests`
--

INSERT INTO `section_student_update_requests` (`id`, `student_id`, `current_adviser_id`, `current_section_id`, `new_section_id`, `approver_adviser_id`, `status`, `created`, `modified`) VALUES
(1, 3, 2, 1, 3, NULL, 1, '2024-09-29 14:33:19', '2024-09-29 14:33:19'),
(2, 5, 2, 1, 3, NULL, 2, '2024-09-29 17:00:11', '2024-09-29 17:00:11'),
(3, 1, 2, 1, 4, NULL, 4, '2024-09-29 17:00:36', '2024-09-29 17:00:36');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(255) NOT NULL,
  `true_student_id` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `birthdate` date NOT NULL,
  `lrn` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` tinyint(50) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp(),
  `last_updated_by` int(11) DEFAULT NULL COMMENT 'teacher_id on who teacher updated the student info',
  `section_updated_by` int(11) DEFAULT NULL COMMENT 'teacher_id on who teacher updated the student section'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `true_student_id`, `first_name`, `last_name`, `address`, `birthdate`, `lrn`, `email`, `status`, `created`, `modified`, `last_updated_by`, `section_updated_by`) VALUES
(1, '597', 'Dynsil', 'Lake', 'NY City', '2004-06-08', '123424242', 'dynsil@gmail.com', 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29', 2, 2),
(2, '943', 'Blake', 'Garden', 'Mis Occ', '2013-08-04', '24354353', 'blake@gmail.com', 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29', 1, 1),
(3, '432sssss', 'xavier', 'Benitez ', 'Tangub', '2019-04-08', '8.65473E+11', 'xavier@gmail.comssssss', 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29', 2, 2),
(4, '4234', 'Aitor ', 'Hernandez ', 'Mis Occ', '2002-06-11', '654633453', 'Aitor@gmail.com', 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29', 1, 1),
(5, '536', 'Joan ', 'Martin ', 'NY City', '2001-08-09', '3.45345E+12', 'Joan@gmail.com', 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29', 2, 2),
(6, '734', 'Kamila ', 'Stone', 'Mis Occ', '2018-05-05', '543453543', 'Kamila@gmail.com', 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29', 1, 1),
(7, '64565', 'Selene ', 'Wolf', 'Tangub', '2003-09-03', '4.35435E+14', 'Selene@gmail.com', 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29', 1, 1),
(8, '6745', 'Allyson ', 'Figueroa', 'Mis Occ', '2000-02-07', '453873535', 'Allyson@gmail.com ', 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29', 1, 1),
(9, '5454', 'Kevin ', 'Whitney', 'NY City', '2020-05-03', '54383', 'Kevin@gmail.com ', 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29', 1, 1),
(10, '57633', 'Damian ', 'Roman', 'Mis Occ', '2009-02-02', '5435', 'Damian@gmail.com ', 1, '2024-09-28 04:21:29', '2024-09-28 04:21:29', 1, 1),
(11, '474568', 'Zuri ', 'Silva', 'NY City', '2020-05-03', '4.53543E+11', 'Zuri@gmail.com ', 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23', 2, 2),
(12, '255348', 'Saige ', 'Evans', 'Mis Occ', '2009-02-02', '385869', 'Saige@gmail.com ', 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23', 2, 2),
(13, '3843543', 'Eliza ', 'Moyer', 'Tangub', '2001-08-09', '345345', 'Eliza@gmail.com ', 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23', 2, 2),
(14, '824867', 'Melvin', 'Mitchell', 'Mis Occ', '2018-05-05', '34535435435', 'Melvin@gmail.com', 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23', 2, 2),
(15, '8452', 'Rosa ', 'Robinson', 'NY City', '2003-09-03', '53543', 'Rosa@gmail.com ', 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23', 2, 2),
(16, '25256', 'Drew ', 'O’Connell', 'Mis Occ', '2000-02-07', '686534535', 'Drew@gmail.com ', 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23', 2, 2),
(17, '35438', 'Viviana ', 'Orozco', 'Tangub', '2020-05-03', '654654686', 'Viviana@gmail.com ', 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23', 2, 2),
(18, '345383', 'Melissa ', 'Reyes', 'Mis Occ', '2009-02-02', '868653543', 'Melissa@gmail.com ', 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23', 2, 2),
(19, '3338', 'Chance ', 'Wall', 'NY City', '2001-08-09', '35438353543', 'Chance@gmail.com ', 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23', 2, 2),
(20, '853548', 'Jaden ', 'Miles', 'Mis Occ', '2018-05-05', '54348383838', 'Jaden@gmail.com ', 1, '2024-09-28 04:23:23', '2024-09-28 04:23:23', 2, 2),
(21, '5686', 'Lane', 'Miles', 'Tangub', '2001-08-09', '453543543', 'Lane@gmail.com', 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59', 3, 3),
(22, '5436', 'Romeo ', 'Knox', 'Mis Occ', '2018-05-05', '3453543543', 'Romeo@gmail.com ', 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59', 3, 3),
(23, '5475', 'Matias ', 'Hudson', 'NY City', '2003-09-03', '38345345867', 'Matias@gmail.com ', 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59', 3, 3),
(24, '754', 'Marcus ', 'McCarty', 'Mis Occ', '2000-02-07', '4835354354', 'Marcus@gmail.com ', 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59', 3, 3),
(25, '8648', 'Alexandria ', 'Acevedo', 'Tangub', '2020-05-03', '5.43884E+13', 'Alexandria@gmail.com ', 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59', 3, 3),
(26, '4746', 'Nylah ', 'Conner', 'Mis Occ', '2009-02-02', '3.21345E+13', 'Nylah@gmail.com ', 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59', 3, 3),
(27, '84437', 'Dallas ', 'Pollard', 'NY City', '2001-08-09', '54438353543', 'Dallas@gmail.com', 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59', 3, 3),
(28, '97489', 'Sariyah ', 'Gaines', 'Mis Occ', '2018-05-05', '354348353', 'Sariyah@gmail.com ', 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59', 3, 3),
(29, '25436', 'Emely ', 'Correa', 'Tangub', '2003-09-03', '3.54354E+11', 'Emely@gmail.com ', 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59', 3, 3),
(30, '25636', 'Aviana ', 'David', 'Mis Occ', '2000-02-07', '3543543838', 'Aviana@gmail.com ', 1, '2024-09-28 04:23:59', '2024-09-28 04:23:59', 3, 3),
(51, '3535', 'Kendra', 'Portillo', 'Tangub', '2003-09-03', '353889889', 'Kendra@gmail.com', 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28', 4, 4),
(52, '86547', 'Jovanni ', 'Aguirre', 'Mis Occ', '2000-02-07', '6.87E+11', 'Jovanni@gmail.com', 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28', 4, 4),
(53, '38735', 'Keanu ', 'Lawson', 'NY City', '2020-05-03', '5.90E+14', 'Keanu@gmail.com', 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28', 4, 4),
(54, '3538443', 'Valentino ', 'Deleon', 'Mis Occ', '2009-02-02', '6.57545E+12', 'Valentino@gmail.com', 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28', 4, 4),
(55, '83323', 'Frankie ', 'Bishop', 'Tangub', '2001-08-09', '3.54E+13', 'Frankie@gmail.com', 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28', 4, 4),
(56, '34835', 'Azariah', 'Hardin', 'Mis Occ', '2018-05-05', '43534367890', 'Azariah@gmail.com', 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28', 4, 4),
(57, '383543', 'Hope ', 'Bass', 'Mis Occ', '2003-09-03', '3.49E+13', 'Hope@gmail.com', 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28', 4, 4),
(58, '353548', 'Landen ', 'York', 'Tangub', '2000-02-07', '8.68E+13', 'Landen@gmail.com', 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28', 4, 4),
(59, '8646', 'Mateo ', 'Espinoza', 'Mis Occ', '2020-05-03', '876253868', 'Mateo@gmail.com', 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28', 4, 4),
(60, '4654763463', 'Edwin', 'Bapolam', 'Mis Occ', '2001-08-09', '5.87E+11', 'edwin@gmail.com', 1, '2024-09-28 04:26:28', '2024-09-28 04:26:28', 4, 4),
(62, '0978766262872618', 'Missy', 'Dense', 'Bonifacio', '2024-09-06', '987546278368173', 'missy@gmail.com', 1, '2024-09-28 04:27:42', '2024-09-28 04:27:42', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `voters_tokens`
--

CREATE TABLE `voters_tokens` (
  `id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `student_id` int(11) NOT NULL,
  `adviser_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `election_period_id` int(11) NOT NULL,
  `valid_flag` tinyint(1) NOT NULL DEFAULT 1,
  `is_used` tinyint(4) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `voters_tokens`
--

INSERT INTO `voters_tokens` (`id`, `token`, `student_id`, `adviser_id`, `section_id`, `election_period_id`, `valid_flag`, `is_used`, `created`, `modified`) VALUES
(1, 'vt11162d94008e', 1, 1, 1, 1, 1, 0, '2024-09-28 11:35:49', '2024-09-28 11:35:49'),
(2, 'vt21f4dfff9c6d', 2, 1, 1, 1, 0, 1, '2024-09-28 11:35:49', '2024-09-28 11:35:49'),
(3, 'vt3125927bf7fd', 3, 1, 1, 1, 0, 1, '2024-09-28 11:35:49', '2024-09-28 11:35:49'),
(4, 'vt41b7219f69ba', 4, 1, 1, 1, 0, 1, '2024-09-28 11:35:49', '2024-09-28 11:35:49'),
(5, 'vt516a0c2d1dd9', 5, 1, 1, 1, 1, 0, '2024-09-28 11:35:49', '2024-09-28 11:35:49'),
(6, 'vt6192f0dccb50', 6, 1, 1, 1, 1, 0, '2024-09-28 11:35:49', '2024-09-28 11:35:49'),
(7, 'vt71dbaeab5049', 7, 1, 1, 1, 1, 0, '2024-09-28 11:35:49', '2024-09-28 11:35:49'),
(8, 'vt818d9e38f719', 8, 1, 1, 1, 0, 1, '2024-09-28 11:35:49', '2024-09-28 11:35:49'),
(9, 'vt912ad28dbf3f', 9, 1, 1, 1, 0, 1, '2024-09-28 11:35:49', '2024-09-28 11:35:49'),
(10, 'vt101b8d5372ce0', 10, 1, 1, 1, 1, 0, '2024-09-28 11:35:49', '2024-09-28 11:35:49'),
(11, 'vt6218f2117f6b5', 62, 1, 1, 1, 1, 0, '2024-09-28 11:35:49', '2024-09-28 11:35:49'),
(12, 'vt5119abef4e9d2', 51, 4, 4, 1, 1, 0, '2024-09-29 17:13:34', '2024-09-29 17:13:34'),
(13, 'vt5215ec79773cc', 52, 4, 4, 1, 1, 0, '2024-09-29 17:13:34', '2024-09-29 17:13:34'),
(14, 'vt5317a33eaf45b', 53, 4, 4, 1, 1, 0, '2024-09-29 17:13:34', '2024-09-29 17:13:34'),
(15, 'vt541b4268a0ded', 54, 4, 4, 1, 1, 0, '2024-09-29 17:13:34', '2024-09-29 17:13:34'),
(16, 'vt5514a78e4c689', 55, 4, 4, 1, 1, 0, '2024-09-29 17:13:34', '2024-09-29 17:13:34'),
(17, 'vt561fac7711f26', 56, 4, 4, 1, 1, 0, '2024-09-29 17:13:34', '2024-09-29 17:13:34'),
(18, 'vt57119b4777e17', 57, 4, 4, 1, 1, 0, '2024-09-29 17:13:34', '2024-09-29 17:13:34'),
(19, 'vt581ce26c7296c', 58, 4, 4, 1, 1, 0, '2024-09-29 17:13:34', '2024-09-29 17:13:34'),
(20, 'vt591c4b58a7026', 59, 4, 4, 1, 1, 0, '2024-09-29 17:13:34', '2024-09-29 17:13:34'),
(21, 'vt6018da53c1297', 60, 4, 4, 1, 1, 0, '2024-09-29 17:13:34', '2024-09-29 17:13:34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `advisers`
--
ALTER TABLE `advisers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `adviser_sections`
--
ALTER TABLE `adviser_sections`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `candidacy_tokens`
--
ALTER TABLE `candidacy_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`);

--
-- Indexes for table `election_periods`
--
ALTER TABLE `election_periods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `election_period_applications`
--
ALTER TABLE `election_period_applications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `election_period_candidates`
--
ALTER TABLE `election_period_candidates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `election_period_positions`
--
ALTER TABLE `election_period_positions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `election_votes`
--
ALTER TABLE `election_votes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `predefined_positions`
--
ALTER TABLE `predefined_positions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `position_title` (`position_title`),
  ADD UNIQUE KEY `order_number` (`order_number`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `section_students`
--
ALTER TABLE `section_students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `section_student_update_requests`
--
ALTER TABLE `section_student_update_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `true_student_id` (`true_student_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `lrn` (`lrn`);

--
-- Indexes for table `voters_tokens`
--
ALTER TABLE `voters_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `advisers`
--
ALTER TABLE `advisers`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `adviser_sections`
--
ALTER TABLE `adviser_sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `candidacy_tokens`
--
ALTER TABLE `candidacy_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `election_periods`
--
ALTER TABLE `election_periods`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `election_period_applications`
--
ALTER TABLE `election_period_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `election_period_candidates`
--
ALTER TABLE `election_period_candidates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `election_period_positions`
--
ALTER TABLE `election_period_positions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `election_votes`
--
ALTER TABLE `election_votes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- AUTO_INCREMENT for table `predefined_positions`
--
ALTER TABLE `predefined_positions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `section_students`
--
ALTER TABLE `section_students`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `section_student_update_requests`
--
ALTER TABLE `section_student_update_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `voters_tokens`
--
ALTER TABLE `voters_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
