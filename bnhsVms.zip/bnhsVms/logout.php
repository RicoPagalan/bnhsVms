<?php
session_start();
session_destroy();
if($_GET['user'] == 'adviser') {
    header("Location: adviser_login.php");
} elseif ($_GET['user'] == 'admin') {
    header("Location: admin_login.php");
}
